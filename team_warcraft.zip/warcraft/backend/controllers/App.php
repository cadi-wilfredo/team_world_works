<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class App extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library(array('session'));
    }

    function setViewData($viewContent, $viewParams = [])
    {
        return [
            'header' => $this->load->view('frontend/partials/header', [
                'navbar' => $this->load->view('frontend/partials/navbar', $viewParams, true),
                'userbar' => $this->load->view('frontend/partials/userbar', $viewParams, true)
            ], true),
            'footer' => $this->load->view('frontend/partials/footer', $viewParams, true),
            'content' => $this->load->view($viewContent, $viewParams, true)
        ];
    }

    public function index()
    {
        $this->load->library('migration');
        if (!$this->migration->current()) {
            show_error($this->migration->error_string());
        }
        $this->load->model('users', '', TRUE);

        if ($this->input->post('token', TRUE) &&
            $this->input->post('token', TRUE) == $this->session->userdata('token') &&
            $this->input->post('name', TRUE) &&
            $this->input->post('accept_rules', TRUE) == 1 &&
            $this->input->post('email', TRUE) &&
            $this->input->post('password', TRUE) &&
            $this->input->post('password2', TRUE) &&
            $this->input->post('password', TRUE) === $this->input->post('password2', TRUE)
        ) {
            $this->users->name = $this->input->post('name', TRUE);
            $this->users->email = $this->input->post('email', TRUE);
            $this->users->password = sha1($this->input->post('password', TRUE));
            $this->users->rol = 'user';
            if ($this->users->find(array('email' => $this->users->email))['count'] === 0) {
                $this->users->persist();
            } else {
                $this->session->set_flashdata('alert', array('type' => 'error', 'msg' => 'The user already exists.'));
                redirect('app/register');
            }
        } else if ($this->input->post('token', TRUE)) {
            redirect('app/register');
        }
        $this->load->model('marks', '', TRUE);
        $east = json_encode($this->marks->find(['region' => 'east', 'type!=' => 'new'], true)['data'], JSON_NUMERIC_CHECK);
        $kalimdor = json_encode($this->marks->find(['region' => 'kalimdor', 'type!=' => 'new'], true)['data'], JSON_NUMERIC_CHECK);
        $out = json_encode($this->marks->find(['region' => 'out', 'type!=' => 'new'], true)['data'], JSON_NUMERIC_CHECK);
        $north = json_encode($this->marks->find(['region' => 'north', 'type!=' => 'new'], true)['data'], JSON_NUMERIC_CHECK);
        $mal = json_encode($this->marks->find(['region' => 'mal', 'type!=' => 'new'], true)['data'], JSON_NUMERIC_CHECK);
//        print_r($north);die;
//        array('marks' => $allmarks['data'], 'cant' => $allmarks['count'])
        $this->load->view('frontend/home', self::setViewData('frontend/content/map_content', [
            'token' => $this->token(),
            'regions' => [
                'east' => $east,
                'out' => $out,
                'kalimdor' => $kalimdor,
                'north' => $north,
                'mal' => $mal
            ]
        ]));
    }

    public function register()
    {
        $this->load->view('frontend/home', self::setViewData('frontend/content/register_content', ['token' => $this->token()]));
    }

    /* public function changelog()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/changelog_content');
        $this->load->view('frontend/partials/footer');
    }

    public function armory()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/armory_content');
        $this->load->view('frontend/partials/footer');
    }

    public function map()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/map_content');
        $this->load->view('frontend/partials/footer');
    }

    public function rules()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/rules_content');
        $this->load->view('frontend/partials/footer');
    }

    public function faq()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/faq_content');
        $this->load->view('frontend/partials/footer');
    }

    public function gameguide()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/gameguide_content');
        $this->load->view('frontend/partials/footer');
    }

    public function contact()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/contact_content');
        $this->load->view('frontend/partials/footer');
    }

    public function bans_account()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/bans_content');
        $this->load->view('frontend/partials/footer');
    }

    public function bans_chars()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/chars_content');
        $this->load->view('frontend/partials/footer');
    }

    public function media()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/media_content');
        $this->load->view('frontend/partials/footer');
    }

    public function raf()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/raf_content');
        $this->load->view('frontend/partials/footer');
    }

    public function sor()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/sor_content');
        $this->load->view('frontend/partials/footer');
    }

    public function talent_calculator()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/talent_calculator_content');
        $this->load->view('frontend/partials/footer');
    }

    public function private_status()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/private_status_content');
        $this->load->view('frontend/partials/footer');
    }

    public function progress()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/progress_content');
        $this->load->view('frontend/partials/footer');
    }

    public function information()
    {
        $this->load->view('frontend/home');
        $this->load->view('frontend/partials/header');
        $this->load->view('frontend/content/information_content');
        $this->load->view('frontend/partials/footer');
    }*/

    public function token()
    {
        $token = md5(uniqid(rand(), true));
        $this->session->set_userdata('token', $token);
        return $token;
    }
}