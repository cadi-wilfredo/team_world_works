<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Mark extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('rol') == FALSE || $this->session->userdata('email') == FALSE) {
            redirect('login/logout');
        }
    }

    public function index()
    {
        /*$this->load->library('migration');
        if (!$this->migration->current()) {
            show_error($this->migration->error_string());
        }*/

        $this->load->model('marks', '', TRUE);
        $allmarks = $this->marks->findAll();

        $this->load->view('backend/index');
        $this->load->view('backend/partials/header');
        $this->load->view('backend/partials/left_menu', array('active' => 'marks'));
        $this->load->view('backend/content/marks/index', array('marks' => $allmarks['data'], 'cant' => $allmarks['count']));
        $this->load->view('backend/partials/footer', array('type' => ''));
    }

    public function form($action, $id)
    {
        $mark = false;
        $this->load->model('marks', '', TRUE);
        $new = $this->marks->find(array('type' => 'new'))['data'];
        if ($action === 'edit') {
            $mark = $this->marks->find(array('id' => $id))['data'][0];
        }
        $this->load->view('backend/index');
        $this->load->view('backend/partials/header');
        $this->load->view('backend/partials/left_menu', array('active' => 'marks'));
        $this->load->view('backend/content/marks/form', array('mark' => $mark, 'new' => $new));
        $this->load->view('backend/partials/footer', array('type' => 'mark', 'data' => $mark));
    }

    public function processform()
    {
        $x = $this->input->post('x', TRUE);
        $y = $this->input->post('y', TRUE);
        $name = $this->input->post('name', TRUE);
        $min = $this->input->post('min', TRUE);
        $max = $this->input->post('max', TRUE);
        $type = $this->input->post('type', TRUE);
        $filter = $this->input->post('filter', TRUE);
        $desc = $this->input->post('desc', TRUE);
        $region = $this->input->post('region', TRUE);
        $this->load->model('marks', '', TRUE);
            $this->marks->icon = '';
            $this->marks->iconext = '';
        if (array_key_exists('icon', $_FILES) && $_FILES['icon']['error'] === UPLOAD_ERR_OK) {
            move_uploaded_file($_FILES['icon']['tmp_name'], realpath('./assets/frontend/images/' . $_FILES['icon']['name']));
            $icon = explode('.', $_FILES['icon']['name'])[0];
            $ext = explode('.', $_FILES['icon']['name'])[1];
            $this->marks->icon = $icon;
            $this->marks->iconext = $ext;
        }

        $msg = 'The item was added successfully.';
        if ($id = $this->input->post('id', TRUE)) {
            $this->marks->id = $id;
            $msg = 'The item was edited successfully.';
        }
        $cat = $this->marks->find(['name' => $type]);

        if ($cat['count'] > 0) {
            $this->marks->typeicon = $cat['data'][0]->icon;
            $this->marks->typeiconext = $cat['data'][0]->iconext;
        } else {
            $this->marks->typeicon = $type;
            $this->marks->typeiconext = 'png';
        }

        $this->marks->name = $name;
        $this->marks->points = '[' . $x . ',' . $y . ']';
        $this->marks->type = $type;
        $this->marks->desc = $desc;
        $this->marks->min = $min;
        $this->marks->max = $max;
        $this->marks->filter = $filter;
        $this->marks->region = $region;

        $this->marks->persist();
        $this->session->set_flashdata('alert', array('type' => 'success', 'msg' => $msg));

        redirect('mark/');
    }

    public function delete($from, $id)
    {
        $this->load->model($from, '', TRUE);
        $this->$from->id = $id;
        $this->$from->delete($id);
        $this->session->set_flashdata('alert', array('type' => 'success', 'msg' => 'The item was deleted successfully.'));
        redirect('mark/');
    }
}