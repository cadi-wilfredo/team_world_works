<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('rol') == FALSE || $this->session->userdata('email') == FALSE) {
            redirect('login/logout');
        }
    }

    public function index()
    {
        $this->load->model('users', '', TRUE);
        $allUsers = $this->users->findAll();

        $this->load->view('backend/index');
        $this->load->view('backend/partials/header');
        $this->load->view('backend/partials/left_menu', array('active' => 'users'));
        $this->load->view('backend/content/users/index', array('users' => $allUsers['data'], 'count' => $allUsers['count']));
        $this->load->view('backend/partials/footer', array('type' => ''));
    }

    public function form($action, $id)
    {
        $user = false;
        $this->load->model('users', '', TRUE);
        if ($action === 'edit') {
            $user = $this->users->find(array('id' => $id))['data'][0];
        }
        $this->load->view('backend/index');
        $this->load->view('backend/partials/header');
        $this->load->view('backend/partials/left_menu', array('active' => 'users'));
        $this->load->view('backend/content/users/form', array('user' => $user));
        $this->load->view('backend/partials/footer', array('type' => 'user', 'data' => $user));
    }

    public function process()
    {
        $this->load->model('users', '', TRUE);
        $this->users->name = $this->input->post('name', TRUE);
        $this->users->email = $this->input->post('email', TRUE);
        $this->users->password = sha1($this->input->post('password', TRUE));
        $this->users->rol = $this->input->post('role', TRUE);
        $msg = 'The item was added successfully.';

        $exist = FALSE;
        if ($this->users->find(array('email' => $this->users->email))['count'] > 0) {
            $exist = TRUE;
        }

        if ($id = $this->input->post('id', TRUE)) {
            $this->users->id = $id;
            $msg = 'The item was edited successfully.';
        }

        if ($exist) {
            $this->session->set_flashdata('alert', array('type' => 'error', 'msg' => 'The item already exists.'));
            if ($this->input->post('id', TRUE))
                redirect('user/form/edit/' . $this->input->post('id', TRUE));
            else {
                redirect('user/form/new/0');
            }
        }
        $this->users->persist();
        $this->session->set_flashdata('alert', array('type' => 'success', 'msg' => $msg));
        redirect('user/');
    }

    public function delete($from, $id)
    {
        $this->load->model($from, '', TRUE);
        $this->$from->id = $id;
        $this->$from->delete($id);
        $this->session->set_flashdata('alert', array('type' => 'success', 'msg' => 'The item was deleted successfully.'));
        redirect('user/');
    }
}