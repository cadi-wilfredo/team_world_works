<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* @fields  $name,$points,$type,$desc,$icon,$lvl,$filter
*/


class Marks extends CI_Model
{

    public $id, $createdAt, $updatedAt, $name, $points, $region, $type, $typeicon, $typeiconext, $desc, $icon, $iconext, $min, $max, $filter;

    public function __construct()
    {
        $this->id = null;
        $this->updatedAt = date('Y-m-d H:i:s');
        // Call the CI_Model constructor
        parent::__construct();
    }

    /*
    *@param   $order   array('id'=>'DESC')
    */
    public function findAll($order = null, $limit = null)
    {
        $this->db->select('*');
        $this->db->from('marks');
        if (!is_null($order)) {
            foreach ($order as $k => $o) {
                $this->db->order_by($k, $o);
            }
        }
        if (!is_null($limit)) {
            $this->db->limit($limit['start'], $limit['limit']);
        }
        $query = $this->db->get();

        return array('data' => $query->result(), 'count' => $query->num_rows());
    }

    /*
    *@param   $order   array('id'=>'1')
    */
    public function find($fields = null, $a = null)
    {
        $this->db->select('*');
        $this->db->from('marks');
        if (!is_null($fields)) {
            foreach ($fields as $f => $v) {
                $this->db->where($f, $v);
            }
        }
        $query = $this->db->get();
        if ($a) {
            return array('data' => $query->result_array(), 'count' => $query->num_rows());
        }
        return array('data' => $query->result(), 'count' => $query->num_rows());
    }

    public function persist()
    {
        if (!is_null($this->id)) {
            foreach ($this as $prop => $val) {
                if (!is_null($val)) {
                    $this->db->set($prop, $val);
                }
            }
            $this->db->where('id', $this->id);
            $this->db->update('marks');
        } else {
            $this->createdAt = date('Y-m-d H:i:s');
            $this->db->insert('marks', $this);
        }
    }

    public function delete()
    {
        if (!is_null($this->id)) {
            $this->db->delete('marks', array('id' => $this->id));
        }
    }

    public function deleteAll()
    {
        $this->db->empty_table('marks');
    }
}