<h2 class="ui header">
    <i class="marker icon"></i>

    <div class="content">Users</div>
</h2>
<div class="ui attached container">
    <?php if ($flash = $this->session->flashdata('alert')) {
        ?>
        <div class="ui ignored <?php echo $flash['type']; ?> message">
            <?php echo $flash['msg']; ?>
        </div>
    <?php } ?>
    <a href="<?php echo site_url('user/form') ?>">
        <button class="ui button green"><i class="plus icon"></i>Add user</button>
    </a>
    <table class="ui celled table">
        <thead>
            <tr>
                <th>
                    <div class="ui ribbon label"><i class="users icon"></i> Users data table</div>
                </th>
                <th><i class="envelope icon"></i> Email</th>
                <th><i class="key icon"></i>Access level</th>
                <th><i class="cogs icon"></i> Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($count > 0) {
                foreach ($users as $key => $user) { ?>
                    <tr>
                        <td class="">
                            <h4 class="ui image header">
                                <div class="conten"><?php echo $user->name ?></div>
                            </h4>
                        </td>
                        <td class=""><?php echo $user->email ?></td>
                        <td class="">
                            <?php
                            if (isset($user->rol) && $user->rol === 'user')
                                echo 'User';
                            elseif ($user->rol === 'admin')
                                echo 'Administrator';
                            else echo '-';
                            ?>
                        </td>
                        <td class="">
                            <div class="ui buttons">
                                <a href="<?php echo site_url('user/form/edit/'.$user->id) ?>" class="ui button olive">Edit</a>
                                <div class="or" data-text="or"></div>
                                <a href="<?php echo site_url('user/delete/users/' . $user->id) ?>" class="ui button red">Delete</a>

                            </div>
                        </td>
                    </tr>
                <?php }
            } else { ?>
                <tr>
                    <td rowspan="6">No data to show</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>