<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<title>Atlantiss Admin</title>
	<?php echo assets_css(
		array(
			'backend/semantic/assets/semantic/dist/semantic.css',
			'backend/semantic/assets/css/style.css'
		)
	) ?>
</head>
<body class="full height" style="cursor: default;">