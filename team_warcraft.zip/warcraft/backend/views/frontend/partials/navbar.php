<nav id="header-bar">
    <ul itemtype="#" itemscope="">
        <li class="home">
            <a title="Home" href="<?php echo site_url('app/index') ?>" itemprop="url"><span itemprop="name">Home</span></a>
        </li>
        <li class="forum ">
            <a title="Forum" href="#!" itemprop="url"><span itemprop="name">Forum</span></a>
        </li>
        <li class="changelog ">
            <a title="Changelog 4.3.4" href="#!" itemprop="url"><span itemprop="name">Changelog 4.3.4</span></a>
        </li>
        <li class="bugtracker ">
            <a title="Bugtracker" href="#!" itemprop="url"><span itemprop="name">Bugtracker</span></a>
        </li>
        <li class="armory active">
            <a title="Armory" href="#!" itemprop="url"><span itemprop="name">Armory</span></a>
        </li>
        <li class="download">
            <a href="#!" itemprop="url">
                <strong>How to connect</strong>
                <span><b>realmlist</b> play.atlantiss.eu</span>
            </a>
        </li>
    </ul>
</nav>