if (typeof $WH == "undefined") {
    var $WH = {}
}
$WH.$E = function (b) {
    if (!b) {
        if (typeof event != "undefined") {
            b = event
        } else {
            return null
        }
    }
    if (b.which) {
        b._button = b.which
    } else {
        b._button = b.button;
        if ($WH.Browser.ie6789 && b._button) {
            if (b._button & 4) {
                b._button = 2
            } else {
                if (b._button & 2) {
                    b._button = 3
                }
            }
        } else {
            b._button = b.button + 1
        }
    }
    b._target = b.target ? b.target : b.srcElement;
    b._wheelDelta = b.wheelDelta ? b.wheelDelta : -b.detail;
    return b
};
$WH.$A = function (h) {
    var f = [];
    for (var g = 0, a = h.length; g < a; ++g) {
        f.push(h[g])
    }
    return f
};
if (!Function.prototype.bind) {
    Function.prototype.bind = function () {
        var f = this, e = $WH.$A(arguments), d = e.shift();
        return function () {
            return f.apply(d, e.concat($WH.$A(arguments)))
        }
    }
}
if (!String.prototype.removeAllWhitespace) {
    String.prototype.removeAllWhitespace = function () {
        return this.replace("/s+/g", "")
    }
}
$WH.sprintf = function (c) {
    var d;
    for (d = 1, len = arguments.length; d < len; ++d) {
        c = c.replace("$" + d, arguments[d])
    }
    return c
};
$WH.sprintfa = function (c) {
    var d;
    for (d = 1, len = arguments.length; d < len; ++d) {
        c = c.replace(new RegExp("\\$" + d, "g"), arguments[d])
    }
    return c
};
$WH.sprintfo = function (f) {
    if (typeof f == "object" && f.length) {
        var e = f;
        f = e[0];
        var d;
        for (d = 1; d < e.length; ++d) {
            f = f.replace("$" + d, e[d])
        }
        return f
    }
};
$WH.isset = function (b) {
    return typeof window[b] != "undefined"
};
if (!$WH.isset("console")) {
    console = {
        log: function () {
        }
    }
}
$WH.ge = function (b) {
    if (typeof b != "string") {
        return b
    }
    return document.getElementById(b)
};
$WH.gE = function (d, c) {
    return d.getElementsByTagName(c)
};
$WH.ce = function (h, c, g) {
    var f = document.createElement(h);
    if (c) {
        $WH.cOr(f, c)
    }
    if (g) {
        $WH.ae(f, g)
    }
    return f
};
$WH.de = function (b) {
    if (!b || !b.parentNode) {
        return
    }
    b.parentNode.removeChild(b)
};
$WH.ae = function (d, c) {
    if ($WH.is_array(c)) {
        $WH.array_apply(c, d.appendChild.bind(d));
        return c
    } else {
        return d.appendChild(c)
    }
};
if (!String.prototype.ltrim) {
    String.prototype.ltrim = function () {
        return this.replace(/^\s*/, "")
    }
}
if (!String.prototype.rtrim) {
    String.prototype.rtrim = function () {
        return this.replace(/\s*$/, "")
    }
}
if (!String.prototype.trim) {
    String.prototype.trim = function () {
        return this.ltrim().rtrim()
    }
}
if (!String.prototype.removeAllWhitespace) {
    String.prototype.removeAllWhitespace = function () {
        return this.replace("/s+/g", "")
    }
}
$WH.strcmp = function (g, h) {
    if (g == h) {
        return 0
    }
    if (g == null) {
        return -1
    }
    if (h == null) {
        return 1
    }
    var a = parseFloat(g);
    var b = parseFloat(h);
    if (!isNaN(a) && !isNaN(b) && a != b) {
        return a < b ? -1 : 1
    }
    if (typeof g == "string" && typeof h == "string") {
        return g.localeCompare(h)
    }
    return g < h ? -1 : 1
};
$WH.trim = function (b) {
    return b.replace(/(^\s*|\s*$)/g, "")
};
$WH.rtrim = function (f, e) {
    var a = f.length;
    while (--a > 0 && f.charAt(a) == e) {
    }
    f = f.substring(0, a + 1);
    if (f == e) {
        f = ""
    }
    return f
};
$WH.sprintf = function (c) {
    var d;
    for (d = 1, len = arguments.length; d < len; ++d) {
        c = c.replace("$" + d, arguments[d])
    }
    return c
};
$WH.sprintfa = function (c) {
    var d;
    for (d = 1, len = arguments.length; d < len; ++d) {
        c = c.replace(new RegExp("\\$" + d, "g"), arguments[d])
    }
    return c
};
$WH.sprintfo = function (f) {
    if (typeof f == "object" && f.length) {
        var e = f;
        f = e[0];
        var d;
        for (d = 1; d < e.length; ++d) {
            f = f.replace("$" + d, e[d])
        }
        return f
    }
};
$WH.str_replace = function (a, b, f) {
    while (a.indexOf(b) != -1) {
        a = a.replace(b, f)
    }
    return a
};
$WH.number_format = function (b) {
    x = ("" + parseFloat(b)).split(".");
    b = x[0];
    x = x.length > 1 ? "." + x[1] : "";
    if (b.length <= 3) {
        return b + x
    }
    return $WH.number_format(b.substr(0, b.length - 3)) + "," + b.substr(b.length - 3) + x
};
$WH.is_array = function (a) {
    return !!(a && a.constructor == Array)
};
$WH.in_array = function (m, j, f, k) {
    if (m == null) {
        return -1
    }
    if (f) {
        return $WH.in_arrayf(m, j, f, k)
    }
    for (var l = k || 0, a = m.length; l < a; ++l) {
        if (m[l] == j) {
            return l
        }
    }
    return -1
};
$WH.aef = function (d, c) {
    return d.insertBefore(c, d.firstChild)
};
$WH.ee = function (d, c) {
    if (!c) {
        c = 0
    }
    while (d.childNodes[c]) {
        d.removeChild(d.childNodes[c])
    }
};
$WH.ct = function (b) {
    return document.createTextNode(b)
};
$WH.st = function (d, c) {
    if (d.firstChild && d.firstChild.nodeType == 3) {
        d.firstChild.nodeValue = c
    } else {
        $WH.aef(d, $WH.ct(c))
    }
};
$WH.tb = function () {
    this.blur()
};
$WH.aE = function (d, f, e) {
    if ($WH.Browser.ie6789) {
        d.attachEvent("on" + f, e)
    } else {
        d.addEventListener(f, e, false)
    }
};
$WH.dE = function (d, f, e) {
    if ($WH.Browser.ie6789) {
        d.detachEvent("on" + f, e)
    } else {
        d.removeEventListener(f, e, false)
    }
};
$WH.sp = function (b) {
    if (!b) {
        b = event
    }
    if ($WH.Browser.ie6789) {
        b.cancelBubble = true
    } else {
        b.stopPropagation()
    }
};
$WH.sc = function (b, a, o, l, k) {
    var m = new Date();
    var p = b + "=" + escape(o) + "; ";
    m.setDate(m.getDate() + a);
    p += "expires=" + m.toUTCString() + "; ";
    if (l) {
        p += "path=" + l + "; "
    }
    if (k) {
        p += "domain=" + k + "; "
    }
    document.cookie = p;
    $WH.gc(b);
    $WH.gc.C[b] = o
};
$WH.dc = function (b) {
    $WH.sc(b, -1);
    $WH.gc.C[b] = null
};
$WH.gc = function (l) {
    if ($WH.gc.I == null) {
        var m = unescape(document.cookie).split("; ");
        $WH.gc.C = {};
        for (var p = 0, j = m.length; p < j; ++p) {
            var k = m[p].indexOf("="), h, o;
            if (k != -1) {
                h = m[p].substr(0, k);
                o = m[p].substr(k + 1)
            } else {
                h = m[p];
                o = ""
            }
            $WH.gc.C[h] = o
        }
        $WH.gc.I = 1
    }
    if (!l) {
        return $WH.gc.C
    } else {
        return $WH.gc.C[l]
    }
};
$WH.ns = function (b) {
    if ($WH.Browser.ie6789) {
        b.onfocus = $WH.tb;
        b.onmousedown = b.onselectstart = b.ondragstart = false
    }
};
$WH.eO = function (c) {
    for (var d in c) {
        delete c[d]
    }
};
$WH.dO = function (d) {
    function c() {
    }

    c.prototype = d;
    return new c
};
$WH.cO = function (f, e) {
    for (var d in e) {
        if (e[d] !== null && typeof e[d] == "object" && e[d].length) {
            f[d] = e[d].slice(0)
        } else {
            f[d] = e[d]
        }
    }
    return f
};
$WH.cOr = function (f, e) {
    for (var d in e) {
        if (typeof e[d] == "object") {
            if (e[d].length) {
                f[d] = e[d].slice(0)
            } else {
                if (!f[d]) {
                    f[d] = {}
                }
                $WH.cOr(f[d], e[d])
            }
        } else {
            f[d] = e[d]
        }
    }
    return f
};
$WH.Browser = {
    ie: !!(window.attachEvent && !window.opera),
    opera: !!window.opera,
    safari: navigator.userAgent.indexOf("Safari") != -1,
    firefox: navigator.userAgent.indexOf("Firefox") != -1,
    chrome: navigator.userAgent.indexOf("Chrome") != -1
};
$WH.Browser.ie9 = $WH.Browser.ie && navigator.userAgent.indexOf("MSIE 9.0") != -1;
$WH.Browser.ie8 = $WH.Browser.ie && navigator.userAgent.indexOf("MSIE 8.0") != -1 && !$WH.Browser.ie9;
$WH.Browser.ie7 = $WH.Browser.ie && navigator.userAgent.indexOf("MSIE 7.0") != -1 && !$WH.Browser.ie8;
$WH.Browser.ie6 = $WH.Browser.ie && navigator.userAgent.indexOf("MSIE 6.0") != -1 && !$WH.Browser.ie7;
$WH.Browser.ie67 = $WH.Browser.ie6 || $WH.Browser.ie7;
$WH.Browser.ie678 = $WH.Browser.ie67 || $WH.Browser.ie8;
$WH.Browser.ie6789 = $WH.Browser.ie678 || $WH.Browser.ie9;
$WH.OS = {
    windows: navigator.appVersion.indexOf("Windows") != -1,
    mac: navigator.appVersion.indexOf("Macintosh") != -1,
    linux: navigator.appVersion.indexOf("Linux") != -1
};
$WH.g_getWindowSize = function () {
    var d = 0, c = 0;
    if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        d = document.documentElement.clientWidth;
        c = document.documentElement.clientHeight
    } else {
        if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
            d = document.body.clientWidth;
            c = document.body.clientHeight
        } else {
            if (typeof window.innerWidth == "number") {
                d = window.innerWidth;
                c = window.innerHeight
            }
        }
    }
    return {w: d, h: c}
};
$WH.g_getScroll = function () {
    var d = 0, c = 0;
    if (typeof(window.pageYOffset) == "number") {
        d = window.pageXOffset;
        c = window.pageYOffset
    } else {
        if (document.body && (document.body.scrollLeft || document.body.scrollTop)) {
            d = document.body.scrollLeft;
            c = document.body.scrollTop
        } else {
            if (document.documentElement && (document.documentElement.scrollLeft || document.documentElement.scrollTop)) {
                d = document.documentElement.scrollLeft;
                c = document.documentElement.scrollTop
            }
        }
    }
    return {x: d, y: c}
};
$WH.g_getCursorPos = function (h) {
    var f, g;
    if (window.innerHeight) {
        f = h.pageX;
        g = h.pageY
    } else {
        var e = $WH.g_getScroll();
        f = h.clientX + e.x;
        g = h.clientY + e.y
    }
    return {x: f, y: g}
};
$WH.ac = function (p, o) {
    var j = 0, k = 0, h;
    while (p) {
        j += p.offsetLeft;
        k += p.offsetTop;
        h = p.parentNode;
        while (h && h != p.offsetParent && h.offsetParent) {
            if (h.scrollLeft || h.scrollTop) {
                j -= (h.scrollLeft | 0);
                k -= (h.scrollTop | 0);
                break
            }
            h = h.parentNode
        }
        p = p.offsetParent
    }
    if ($WH.isset("Lightbox") && Lightbox.isVisible()) {
        o = true
    }
    if (o) {
        var l = $WH.g_getScroll();
        j += l.x;
        k += l.y
    }
    var m = [j, k];
    m.x = j;
    m.y = k;
    return m
};
$WH.g_scrollTo = function (A, B) {
    var q, r = $WH.g_getWindowSize(), p = $WH.g_getScroll(), t = r.w, y = r.h, v = p.x, z = p.y;
    A = $WH.ge(A);
    if (B == null) {
        B = []
    } else {
        if (typeof B == "number") {
            B = [B]
        }
    }
    q = B.length;
    if (q == 0) {
        B[0] = B[1] = B[2] = B[3] = 0
    } else {
        if (q == 1) {
            B[1] = B[2] = B[3] = B[0]
        } else {
            if (q == 2) {
                B[2] = B[0];
                B[3] = B[1]
            } else {
                if (q == 3) {
                    B[3] = B[1]
                }
            }
        }
    }
    q = $WH.ac(A);
    var C = q[0] - B[3], u = q[1] - B[0], s = q[0] + A.offsetWidth + B[1], w = q[1] + A.offsetHeight + B[2];
    if (s - C > t || C < v) {
        v = C
    } else {
        if (s - t > v) {
            v = s - t
        }
    }
    if (w - u > y || u < z) {
        z = u
    } else {
        if (w - y > z) {
            z = w - y
        }
    }
    scrollTo(v, z)
};
$WH.g_createReverseLookupJson = function (d) {
    var f = {};
    for (var e in d) {
        f[d[e]] = e
    }
    return f
};
$WH.g_getLocaleFromDomain = function (e) {
    var f = $WH.g_getLocaleFromDomain.L;
    if (e) {
        var d = e.indexOf(".");
        if (d != -1) {
            e = e.substring(0, d)
        }
    }
    return (f[e] ? f[e] : 0)
};
$WH.g_getLocaleFromDomain.L = {fr: 2, de: 3, es: 6, ru: 7, www: 0, s3: -1};
$WH.g_getDomainFromLocale = function (d) {
    var c;
    if ($WH.g_getDomainFromLocale.L) {
        c = $WH.g_getDomainFromLocale.L
    } else {
        c = $WH.g_getDomainFromLocale.L = $WH.g_createReverseLookupJson($WH.g_getLocaleFromDomain.L)
    }
    return (c[d] ? c[d] : "www")
};
$WH.g_getIdFromTypeName = function (d) {
    var c = $WH.g_getIdFromTypeName.L;
    return (c[d] ? c[d] : -1)
};
$WH.g_getIdFromTypeName.L = {
    npc: 1,
    object: 2,
    item: 3,
    itemset: 4,
    quest: 5,
    spell: 6,
    zone: 7,
    faction: 8,
    pet: 9,
    achievement: 10,
    title: 11,
    statistic: 16,
    character: 100
};
$WH.g_ajaxIshRequest = function (d) {
    var f = document.getElementsByTagName("head")[0], e = $WH.g_getGets();
    if (e.refresh != null) {
        if (e.refresh.length) {
            d += ("&refresh=" + e.refresh)
        } else {
            d += "&refresh"
        }
    }
    if (e.locale != null) {
        d += "&locale=" + e.locale
    }
    if (e.ptr != null) {
        d += "&ptr"
    }
    $WH.ae(f, $WH.ce("script", {type: "text/javascript", src: d, charset: "utf8"}))
};
$WH.g_getGets = function () {
    if ($WH.g_getGets.C != null) {
        return $WH.g_getGets.C
    }
    var c = $WH.g_getQueryString();
    var d = $WH.g_parseQueryString(c);
    $WH.g_getGets.C = d;
    return d
};
$WH.g_getQueryString = function () {
    var b = "";
    if (location.pathname) {
        b += location.pathname.substr(1)
    }
    if (location.search) {
        if (location.pathname) {
            b += "&"
        }
        b += location.search.substr(1)
    }
    return b
};
$WH.g_parseQueryString = function (h) {
    h = decodeURIComponent(h);
    var j = h.split("&");
    var k = {};
    for (var f = 0, g = j.length; f < g; ++f) {
        $WH.g_splitQueryParam(j[f], k)
    }
    return k
};
$WH.g_splitQueryParam = function (k, j) {
    var h = k.indexOf("=");
    var g;
    var f;
    if (h != -1) {
        g = k.substr(0, h);
        f = k.substr(h + 1)
    } else {
        g = k;
        f = ""
    }
    j[g] = f
};
$WH.g_createRect = function (g, h, f, e) {
    return {l: g, t: h, r: g + f, b: h + e}
};
$WH.g_intersectRect = function (a, b) {
    return !(a.l >= b.r || b.l >= a.r || a.t >= b.b || b.t >= a.b)
};
$WH.g_convertRatingToPercent = function (l, j, m, q) {
    var o = $WH.g_convertRatingToPercent.RB, p = $WH.g_convertRatingToPercent.LH;
    if (l < 0) {
        l = 1
    } else {
        if (l > 85) {
            l = 85
        }
    }
    if ((j == 12 || j == 13 || j == 14 || j == 15) && l < 34) {
        l = 34
    }
    if ((j == 28 || j == 36) && (q == 2 || q == 6 || q == 7 || q == 11)) {
        o[j] /= 1.3
    }
    if (m < 0) {
        m = 0
    }
    var k;
    if (o[j] == null) {
        k = 0
    } else {
        var r;
        if (l > 80) {
            r = p[l]
        } else {
            if (l > 70) {
                r = (82 / 52) * Math.pow((131 / 63), ((l - 70) / 10))
            } else {
                if (l > 60) {
                    r = (82 / (262 - 3 * l))
                } else {
                    if (l > 10) {
                        r = ((l - 8) / 52)
                    } else {
                        r = 2 / 52
                    }
                }
            }
        }
        k = m / o[j] / r
    }
    return k
};
$WH.g_statToJson = {
    1: "health",
    2: "mana",
    3: "agi",
    4: "str",
    5: "int",
    6: "spi",
    7: "sta",
    8: "energy",
    9: "rage",
    10: "focus",
    13: "dodgertng",
    14: "parryrtng",
    16: "mlehitrtng",
    17: "rgdhitrtng",
    18: "splhitrtng",
    19: "mlecritstrkrtng",
    20: "rgdcritstrkrtng",
    21: "splcritstrkrtng",
    22: "_mlehitrtng",
    23: "_rgdhitrtng",
    24: "_splhitrtng",
    25: "_mlecritstrkrtng",
    26: "_rgdcritstrkrtng",
    27: "_splcritstrkrtng",
    28: "mlehastertng",
    29: "rgdhastertng",
    30: "splhastertng",
    31: "hitrtng",
    32: "critstrkrtng",
    33: "_hitrtng",
    34: "_critstrkrtng",
    35: "resirtng",
    36: "hastertng",
    37: "exprtng",
    38: "atkpwr",
    39: "rgdatkpwr",
    41: "splheal",
    42: "spldmg",
    43: "manargn",
    44: "armorpenrtng",
    45: "splpwr",
    46: "healthrgn",
    47: "splpen",
    49: "mastrtng",
    50: "armor",
    51: "firres",
    52: "frores",
    53: "holres",
    54: "shares",
    55: "natres",
    56: "arcres"
};
$WH.g_jsonToStat = {};
for (var i in $WH.g_statToJson) {
    $WH.g_jsonToStat[$WH.g_statToJson[i]] = i
}
$WH.g_individualToGlobalStat = {
    16: 31,
    17: 31,
    18: 31,
    19: 32,
    20: 32,
    21: 32,
    22: 33,
    23: 33,
    24: 33,
    25: 34,
    26: 34,
    27: 34,
    28: 36,
    29: 36,
    30: 36
};
$WH.g_convertScalingFactor = function (t, u, p, s, l) {
    var q = $WH.g_convertScalingFactor.SV;
    var r = $WH.g_convertScalingFactor.SD;
    if (!q[t]) {
        if (g_user.roles & U_GROUP_ADMIN) {
            alert("There are no item scaling values for level " + t)
        }
        return (l ? {} : 0)
    }
    var m = {}, o = q[t], v = r[p];
    if (!v || !(s >= 0 && s <= 9)) {
        m.v = o[u]
    } else {
        m.n = $WH.g_statToJson[v[s]];
        m.s = v[s];
        m.v = Math.floor(o[u] * v[s + 10] / 10000)
    }
    return (l ? m : m.v)
};
if (!$WH.wowheadRemote) {
    $WH.g_ajaxIshRequest(baseUrl+"assets/frontend/js/item-scaling.js")
}
$WH.g_convertScalingSpell = function (z, t) {
    var r = {}, u = $WH.g_convertScalingSpell.SV, w = $WH.g_convertScalingSpell.SD, A, q;
    if (!w[t]) {
        if (g_user.roles & U_GROUP_ADMIN) {
            alert("There are no spell scaling distributions for dist " + t)
        }
        return r
    }
    if (!u[z]) {
        if (g_user.roles & U_GROUP_ADMIN) {
            alert("There are no spell scaling values for level " + z)
        }
        return r
    }
    A = w[t];
    if (!A[3]) {
        if (g_user.roles & U_GROUP_ADMIN) {
            alert("This spell should not scale at all")
        }
        return r
    } else {
        if (A[3] == -1) {
            if (g_user.roles & U_GROUP_ADMIN) {
                alert("This spell should use the generic scaling distribution 12")
            }
            A[3] = 12
        }
    }
    if (!u[z][A[3] - 1]) {
        if (g_user.roles & U_GROUP_ADMIN) {
            alert("Unknown category for spell scaling " + A[3])
        }
        return r
    }
    q = u[z][A[3] - 1];
    q *= (Math.min(z, A[14]) + (A[13] * Math.max(0, z - A[14]))) / z;
    r.cast = Math.min(A[1], A[1] > 0 && z > 1 ? A[0] + (((z - 1) * (A[1] - A[0])) / (A[2] - 1)) : A[0]);
    r.effects = {};
    for (var y = 0; y < 3; ++y) {
        var p = A[4 + y], s = A[7 + y], v = A[10 + y], o = r.effects[y + 1] = {};
        o.avg = p * q * (A[1] > 0 ? r.cast / A[1] : 1);
        o.min = Math.round(o.avg) - Math.floor(o.avg * s / 2);
        o.max = Math.round(o.avg) + Math.floor(o.avg * s / 2);
        o.pts = Math.round(v * q);
        o.avg = Math.max(Math.ceil(p), Math.round(o.avg))
    }
    r.cast = Math.round(r.cast / 10) / 100;
    return r
};
if (!$WH.wowheadRemote) {
    $WH.g_ajaxIshRequest(baseUrl+"assets/frontend/js/spell-scaling.js")
}
$WH.g_getDataSource = function () {
    if ($WH.isset("g_pageInfo")) {
        switch (g_pageInfo.type) {
            case 3:
                if ($WH.isset("g_items")) {
                    return g_items
                }
            case 6:
                if ($WH.isset("g_spells")) {
                    return g_spells
                }
        }
    }
    return []
};
$WH.g_setJsonItemLevel = function (p, B) {
    if (!p.scadist || !p.scaflags) {
        return
    }
    p.bonuses = p.bonuses || {};
    var w = p.scaflags & 255, u = (p.scaflags >> 8) & 255, r = (p.scaflags & (1 << 16)) != 0, s = (p.scaflags & (1 << 17)) != 0, C = (p.scaflags & (1 << 18)) != 0, z;
    switch (w) {
        case 5:
        case 1:
        case 7:
        case 17:
            z = 7;
            break;
        case 3:
        case 12:
            z = 8;
            break;
        case 16:
        case 11:
            z = 9;
            break;
        case 15:
            z = 10;
            break;
        case 23:
        case 21:
        case 22:
        case 13:
            z = 11;
            break;
        default:
            z = -1
    }
    if (z >= 0) {
        for (var y = 0; y < 10; ++y) {
            var q = $WH.g_convertScalingFactor(B, z, p.scadist, y, 1);
            if (q.n) {
                p[q.n] = q.v
            }
            p.bonuses[q.s] = q.v
        }
    }
    if (C) {
        p.splpwr = p.bonuses[45] = $WH.g_convertScalingFactor(B, 6)
    }
    if (r) {
        switch (w) {
            case 3:
                p.armor = $WH.g_convertScalingFactor(B, 11 + u);
                break;
            case 5:
                p.armor = $WH.g_convertScalingFactor(B, 15 + u);
                break;
            case 1:
                p.armor = $WH.g_convertScalingFactor(B, 19 + u);
                break;
            case 7:
                p.armor = $WH.g_convertScalingFactor(B, 23 + u);
                break;
            case 16:
                p.armor = $WH.g_convertScalingFactor(B, 28);
                break;
            default:
                p.armor = 0
        }
    }
    if (s) {
        var t = (p.mledps ? "mle" : "rgd"), v;
        switch (w) {
            case 23:
            case 21:
            case 22:
            case 13:
                p.dps = p[t + "dps"] = $WH.g_convertScalingFactor(B, C ? 2 : 0);
                v = 0.3;
                break;
            case 17:
                p.dps = p[t + "dps"] = $WH.g_convertScalingFactor(B, C ? 3 : 1);
                v = 0.2;
                break;
            case 15:
                p.dps = p[t + "dps"] = $WH.g_convertScalingFactor(B, u == 19 ? 5 : 4);
                v = 0.3;
                break;
            default:
                p.dps = p[t + "dps"] = 0;
                v = 0
        }
        p.dmgmin = p[t + "dmgmin"] = Math.floor(p.dps * p.speed * (1 - v));
        p.dmgmax = p[t + "dmgmax"] = Math.floor(p.dps * p.speed * (1 + v))
    }
    if (p.gearscore != null) {
        if (p._gearscore == null) {
            p._gearscore = p.gearscore
        }
        var A = Math.min(85, B + 1);
        if (A >= 70) {
            n = ((A - 70) * 9.5) + 105
        } else {
            if (A >= 60) {
                n = ((A - 60) * 4.5) + 60
            } else {
                n = A + 5
            }
        }
        p.gearscore = (p._gearscore * n) / 1.8
    }
};
$WH.g_setJsonSpellLevel = function (d, c) {
    if (!d.scadist) {
        return
    }
    $WH.cO(d, $WH.g_convertScalingSpell(c, d.scadist))
};
$WH.g_getJsonReforge = function (j, k, g) {
    var h = {
        amount: 0,
        s1: $WH.g_statToJson[$WH.g_individualToGlobalStat[k] || k],
        s2: $WH.g_statToJson[$WH.g_individualToGlobalStat[g] || g]
    };
    for (var f in j) {
        if ($WH.g_jsonToStat[f] == k || $WH.g_individualToGlobalStat[$WH.g_jsonToStat[f]] == k) {
            h.amount = Math.floor(j[f] * 0.4);
            break
        }
    }
    return h
};
$WH.g_setTooltipLevel = function (r, y, m) {
    var q = typeof r;
    if (q == "number") {
        var t = $WH.g_getDataSource();
        if (t[r] && t[r][(m ? "buff_" : "tooltip_") + Locale.getName()]) {
            r = t[r][(m ? "buff_" : "tooltip_") + Locale.getName()]
        } else {
            return r
        }
    } else {
        if (q != "string") {
            return r
        }
    }
    q = r.match(/<!--\?([0-9:]*)-->/);
    if (!q) {
        return r
    }
    q = q[1].split(":");
    var y = Math.min(parseInt(q[2]), Math.max(parseInt(q[1]), y)), w = parseInt(q[4]) || 0;
    if (w) {
        if (!r.match(/<!--pts[0-9](:[0-9])?-->/g)) {
            var o = parseInt(q[5]) || 0, v = r.match(/<!--spd-->(\d\.\d+)/);
            if (v) {
                v = parseFloat(v[1]) || 0
            }
            var p = {scadist: w, scaflags: o, speed: v};
            $WH.g_setJsonItemLevel(p, y);
            r = r.replace(/(<!--asc(\d+)-->)([^<]+)/, function (b, a, c) {
                q = c;
                if (y < 40 && (c == 3 || c == 4)) {
                    --q
                }
                return a + g_itemset_types[q]
            });
            r = r.replace(/(<!--dmg-->)\d+(\D+)\d+/, function (b, a, c) {
                return a + p.dmgmin + c + p.dmgmax
            });
            r = r.replace(/(<!--dps-->\D*?)(\d+\.\d)/, function (b, a) {
                return a + p.dps.toFixed(1)
            });
            r = r.replace(/(<!--amr-->)\d+/, function (b, a) {
                return a + p.armor
            });
            r = r.replace(/<span><!--stat(\d+)-->[-+]\d+(\D*?)<\/span>(<!--e-->)?(<!--ps-->)?(<br ?\/?>)?/gi, function (e, h, a, c, b, g) {
                var f, d = p.bonuses[h];
                if (d) {
                    d = (d > 0 ? "+" : "-") + d;
                    f = "";
                    g = (g ? "<br />" : "")
                } else {
                    d = "+0";
                    f = ' style="display: none"';
                    g = (g ? "<!--br-->" : "")
                }
                return "<span" + f + "><!--stat" + h + "-->" + d + a + "</span>" + (c || "") + (b || "") + g
            });
            r = r.replace(/<span class="q2">(.*?)<!--rtg(\d+)-->\d+(.*?)<\/span>(<br \/>)?/gi, function (e, b, j, g, a, d, f) {
                var c, h = p.bonuses[$WH.g_individualToGlobalStat[j] || j];
                if (h) {
                    c = "";
                    f = (f ? "<br />" : "")
                } else {
                    c = ' style="display: none"';
                    f = (f ? "<!--br-->" : "")
                }
                return '<span class="q2"' + c + ">" + b + "<!--rtg" + j + "-->" + h + g + "</span>" + f
            })
        } else {
            var p = {scadist: w};
            $WH.g_setJsonSpellLevel(p, y);
            r = r.replace(/<!--cast-->\d+\.\d+/, "<!--cast-->" + p.cast);
            if (p.effects) {
                for (var u = 1; u < 4; ++u) {
                    var s = p.effects[u];
                    r = r.replace(new RegExp("<!--pts" + u + "(:0)?-->(.+?)<", "g"), "<!--pts" + u + "$1-->" + (s.min == s.max ? s.avg : s.min + " to " + s.max) + "<");
                    r = r.replace(new RegExp("<!--pts" + u + ":1-->(.+?)<", "g"), "<!--pts" + u + ":1-->" + s.min + "<");
                    r = r.replace(new RegExp("<!--pts" + u + ":2-->(.+?)<", "g"), "<!--pts" + u + ":2-->" + s.max + "<");
                    r = r.replace(new RegExp("<!--pts" + u + ":3:(\\d+)-->(.+?)<", "g"), function (b, a) {
                        return "<!--pts" + u + ":3:" + a + "-->" + (s.avg * a) + "<"
                    });
                    r = r.replace(new RegExp("<!--pts" + u + ":4-->(.+?)<", "g"), "<!--pts" + u + ":4-->" + s.pts + "<")
                }
            }
        }
    }
    r = r.replace(/(<!--rtg%(\d+)-->)([\.0-9]+)/g, function (c, a, b, d) {
        q = r.match(new RegExp("<!--rtg" + b + "-->(\\d+)"));
        if (!q) {
            return c
        }
        return a + Math.round($WH.g_convertRatingToPercent(y, b, q[1]) * 100) / 100
    });
    r = r.replace(/(<!--\?\d+:\d+:\d+:)\d+/, "$1" + y);
    r = r.replace(/<!--lvl-->\d+/g, "<!--lvl-->" + y);
    return r
};
$WH.g_setTooltipSpells = function (o, r, p, t) {
    var l = {}, m = "<!--sp([0-9]+):[01]-->.+?<!--sp\\1-->", s;
    if (r == null) {
        r = []
    }
    if (t == null) {
        t = {}
    }
    for (var u = 0; u < r.length; ++u) {
        l[r[u]] = 1
    }
    if (s = o.match(new RegExp(m, "g"))) {
        for (var u = 0; u < s.length; ++u) {
            var v = s[u].match(m)[1];
            l[v] = (l[v] | 0);
            if (t[v] == null) {
                t[v] = -1
            }
            t[v]++;
            if (p[v] == null || p[v][t[v]] == null || p[v][t[v]][l[v]] == null) {
                continue
            }
            var q = p[v][t[v]][l[v]];
            if (!q.match(m)) {
                q = '<a href="/armory/spell/' + v + '" class="q1 tip">' + q + "</a>"
            } else {
                q = $WH.g_setTooltipSpells(q, r, p, t)
            }
            o = o.replace(s[u], "<!--sp" + v + ":" + l[v] + "-->" + q + "<!--sp" + v + "-->")
        }
    }
    return o
};
$WH.g_enhanceTooltip = function (u, r, t, z, p, q, y) {
    var s = typeof u, A;
    if (s == "number") {
        var v = $WH.g_getDataSource(), C = u;
        if (v[C] && v[C][(p ? "buff_" : "tooltip_") + Locale.getName()]) {
            u = v[C][(p ? "buff_" : "tooltip_") + Locale.getName()];
            A = v[C][(p ? "buff" : "") + "spells_" + Locale.getName()];
            if (A) {
                u = $WH.g_setTooltipSpells(u, q, A)
            }
        } else {
            return u
        }
    } else {
        if (s != "string") {
            return u
        }
    }
    if (t) {
        var B = $WH.g_getGets();
        if (B.lvl) {
            u = $WH.g_setTooltipLevel(u, B.lvl, p)
        }
    }
    if (r) {
        u = u.replace(/<span class="q2"><!--addamr(\d+)--><span>.*?<\/span><\/span>/i, function (b, a) {
            return '<span class="q2 tip" onmouseover="$WH.Tooltip.showAtCursor(event, $WH.sprintf(LANG.tooltip_armorbonus, ' + a + '), 0, 0, \'q\')" onmousemove="$WH.Tooltip.cursorUpdate(event)" onmouseout="$WH.Tooltip.hide()">' + b + "</span>"
        });
        u = u.replace(/\(([^\)]*?<!--lvl-->[^\(]*?)\)/gi, function (a, b) {
            return '(<a href="javascript:;" onmousedown="return false" class="tip" style="color: white; cursor: pointer" onclick="$WH.g_staticTooltipLevelClick(this, null, 0)" onmouseover="$WH.Tooltip.showAtCursor(event, \'<span class=\\\'q2\\\'>\' + LANG.tooltip_changelevel + \'</span>\')" onmousemove="$WH.Tooltip.cursorUpdate(event)" onmouseout="$WH.Tooltip.hide()">' + b + "</a>)"
        })
    }
    if (z && Slider) {
        if (p && p.slider) {
            p.bufftip = this
        } else {
            var s = u.match(/<!--\?(\d+):(\d+):(\d+):(\d+)/);
            if (s && s[2] != s[3]) {
                this.slider = Slider.init(z, {
                    minValue: parseInt(s[2]),
                    maxValue: parseInt(s[3]),
                    onMove: $WH.g_tooltipSliderMove.bind(this)
                });
                Slider.setValue(this.slider, parseInt(s[4]));
                this.slider.onmouseover = function (a) {
                    $WH.Tooltip.showAtCursor(a, LANG.tooltip_changelevel2, 0, 0, "q2")
                };
                this.slider.onmousemove = $WH.Tooltip.cursorUpdate;
                this.slider.onmouseout = $WH.Tooltip.hide
            }
        }
    }
    if (y) {
        if (p && p.modified) {
            p.bufftip = this
        } else {
            for (var w in A) {
                if (!g_spells[w]) {
                    continue
                }
                $(y).append('<input type="checkbox" id="known-' + w + '" />').append('<label for="known-' + w + '"><a rel="spell=' + w + '">' + g_spells[w]["name_" + Locale.getName()] + (g_spells[w]["rank_" + Locale.getName()] ? " (" + g_spells[w]["rank_" + Locale.getName()] + ")" : "") + "</a></label>").append("<br />");
                $("#known-" + w).change($WH.g_tooltipSpellsChange.bind(this))
            }
        }
        this.modified = [y, A, q];
        $(y).toggle(!$(y).is(":empty"))
    }
    return u
};
$WH.g_staticTooltipLevelClick = function (u, v, p, m) {
    while (u.className.indexOf("tooltip") == -1) {
        u = u.parentNode
    }
    var o = u.innerHTML;
    o = o.match(/<!--\?(\d+):(\d+):(\d+):(\d+)/);
    if (!o) {
        return
    }
    var l = parseInt(o[1]), r = parseInt(o[2]), q = parseInt(o[3]), s = parseInt(o[4]);
    if (r >= q) {
        return
    }
    if (!v) {
        v = prompt($WH.sprintf(LANG.prompt_ratinglevel, r, q), s)
    }
    v = parseInt(v);
    if (isNaN(v)) {
        return
    }
    if (v == s || v < r || v > q) {
        return
    }
    var t = $WH.g_getDataSource();
    o = $WH.g_setTooltipLevel(t[l][(m ? "buff_" : "tooltip_") + Locale.getName()], v, m);
    o = $WH.g_enhanceTooltip(o, true);
    u.innerHTML = o;
    $WH.Tooltip.fixSafe(u, 1, 1);
    if (u.slider && !p) {
        Slider.setValue(u.slider, v)
    }
    if (!m) {
        ($WH.g_tooltipSpellsChange.bind(u))()
    }
};
$WH.g_tooltipSliderMove = function (f, d, e) {
    $WH.g_staticTooltipLevelClick(this, e.value, 1);
    if (this.bufftip) {
        $WH.g_staticTooltipLevelClick(this.bufftip, e.value, 1, 1)
    }
    $WH.Tooltip.hide()
};
$WH.g_tooltipSpellsChange = function () {
    if (!this.modified) {
        return
    }
    var f = this.modified[0], e = this.modified[1], d = [];
    $.each($("input:checked", f), function (b, a) {
        d.push(parseInt(a.id.replace("known-", "")))
    });
    this.modified[2] = d;
    this.innerHTML = $WH.g_setTooltipSpells(this.innerHTML, d, e);
    if (this.bufftip) {
        ($WH.g_tooltipSpellsChange.bind(this.bufftip))()
    }
};
$WH.Tooltip = {
    create: function (s, q) {
        var u = $WH.ce("div"), d = $WH.ce("table"), z = $WH.ce("tbody"), v = $WH.ce("tr"), y = $WH.ce("tr"), A = $WH.ce("td"), p = $WH.ce("th"), r = $WH.ce("th"), t = $WH.ce("th");
        u.className = "wowhead-tooltip";
        if (s) {
            A.innerHTML = s
        }
        $WH.ae(v, A);
        $WH.ae(v, p);
        $WH.ae(z, v);
        $WH.ae(y, r);
        $WH.ae(y, t);
        $WH.ae(z, y);
        $WH.ae(d, z);
        if (!q) {
            $WH.Tooltip.icon = $WH.ce("p");
            $WH.Tooltip.icon.style.visibility = "hidden";
            $WH.ae($WH.Tooltip.icon, $WH.ce("div"));
            $WH.ae(u, $WH.Tooltip.icon)
        }
        $WH.ae(u, d);
        if (!q) {
            var w = $WH.ce("div");
            w.className = "wowhead-tooltip-powered";
            $WH.ae(u, w);
            $WH.Tooltip.logo = w
        }
        return u
    }, getMultiPartHtml: function (c, d) {
        return "<table><tr><td>" + c + "</td></tr></table><table><tr><td>" + d + "</td></tr></table>"
    }, fix: function (p, c, m) {
        var o = $WH.gE(p, "table")[0], k = $WH.gE(o, "td")[0], l = k.childNodes;
        p.className = $WH.trim(p.className.replace("tooltip-slider", ""));
        if (l.length >= 2 && l[0].nodeName == "TABLE" && l[1].nodeName == "TABLE") {
            l[0].style.whiteSpace = "nowrap";
            var j = parseInt(p.style.width);
            if (!p.slider || !j) {
                if (l[1].offsetWidth > 300) {
                    j = Math.max(300, l[0].offsetWidth) + 20
                } else {
                    j = Math.max(l[0].offsetWidth, l[1].offsetWidth) + 20
                }
            }
            j = Math.min(320, j);
            if (j > 20) {
                p.style.width = j + "px";
                l[0].style.width = l[1].style.width = "100%";
                if (p.slider) {
                    Slider.setSize(p.slider, j - 6);
                    p.className += " tooltip-slider"
                }
                if (!c && p.offsetHeight > document.body.clientHeight) {
                    o.className = "shrink"
                }
            }
        }
        if (m) {
            p.style.visibility = "visible"
        }
    }, fixSafe: function (f, d, e) {
        $WH.Tooltip.fix(f, d, e)
    }, append: function (f, d) {
        var f = $WH.ge(f);
        var e = $WH.Tooltip.create(d);
        $WH.ae(f, e);
        $WH.Tooltip.fixSafe(e, 1, 1)
    }, prepare: function () {
        if ($WH.Tooltip.tooltip) {
            return
        }
        var b = $WH.Tooltip.create();
        b.style.position = "absolute";
        b.style.left = b.style.top = "-2323px";
        $WH.ae(document.body, b);
        $WH.Tooltip.tooltip = b;
        $WH.Tooltip.tooltipTable = $WH.gE(b, "table")[0];
        $WH.Tooltip.tooltipTd = $WH.gE(b, "td")[0];
        var b = $WH.Tooltip.create(null, true);
        b.style.position = "absolute";
        b.style.left = b.style.top = "-2323px";
        $WH.ae(document.body, b);
        $WH.Tooltip.tooltip2 = b;
        $WH.Tooltip.tooltipTable2 = $WH.gE(b, "table")[0];
        $WH.Tooltip.tooltipTd2 = $WH.gE(b, "td")[0]
    }, set: function (f, d) {
        var e = $WH.Tooltip.tooltip;
        e.style.width = "550px";
        e.style.left = "-2323px";
        e.style.top = "-2323px";
        if (f.nodeName) {
            $WH.ee($WH.Tooltip.tooltipTd);
            $WH.ae($WH.Tooltip.tooltipTd, f)
        } else {
            $WH.Tooltip.tooltipTd.innerHTML = f
        }
        e.style.display = "";
        $WH.Tooltip.fix(e, 0, 0);
        if (d) {
            $WH.Tooltip.showSecondary = true;
            var e = $WH.Tooltip.tooltip2;
            e.style.width = "550px";
            e.style.left = "-2323px";
            e.style.top = "-2323px";
            if (d.nodeName) {
                $WH.ee($WH.Tooltip.tooltipTd2);
                $WH.ae($WH.Tooltip.tooltipTd2, d)
            } else {
                $WH.Tooltip.tooltipTd2.innerHTML = d
            }
            e.style.display = "";
            $WH.Tooltip.fix(e, 0, 0)
        } else {
            $WH.Tooltip.showSecondary = false
        }
    }, moveTests: [[null, null], [null, false], [false, null], [false, false]], move: function (u, v, F, t, G, I) {
        if (!$WH.Tooltip.tooltipTable) {
            return
        }
        var w = $WH.Tooltip.tooltip, B = $WH.Tooltip.tooltipTable.offsetWidth, H = $WH.Tooltip.tooltipTable.offsetHeight, z = $WH.Tooltip.tooltip2, D = $WH.Tooltip.showSecondary ? $WH.Tooltip.tooltipTable2.offsetWidth : 0, J = $WH.Tooltip.showSecondary ? $WH.Tooltip.tooltipTable2.offsetHeight : 0, K;
        w.style.width = B + "px";
        z.style.width = D + "px";
        var y, E;
        for (var C = 0, A = $WH.Tooltip.moveTests.length; C < A; ++C) {
            K = $WH.Tooltip.moveTests[C];
            y = $WH.Tooltip.moveTest(u, v, F, t, G, I, K[0], K[1]);
            if ($WH.isset("Ads") && !Ads.intersect(y)) {
                E = true;
                break
            } else {
                if (!$WH.isset("Ads")) {
                    break
                }
            }
        }
        if ($WH.isset("Ads") && !E) {
            Ads.intersect(y, true)
        }
        w.style.left = y.l + "px";
        w.style.top = y.t + "px";
        w.style.visibility = "visible";
        if ($WH.Tooltip.showSecondary) {
            z.style.left = y.l + B + "px";
            z.style.top = y.t + "px";
            z.style.visibility = "visible"
        }
    }, moveTest: function (Y, Q, L, K, aa, ac, N, ab) {
        var R = Y, O = Q, W = $WH.Tooltip.tooltip, T = $WH.Tooltip.tooltipTable.offsetWidth, I = $WH.Tooltip.tooltipTable.offsetHeight, P = $WH.Tooltip.tooltip2, M = $WH.Tooltip.showSecondary ? $WH.Tooltip.tooltipTable2.offsetWidth : 0, X = $WH.Tooltip.showSecondary ? $WH.Tooltip.tooltipTable2.offsetHeight : 0, U = $WH.g_getWindowSize(), S = $WH.g_getScroll(), V = U.w, J = U.h, Z = S.x, D = S.y, E = Z, F = D, G = Z + V, H = D + J;
        if (N == null) {
            N = (Y + L + T + M <= G)
        }
        if (ab == null) {
            ab = (Q - Math.max(I, X) >= F)
        }
        if (N) {
            Y += L + aa
        } else {
            Y = Math.max(Y - (T + M), E) - aa
        }
        if (ab) {
            Q -= Math.max(I, X) + ac
        } else {
            Q += K + ac
        }
        if (Y < E) {
            Y = E
        } else {
            if (Y + T + M > G) {
                Y = G - (T + M)
            }
        }
        if (Q < F) {
            Q = F
        } else {
            if (Q + Math.max(I, X) > H) {
                Q = Math.max(D, H - Math.max(I, X))
            }
        }
        if ($WH.Tooltip.iconVisible) {
            if (R >= Y - 48 && R <= Y && O >= Q - 4 && O <= Q + 48) {
                Q -= 48 - (O - Q)
            }
        }
        return $WH.g_createRect(Y, Q, T, I)
    }, show: function (k, l, o, h, p, m) {
        if ($WH.Tooltip.disabled) {
            return
        }
        if (!o || o < 1) {
            o = 1
        }
        if (!h || h < 1) {
            h = 1
        }
        if (p) {
            l = '<span class="' + p + '">' + l + "</span>"
        }
        var j = $WH.ac(k);
        $WH.Tooltip.prepare();
        $WH.Tooltip.set(l, m);
        $WH.Tooltip.move(j.x, j.y, k.offsetWidth, k.offsetHeight, o, h)
    }, showAtCursor: function (m, l, p, j, e, o) {
        if ($WH.Tooltip.disabled) {
            return
        }
        if (!p || p < 10) {
            p = 10
        }
        if (!j || j < 10) {
            j = 10
        }
        if (e) {
            l = '<span class="' + e + '">' + l + "</span>";
            if (o) {
                o = '<span class="' + e + '">' + o + "</span>"
            }
        }
        m = $WH.$E(m);
        var k = $WH.g_getCursorPos(m);
        $WH.Tooltip.prepare();
        $WH.Tooltip.set(l, o);
        $WH.Tooltip.move(k.x, k.y, 0, 0, p, j)
    }, showAtXY: function (k, h, j, m, g, l) {
        if ($WH.Tooltip.disabled) {
            return
        }
        $WH.Tooltip.prepare();
        $WH.Tooltip.set(k, l);
        $WH.Tooltip.move(h, j, 0, 0, m, g)
    }, cursorUpdate: function (e, f, g) {
        if ($WH.Tooltip.disabled || !$WH.Tooltip.tooltip) {
            return
        }
        e = $WH.$E(e);
        if (!f || f < 10) {
            f = 10
        }
        if (!g || g < 10) {
            g = 10
        }
        var h = $WH.g_getCursorPos(e);
        $WH.Tooltip.move(h.x, h.y, 0, 0, f, g)
    }, hide: function () {
        if ($WH.Tooltip.tooltip) {
            $WH.Tooltip.tooltip.style.display = "none";
            $WH.Tooltip.tooltip.visibility = "hidden";
            $WH.Tooltip.tooltipTable.className = "";
            $WH.Tooltip.setIcon(null);
            if ($WH.isset("Ads")) {
                Ads.restoreHidden()
            }
        }
        if ($WH.Tooltip.tooltip2) {
            $WH.Tooltip.tooltip2.style.display = "none";
            $WH.Tooltip.tooltip2.visibility = "hidden";
            $WH.Tooltip.tooltipTable2.className = ""
        }
    }, setIcon: function (b) {
        $WH.Tooltip.prepare();
        if (b) {
            $WH.Tooltip.icon.style.backgroundImage = "url(http://atlantiss.pl/images/wow/icons/medium/" + b.toLowerCase() + ".jpg)";
            $WH.Tooltip.icon.style.visibility = "visible"
        } else {
            $WH.Tooltip.icon.style.backgroundImage = "none";
            $WH.Tooltip.icon.style.visibility = "hidden"
        }
        $WH.Tooltip.iconVisible = b ? 1 : 0
    }
};
if ($WH.isset("$WowdbPower")) {
    $WowdbPower.init()
}
;