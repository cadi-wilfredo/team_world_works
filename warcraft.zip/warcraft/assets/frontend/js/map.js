(function(e,t,n){function f(e){e=e||location.href;return"#"+e.replace(/^[^#]*#?(.*)$/,"$1")}var r="hashchange",i=document,s,o=e.event.special,u=i.documentMode,a="on"+r in t&&(u===n||u>7);e.fn[r]=function(e){return e?this.bind(r,e):this.trigger(r)};e.fn[r].delay=50;o[r]=e.extend(o[r],{setup:function(){if(a){return false}e(s.start)},teardown:function(){if(a){return false}e(s.stop)}});s=function(){function h(){var n=f(),i=l(o);if(n!==o){a(o=n,i);e(t).trigger(r)}else{if(i!==o){location.href=location.href.replace(/#.*/,"")+i}}s=setTimeout(h,e.fn[r].delay)}var i={},s,o=f(),u=function(e){return e},a=u,l=u;i.start=function(){s||h()};i.stop=function(){s&&clearTimeout(s);s=n};return i}()})(jQuery,this);

function WoWMap() {
    this.images = {};
    if (!$('#map-tip').lenght) {
        $('body').append(
            $('<div class="wowhead-tooltip" id="map-tip" style="position: absolute; min-width: 250px; max-width: 300px; visibility: visible; display: none;"></div>')
        );
    }
    this.data = {};
    this.currentNode = null;

    this.stage = new Kinetic.Stage({
        container: 'map-section',
        width: 690,
        height: 880
    });

    this.FillFilters();
}

WoWMap.prototype.FillFilters = function() {
    this.filterList = [];
    var s = this;
    var i = 0;
    $('#map-filters input[type="checkbox"]:checked').each(function() {
        s.filterList[i] = parseInt($(this).val());
        ++i;
    });
};

WoWMap.prototype.UpdateFilters = function() {
    this.FillFilters();
    var x = this.AddMapImage;
    this.loadMapImage(this.lastMap, x);
};

WoWMap.prototype.loadData = function(data) {
    this.data = data;
};

WoWMap.prototype.loadMapImage = function(type, callback) {
    this.currentType = type;
    this.loadImage(type, callback);
};

WoWMap.prototype.loadImage = function(type, callback, id) {
    var s = this;
    this.currentType = type;
    var src = baseUrl+'assets/frontend/images/' + type + '.png';
    if (s.images[type]) {
        callback.call(s, type, id);
    } else {
        s.images[type] = new Image();
        s.images[type].onload = function() {
            callback.call(s, type, id);
        };
        s.images[type].src = src;
    }
};

WoWMap.prototype.GenMarkTooltip = function(name, dtip) {
    var text = '<table style="white-space: nowrap; width: 100%;"><tbody><tr>';
    text += '<td>';
    text += '<b class="q">' + name + '</b>';
    if (dtip.lvl.min > 0) {
        text += '<br><span class="q1">Level: ' + dtip.lvl.min;
        if (dtip.lvl.min !== dtip.lvl.max)
            text += ' - ' + dtip.lvl.max;
        text += '</span>';
    }
    text += '</td>';
    text += '<th>';
    if (dtip.icon)
        text += '<img src="'+baseUrl+'assets/frontend/images/' + dtip.icon + '.png">';
    text += '</th>';
    text += '</tr></tbody></table>';

    if (dtip.desc !== '') {
        text += '<table style="width: 100%;"><tbody><tr>';
        text += '<td class="left" style="text-align:justify;font-size:11px"><br>' + dtip.desc + '</td></tr>';
        text += '</tr></tbody></table>';
    }

    return this.SimplyTip(text);
};

WoWMap.prototype.GenTooltip = function(name, dtip) {
    var text = '<table style="white-space: nowrap; width: 100%;"><tbody><tr>';
    text += '<td>';
    text += '<b class="q">' + name + '</b>';
    text += '<br><span class="q1">Level: ' + dtip.lvl.min;
    if (dtip.lvl.min !== dtip.lvl.max)
        text += ' - ' + dtip.lvl.max;
    text += '</span>';
    text += '</td>';
    text += '<th>';
    if (dtip.faction === 'horde' || dtip.faction === 'alliance')
        text += '<img src="'+baseUrl+'assets/frontend/images/' + dtip.faction + '.png">';
    text += '</th>';
    text += '</tr></tbody></table>';

    var max = dtip['quest'][0] + dtip['quest'][1] + dtip['quest'][2];
    var work = (max > 0 ? dtip['quest'][0] * 100 / max : 0);
    var noworks = (max > 0 ? dtip['quest'][1] * 100 / max : 0);

    text += '<table style="width: 100%;"><tbody><tr>';
    text += '<td class="left"><br><span class="q1">Quests:</span>';
    text += '</td></tr>';
    text += '<tr><td><div style="margin-top:5px" class="tip-bar"><div class="tip-bar-wrapp"><div class="un"></div><div class="data-wrapp">';
    if (dtip['quest'][0] > 0)
        text += '<div class="works" style="width:' + work + '%;"><span> </span></div>';
    if (dtip['quest'][1] > 0)
        text += '<div class="noworks" style="width:' + noworks + '%;"><span> </span></div>';
    text += '</div></div></div></td>';
    text += '<tr><td style="text-align:center">';
    text += '<span style="font-size:11px;color:#3f8629">Blizzlike: ' + dtip['quest'][0] + '</span> &nbsp;';
    text += '<span style="font-size:11px" class="q10">Bugged: ' + dtip['quest'][1] + '</span> &nbsp;';
    text += '<span style="font-size:11px" class="q0">Untested: ' + dtip['quest'][2] + '</span>';
    text += '</td></tr>';
    text += '</tr></tbody></table>';

    return this.SimplyTip(text);
};

WoWMap.prototype.SimplyTip = function(val) {
    var text = '<table><tbody><tr><td>' + val + '</td><th></th></tr><tr><th></th><th></th></tr></tbody></table>';
    return text;
};

WoWMap.prototype.RelocateTooltip = function() {
    if (!this.currentPoly)
        return;
    var poly = this.currentPoly;
    var tip = $('#map-tip');

    var offset = $('#map-section').offset();
    if ($(window).width() < poly.tipPos.maxX + offset.left + tip.width() -142) {
        tip.css('left', poly.tipPos.minX + offset.left - tip.width() -142);
    } else {
        tip.css('left', poly.tipPos.maxX + offset.left -142);
    }

    var YPos = poly.tipPos.minY + offset.top;

    var pTop = offset.top - $(window).scrollTop() + poly.tipPos.minY;
    if (pTop - 10 < 0) {
        YPos -= pTop - 10;
    } else if (pTop + tip.height() + 20 > $(window).height()) {
        YPos -= tip.height();
        YPos += $(window).height() - pTop - 20;
    }

    tip.css('top', YPos);
};

WoWMap.prototype.ShowTooltip = function(poly) {
    this.currentNode = poly.name;
    this.currentPoly = poly;
    var tip = $('#map-tip');
    tip.html(poly.tip);
    this.RelocateTooltip();
    tip.stop().fadeIn(300);
};

WoWMap.prototype.HideTooltip = function(poly) {
    if (!this.currentNode || !poly || this.currentNode === poly.name) {
        $('#map-tip').stop().hide();
        this.currentNode = null;
        this.currentPoly = null;
    }
};

WoWMap.prototype.AddMapImage = function(img) {
    this.mapImage = this.images[img];
    if (this.layer) {
        this.layer.destroy();
        $('#map-tip').hide();
        this.currentNode = null;
    }
    this.layer = new Kinetic.Layer();
    this.baseImage = new Kinetic.Image({
        x: 0,
        y: 0,
        image: this.mapImage,
        width: this.mapImage.width,
        height: this.mapImage.height
    });

    this.layer.add(this.baseImage);
    this.stage.add(this.layer);

    this.baseImage.cache();

    this.baseImage.filters([Kinetic.Filters.Brighten]);
    //this.baseImage.filters([Kinetic.Filters.Grayscale, Kinetic.Filters.Brighten, Kinetic.Filters.Sepia]);
    this.baseImage.brightness(-0.1);
    var s = this;
    this.baseImage.on('mouseout touchend mouseover touchstart', function() {
        document.body.style.cursor = 'default';
        s.HideTooltip(null);
    });

    this.layer.draw();
    var cdata = this.data[this.currentType];
    $('#map-name').html(cdata.name);

    for (var i in cdata.points) {
        this.generatePoly(cdata.points[i]);
    }

    var h = this.addMark;
    for (var i in cdata.marks) {
        if ($.inArray( cdata.marks[i].filter, this.filterList) === -1)
            continue;
        this.loadImage('' + cdata.marks[i].type, h, cdata.marks[i]);
    }
};

WoWMap.prototype.addMark = function(type, data) {
    var cx = data.points[0], cy = data.points[1];
    var s = this;
    var poly = new Kinetic.Image({
        x: cx,
        y: cy,
        image: this.images[type],
        width: 16,
        height: 16
    });

    var tip = {};
    tip.desc = data.desc;
    tip.icon = data.icon;
    tip.lvl = data.lvl;
    poly.tip = this.GenMarkTooltip(data.name, tip);

    poly.tipPos = {
        minY: cy - 70,
        maxY: cy + 70,
        minX: cx - 12,
        maxX: cx + 12
    };
    poly.on('mouseover touchstart', function() {
        document.body.style.cursor = 'pointer';
        poly.brightness(-0.5);
        s.layer.draw();
        s.ShowTooltip(poly);
    });

    poly.on('mouseout touchend', function() {
        document.body.style.cursor = 'default';
        poly.brightness(-0.1);
        s.layer.draw();
        s.HideTooltip(poly);
    });

    s.layer.add(poly);
    s.layer.draw();
};

WoWMap.prototype.generatePoly = function(data) {
    var s = this;
    var poly = new Kinetic.Line({
        points: data.points,
        lineCap: 'round',
        lineJoin: 'round',
        strokeWidth: 1,
        closed: true,

        sides: 5,
        radius: 70,
    });

    s.layer.add(poly);
    s.layer.batchDraw();

    poly.tip = this.GenTooltip(data.name, data.tip);
    poly.name = data.name;
    var pos = {
        minY: 99999999999999,
        maxY: 0,
        minX: 99999999999999,
        maxX: 0
    };
    for (var i in data.points) {
        if (i % 2 || i === 0) {
            pos.minY = Math.min(pos.minY, data.points[i]);
            pos.maxY = Math.max(pos.maxY, data.points[i]);
        } else {
            pos.minX = Math.min(pos.minX, data.points[i]);
            pos.maxX = Math.max(pos.maxX, data.points[i]);
        }
    }
    poly.tipPos = pos;

    /*poly.on('click', function() {
     });*/

    poly.on('mouseover touchstart', function() {
        poly.setFillPatternImage(s.mapImage);
        poly.filters([Kinetic.Filters.Blur]);
        poly.blurRadius(40);
        document.body.style.cursor = 'pointer';
        s.layer.draw();
        s.ShowTooltip(poly);
    });

    poly.on('mouseout touchend', function() {
        poly.setFillPatternImage(null);
        document.body.style.cursor = 'default';
        s.layer.draw();
        s.HideTooltip(poly);
    });
    this.stage.add(s.layer);
};

WoWMap.prototype.ChangeMap = function(hash) {
    var map = hash.slice(1);
    if (this.lastMap === map)
        return;
    if (!this.data[map]) {
        if (this.lastMap == null) {
            location.hash = 'east';
        }
        return;
    }
    $('.map-list dd').removeClass('active');
    $('.map-list dd.' + map).addClass('active');
    this.lastMap = map;
    var x = this.AddMapImage;
    this.loadMapImage(map, x);
};

function genPoly(xOffset, yOffset, points) {
    var pPoints = '';
    for (var i in points) {
        pPoints += ', ' + Math.round(points[i][0][0] + xOffset);
        pPoints += ', ' + Math.round(points[i][0][1] + yOffset);
    }
    return pPoints;
}
