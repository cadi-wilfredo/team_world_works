if (typeof $WowdbPower == "undefined") {
    function strpos(b, c, d) {
        var a = (b + "").indexOf(c, (d || 0));
        return a === -1 ? false : a
    }

    var $WowdbPower = new function () {
        if (typeof aB === "undefined") {
            var aB = {
                tooltip_genericrating: '<span class="q2">Equip: Increases your $1 by <!--rtg$2-->$3&nbsp;<small>(<!--rtg%$2-->0&nbsp;@&nbsp;L<!--lvl-->0)</small>.</span><br />',
                tooltip_reforged: "Reforged ($1 $2 &rarr; $1 $3)",
                traits: {
                    agi: ["Agility", "Agi", "Agi"],
                    arcres: ["Arcane resistance", "Arcane Resist", "ArcR"],
                    arcsplpwr: ["Arcane spell power", "Arcane Power", "ArcP"],
                    armor: ["Armor", "Armor", "Armor"],
                    armorbonus: ["Additional armor", "Bonus Armor", "AddAr"],
                    armorpenrtng: ["Armor penetration rating", "Armor Pen", "Pen"],
                    atkpwr: ["Attack power", "AP", "AP"],
                    avgbuyout: ["Average buyout price", "Buyout", "AH"],
                    avgmoney: ["Average money contained", "Money", "Money"],
                    block: ["Block value", "Block Value", "BkVal"],
                    blockrtng: ["Block rating", "Block", "Block"],
                    buyprice: ["Buy price (coppers)", "Buy", "Buy"],
                    cooldown: ["Cooldown (seconds)", "Cooldown", "CD"],
                    critstrkrtng: ["Critical strike rating", "Crit", "Crit"],
                    defrtng: ["Defense rating", "Defense", "Def"],
                    dmg: ["Weapon damage", "Damage", "Dmg"],
                    dmgmax1: ["Maximum damage", "Max Damage", "Max"],
                    dmgmin1: ["Minimum damage", "Min Damage", "Min"],
                    dodgertng: ["Dodge rating", "Dodge", "Dodge"],
                    dps: ["Damage per second", "DPS", "DPS"],
                    dura: ["Durability", "Durability", "Dura"],
                    exprtng: ["Expertise rating", "Expertise", "Exp"],
                    feratkpwr: ["Feral attack power", "Feral AP", "FAP"],
                    firres: ["Fire resistance", "Fire Resist", "FirR"],
                    firsplpwr: ["Fire spell power", "Fire Power", "FireP"],
                    frores: ["Frost resistance", "Frost Resist", "FroR"],
                    frosplpwr: ["Frost spell power", "Frost Power", "FroP"],
                    hastertng: ["Haste rating", "Haste", "Haste"],
                    health: ["Health", "Health", "Hlth"],
                    healthrgn: ["Health regeneration", "HP5", "HP5"],
                    hitrtng: ["Hit rating", "Hit", "Hit"],
                    holres: ["Holy resistance", "Holy Resist", "HolR"],
                    holsplpwr: ["Holy spell power", "Holy Power", "HolP"],
                    "int": ["Intellect", "Int", "Int"],
                    level: ["Level", "Level", "Lvl"],
                    mana: ["Mana", "Mana", "Mana"],
                    manargn: ["Mana regeneration", "MP5", "MP5"],
                    mastrtng: ["Mastery rating", "Mastery", "Mastery"],
                    mleatkpwr: ["Melee attack power", "Melee AP", "AP"],
                    mlecritstrkrtng: ["Melee critical strike rating", "Melee Crit", "Crit"],
                    mledmgmax: ["Melee maximum damage", "Melee Max Damage", "Max"],
                    mledmgmin: ["Melee minimum damage", "Melee Min Damage", "Min"],
                    mledps: ["Melee DPS", "Melee DPS", "DPS"],
                    mlehastertng: ["Melee haste rating", "Melee Haste", "Haste"],
                    mlehitrtng: ["Melee hit rating", "Melee Hit", "Hit"],
                    mlespeed: ["Melee speed", "Melee Speed", "Speed"],
                    natres: ["Nature resistance", "Nature Resist", "NatR"],
                    natsplpwr: ["Nature spell power", "Nature Power", "NatP"],
                    nsockets: ["Number of sockets", "Sockets", "Sockt"],
                    parryrtng: ["Parry rating", "Parry", "Parry"],
                    reqarenartng: ["Required personal and team arena rating", "Req Rating", "Rating"],
                    reqlevel: ["Required level", "Req Level", "Level"],
                    reqskillrank: ["Required skill level", "Req Skill", "Skill"],
                    resirtng: ["Resilience rating", "Resilience", "Resil"],
                    rgdatkpwr: ["Ranged attack power", "Ranged AP", "RAP"],
                    rgdcritstrkrtng: ["Ranged critical strike rating", "Ranged Crit", "Crit"],
                    rgddmgmax: ["Ranged maximum damage", "Ranged Max Damage", "Max"],
                    rgddmgmin: ["Ranged minimum damage", "Ranged Min Damage", "Min"],
                    rgddps: ["Ranged DPS", "Ranged DPS", "DPS"],
                    rgdhastertng: ["Ranged haste rating", "Ranged Haste", "Haste"],
                    rgdhitrtng: ["Ranged hit rating", "Ranged Hit", "Hit"],
                    rgdspeed: ["Ranged speed", "Ranged Speed", "Speed"],
                    sellprice: ["Sale price (coppers)", "Sell", "Sell"],
                    sepbasestats: "Base stats",
                    sepdefensivestats: "Defensive stats",
                    sepgeneral: "General",
                    sepindividualstats: "Individual stats",
                    sepmisc: "Miscellaneous",
                    sepoffensivestats: "Offensive stats",
                    sepresistances: "Resistances",
                    sepweaponstats: "Weapon stats",
                    shares: ["Shadow resistance", "Shadow Resist", "ShaR"],
                    shasplpwr: ["Shadow spell power", "Shadow Power", "ShaP"],
                    speed: ["Speed", "Speed", "Speed"],
                    spi: ["Spirit", "Spi", "Spi"],
                    splcritstrkrtng: ["Spell critical strike rating", "Spell Crit", "Crit"],
                    spldmg: ["Damage done by spells", "Spell Damage", "Dmg"],
                    splheal: ["Healing done by spells", "Healing", "Heal"],
                    splpwr: ["Spell power", "Spell Power", "SP"],
                    splhastertng: ["Spell haste rating", "Spell Haste", "Haste"],
                    splhitrtng: ["Spell hit rating", "Spell Hit", "Hit"],
                    splpen: ["Spell penetration", "Spell Pen", "Pen"],
                    sta: ["Stamina", "Sta", "Sta"],
                    str: ["Strength", "Str", "Str"]
                }
            }
        }
        function ab() {
            if (a3) {
                var a = "http://";
                if (strpos(window.location.host, "atlantiss") !== false) {
                    a += window.location.host
                } else {
                    a += "atlantiss.pl"
                }
                var b = document.createElement("script");
                b.src = baseUrl+"assets/frontend/js/basic.js";
                aS.appendChild(b)
            } else {
                ad()
            }
        }

        function ad() {
            if (aQ) {
                return
            }
            aQ = true;
            $WH.aE(document, "mouseover", ao)
        }

        function aF(b) {
            var a = $WH.g_getCursorPos(b);
            aU = a.x;
            a5 = a.y
        }

        function ap(u, h) {
            if (u.nodeName != "A" && u.nodeName != "AREA") {
                return -2323
            }
            if (!u.href.length && !u.rel) {
                return
            }
            if (u.rel && u.rel.indexOf("np") != -1) {
                return
            }
            var a, q, C, f, k = {};
            a7 = k;
            var x = function (d, c, g) {
                if (c == "buff" || c == "sock" || c == "map") {
                    k[c] = true
                } else {
                    if (c == "rand" || c == "ench" || c == "lvl" || c == "c" || c == "diff") {
                        k[c] = parseInt(g)
                    } else {
                        if (c == "gems" || c == "pcs" || c == "forg" || c == "know") {
                            k[c] = g.split(":")
                        } else {
                            if (c == "who" || c == "domain") {
                                k[c] = g
                            } else {
                                if (c == "when") {
                                    k[c] = new Date(parseInt(g))
                                }
                            }
                        }
                    }
                }
            };
            var b = false;
            if (aL.applyto & 1) {
                q = 2;
                C = 3;
                b = true;
                f = u.href.match(/()\/\??(item|quest|spell|achievement|statistic|npc|object)\/([0-9]+)/);
                aH = 1
            }
            if (f == null && u.rel && aL.applyto & 2) {
                a = 0;
                q = 1;
                C = 2;
                f = u.rel.match(/(item|quest|spell|achievement|statistic|npc|object).?([0-9]+)/);
                aH = 1
            }
            u.href.replace(/([a-zA-Z]+)=?([a-zA-Z0-9:-]*)/g, x);
            if (u.rel) {
                u.rel.replace(/([a-zA-Z]+)=?([a-zA-Z0-9:-]*)/g, x)
            }
            if (k.gems && k.gems.length > 0) {
                var w;
                for (w = Math.min(3, k.gems.length - 1); w >= 0; --w) {
                    if (parseInt(k.gems[w])) {
                        break
                    }
                }
                ++w;
                if (w == 0) {
                    delete k.gems
                } else {
                    if (w < k.gems.length) {
                        k.gems = k.gems.slice(0, w)
                    }
                }
            }
            if (f) {
                var B, j = "www";
                a1 = u;
                B = $WH.g_getLocaleFromDomain(j);
                aK = j;
                if (u.href.indexOf("#") != -1 && document.location.href.indexOf(f[q] + "=" + f[C]) != -1) {
                    return
                }
                aZ = u.parentNode.className.indexOf("icon") == 0 && u.parentNode.nodeName == "DIV" ? 1 : 0;
                if (!u.onmouseout) {
                    if (aZ == 0) {
                        u.onmousemove = ai
                    }
                    u.onmouseout = au
                }
                aF(h);
                var t = $WH.g_getIdFromTypeName(f[q]), A = f[C];
                if (t != -1) {
                    a2(t, A, B, k)
                }
            }
        }

        function ao(b) {
            b = $WH.$E(b);
            var a = b._target;
            var c = 0;
            while (a != null && c < 5 && ap(a, b) == -2323) {
                a = a.parentNode;
                ++c
            }
        }

        function ai(a) {
            a = $WH.$E(a);
            aF(a);
            $WH.Tooltip.move(aU, a5, 0, 0, aW, av)
        }

        function au() {
            aY = null;
            a1 = null;
            $WH.Tooltip.hide()
        }

        function aa(b, a) {
            return (a7 && a7.buff ? "buff" : "tooltip") + (a ? a : "") + "_" + ae[b]
        }

        function z(a) {
            return (a7 && a7.buff ? "buff" : "") + "spells_" + ae[a]
        }

        function aP(c, a, d) {
            var b = aO[c][0];
            if (b[a] == null) {
                b[a] = {}
            }
            if (b[a].status == null) {
                b[a].status = {}
            }
            if (b[a].response == null) {
                b[a].response = {}
            }
            if (b[a].status[d] == null) {
                b[a].status[d] = af
            }
        }

        function a2(g, b, h, c) {
            if (!c) {
                c = {}
            }
            var a = aD(b, c);
            aY = g;
            aM = a;
            aR = h;
            a7 = c;
            aP(g, a, h);
            var d = aO[g][0];
            if (d[a].status[h] == an || d[a].status[h] == aV) {
                aE(d[a][aa(h)], d[a].icon, d[a].map, d[a][z(h)], d[a][aa(h, 2)])
            } else {
                if (d[a].status[h] == al || d[a].status[h] == aA) {
                    aE(aq.loading)
                } else {
                    aX(g, b, h, null, c)
                }
            }
        }

        function aX(h, m, d, b, g) {
            var p = aD(m, g);
            var c = aO[h][0];
            if (c[p].status[d] != af && c[p].status[d] != ay) {
                return
            }
            c[p].status[d] = al;
            if (!b) {
                c[p].timer = setTimeout(function () {
                    aC.apply(this, [h, p, d])
                }, 333)
            }
            var k = "";
            for (var j in g) {
                if (j != "rand" && j != "ench" && j != "gems" && j != "sock" && j != "diff") {
                    continue
                }
                if (typeof g[j] == "object") {
                    k += "&" + j + "=" + g[j].join(":")
                } else {
                    if (g[j] === true) {
                        k += "&" + j
                    } else {
                        k += "&" + j + "=" + g[j]
                    }
                }
            }
            var f = "http://";
            if (strpos(window.location.host, "atlantiss") !== false) {
                f += window.location.host
            } else {
                f += "atlantiss.pl"
            }
            $WH.g_ajaxIshRequest(f + "/tooltip/" + aO[h][1] + "/" + m + ".json?power" + k);
            if (ah[h] && !ah[h][d]) {
                $WH.g_ajaxIshRequest(f + ah[h].url)
            }
        }

        function aE(j, A, f, a, x) {
            if (a1 && a1._fixTooltip) {
                j = a1._fixTooltip(j, aY, aM, a1)
            }
            var c = false;
            if (!j) {
                j = aO[aY][2] + " not found :(";
                A = "inv_misc_questionmark";
                c = true
            } else {
                if (a7 != null) {
                    if (a7.forg && a7.forg.length == 2) {
                        var k = [a7.forg[0]];
                        for (var s in $WH.g_individualToGlobalStat) {
                            if ($WH.g_individualToGlobalStat[s] == k[0]) {
                                k.push(s)
                            }
                        }
                        var h;
                        if ((h = j.match(new RegExp("(<!--(stat|rtg)(" + k.join("|") + ")-->)[+-]?([0-9]+)"))) && !j.match(new RegExp("<!--(stat|rtg)" + a7.forg[1] + "-->[+-]?[0-9]+"))) {
                            var i = Math.floor(h[4] * 0.4), o = aB.traits[$WH.g_statToJson[a7.forg[1]]][0];
                            if (a7.forg[1] == 6) {
                                j = j.replace("<!--rs-->", '<span class="q2">+' + i + " " + o + "</span><br />")
                            } else {
                                j = j.replace("<!--rr-->", $WH.sprintfa(aB.tooltip_genericrating, o.toLowerCase(), a7.forg[1], i))
                            }
                            j = j.replace(h[0], h[1] + (h[4] - i));
                            j = j.replace("<!--rf-->", '<span class="q2">' + $WH.sprintfa(aB.tooltip_reforged, i, aB.traits[$WH.g_statToJson[a7.forg[0]]][2], aB.traits[$WH.g_statToJson[a7.forg[1]]][2]) + "</span><br />")
                        }
                    }
                    if (a7.pcs && a7.pcs.length) {
                        var l = aM.match(/^(\d+)/);
                        l = l[1];
                        var q = 0;
                        for (var s = 0, B = a7.pcs.length; s < B; ++s) {
                            var h;
                            if (h = j.match(new RegExp("<span><!--si([0-9]+:)*" + a7.pcs[s] + '(:[0-9]+)*--><a href="/armory/item/(\\d+)">(.+?)</a></span>'))) {
                                j = j.replace(h[0], '<span class="q8"><!--si' + a7.pcs[s] + '--><a href="/armory/item/' + h[3] + '">' + ($WH.isset("g_items") && g_items[a7.pcs[s]] ? g_items[a7.pcs[s]]["name_" + ae[aR]] : h[4]) + "</a></span>");
                                ++q
                            }
                        }
                        if (q > 0) {
                            j = j.replace("(0/", "(" + q + "/");
                            j = j.replace(new RegExp("<span>\\(([0-" + q + "])\\)", "g"), '<span class="q2">($1)')
                        }
                    }
                    if (a7.know && a7.know.length) {
                        j = $WH.g_setTooltipSpells(j, a7.know, a)
                    }
                    if (a7.lvl) {
                        j = $WH.g_setTooltipLevel(j, a7.lvl, a7.buff)
                    }
                    if (a7.who && a7.when) {
                        j = j.replace("<table><tr><td><br />", '<table><tr><td><br /><span class="q2">' + $WH.sprintf(aq.achievementcomplete, a7.who, a7.when.getMonth() + 1, a7.when.getDate(), a7.when.getFullYear()) + "</span><br /><br />");
                        j = j.replace(/class="q0"/g, 'class="r3"')
                    }
                }
            }
            if (a7.map && f && f.getMap) {
                x = f.getMap()
            }
            if (aZ == 1) {
                $WH.Tooltip.setIcon(null);
                $WH.Tooltip.show(a1, j, null, null, null, x)
            } else {
                $WH.Tooltip.setIcon(A);
                $WH.Tooltip.showAtXY(j, aU, a5, aW, av, x)
            }
        }

        function aC(c, a, d) {
            if (aY == c && aM == a && aR == d) {
                aE(aq.loading);
                var b = aO[c][0];
                b[a].timer = setTimeout(function () {
                    at.apply(this, [c, a, d])
                }, 3850)
            }
        }

        function at(c, a, d) {
            var b = aO[c][0];
            b[a].status[d] = ay;
            if (aY == c && aM == a && aR == d) {
                aE(aq.noresponse)
            }
        }

        function aD(b, a) {
            return b + (a.rand ? "r" + a.rand : "") + (a.ench ? "e" + a.ench : "") + (a.gems ? "g" + a.gems.join(",") : "") + (a.sock ? "s" : "")
        }

        var a3 = true;
        var aL = {applyto: 3}, aS = document.getElementsByTagName("head")[0], aN = true, aY, aM, aR, aK, a7, a1, aU, a5, aZ = 1, aQ = false, a4 = {}, aJ = {}, aT = {}, a0 = {}, aG = {}, a6 = {}, aI = {}, aw = {}, ag = 1, aH = 1, af = 0, al = 1, ay = 2, aV = 3, an = 4, aA = 5, ak = 1, am = 2, a8 = 3, ax = 5, aj = 6, ar = 10, az = 100, aW = 15, av = 15, aq = {
            loading: "Loading...",
            noresponse: "No response from server :(",
            achievementcomplete: "Achievement earned by $1 on $2/$3/$4"
        }, aO = {
            1: [a4, "npc", "NPC"],
            2: [aJ, "object", "Object"],
            3: [aT, "item", "Item"],
            5: [a0, "quest", "Quest"],
            6: [aG, "spell", "Spell"],
            10: [a6, "achievement", "Achievement"],
            100: [aw, "character", "Character"]
        }, ah = {3: {url: baseUrl+"assets/frontend/js/item-scaling.js"}, 6: {url: baseUrl+"assets/frontend/js/spell-scaling.js"}}, ae = {
            0: "enus",
            2: "frfr",
            3: "dede",
            6: "eses",
            7: "ruru"
        };
        if (a3) {
            var ac = {
                getId: function () {
                    return 0
                }, getName: function () {
                    return "enus"
                }
            }
        }
        this.init = function () {
            if (a3) {
                var a = "http://";
                if (strpos(window.location.host, "atlantiss") !== false) {
                    a += window.location.host
                } else {
                    a += "atlantiss.pl"
                }
                $WH.ae(aS, $WH.ce("link", {type: "text/css", href:  baseUrl+"assets/frontend/css/basic.css", rel: "stylesheet"}))
            }
            ad()
        };
        this.loadScales = function (d, b) {
            var f = aO[d][0];
            for (var c in ae) {
                if (b == c || !b && !isNaN(c)) {
                    ah[d][c] = 1;
                    for (var a in f) {
                        if (f[a].status[c] == aA && f[a].response[c]) {
                            f[a].response[c]()
                        }
                    }
                }
            }
        };
        this.register = function (d, b, f, c) {
            var a = aO[d][0];
            aP(d, b, f);
            if (ah[d] && !ah[d][f]) {
                a[b].status[f] = aA;
                a[b].response[f] = this.register.bind(this, d, b, f, c);
                return
            }
            if (a[b].timer) {
                clearTimeout(a[b].timer);
                a[b].timer = null
            }
            if (c.map) {
                if (a[b].map == null) {
                    a[b].map = new Mapper({parent: $WH.ce("div"), zoom: 3, zoomable: false, buttons: false})
                }
                a[b].map.update(c.map);
                delete c.map
            }
            $WH.cO(a[b], c);
            if (a[b].status[f] == al || a[b].status[f] == aA) {
                if (a[b][aa(f)]) {
                    a[b].status[f] = an
                } else {
                    a[b].status[f] = aV
                }
            }
            if (aY == d && b == aM && aR == f) {
                aE(a[b][aa(f)], a[b].icon, a[b].map, a[b][z(f)], a[b][aa(f, 2)])
            }
        };
        this.registerNpc = function (b, a, c) {
            this.register(ak, b, a, c)
        };
        this.registerObject = function (b, a, c) {
            this.register(am, b, a, c)
        };
        this.registerItem = function (b, a, c) {
            this.register(a8, b, a, c)
        };
        this.registerQuest = function (b, a, c) {
            this.register(ax, b, a, c)
        };
        this.registerSpell = function (b, a, c) {
            this.register(aj, b, a, c)
        };
        this.registerAchievement = function (b, a, c) {
            this.register(ar, b, a, c)
        };
        this.registerCharacter = function (b, a, c) {
            this.register(az, b, a, c)
        };
        this.request = function (d, b, f, c) {
            if (!c) {
                c = {}
            }
            var a = aD(b, c);
            aP(d, a, f);
            aX(d, b, f, 1, c)
        };
        this.requestItem = function (b, a) {
            this.request(a8, b, ac.getId(), a)
        };
        this.requestSpell = function (a) {
            this.request(aj, a, ac.getId())
        };
        this.getStatus = function (c, a, d) {
            var b = aO[c][0];
            if (b[a] !== null) {
                return b[a].status[d]
            } else {
                return af
            }
        };
        this.getItemStatus = function (b, a) {
            this.getStatus(a8, b, a)
        };
        this.getSpellStatus = function (b, a) {
            this.getStatus(aj, b, a)
        };
        if (a3) {
            this.set = function (a) {
                $WH.cO(aL, a)
            };
            this.showTooltip = function (b, a, c) {
                aF(b);
                aE(a, c)
            };
            this.hideTooltip = function () {
                $WH.Tooltip.hide()
            };
            this.moveTooltip = function (a) {
                ai(a)
            }
        }
        ab()
    }
}
;