<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('users', '', TRUE);
        $this->load->library(array('session'));
    }

    public function index()
    {
        if ($this->input->post('token', TRUE) &&
            $this->input->post('email', TRUE) &&
            $this->input->post('password', TRUE) &&
            $this->input->post('token', TRUE) == $this->session->userdata('token')
        ) {
            $user = $this->users->find(['email' => $this->input->post('email', TRUE), 'password' => sha1($this->input->post('password', TRUE))]);
//            print_r($user);
//            die;
            if ($user['count'] > 0) {
                $this->session->set_userdata([
                    'is_logued_in' => TRUE,
                    'id' => $user['data'][0]->id,
                    'rol' => $user['data'][0]->rol,
                    'email' => $user['data'][0]->email,
                    'name' => $user['data'][0]->name
                ]);
                redirect('mark/');
            }
        }
        redirect('app/');
    }

    public function logout()
    {
        $this->session->sess_destroy();
        $this->index();
    }
}