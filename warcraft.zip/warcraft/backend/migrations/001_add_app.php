<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Add_app extends CI_Migration
{
    public function up()
    {
//        configuration////////////////////////////////////////////////////////////////////////////////////////////
        $this->dbforge->add_field(array(
            'id' => array(
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE,
            ),
            'name' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'email' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'password' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'rol' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'createdAt' => array(
                'type' => 'DATETIME',
                'null' => TRUE,
            ),
            'updatedAt' => array(
                'type' => 'DATETIME',
                'null' => TRUE,
            ),
        ));
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table('users', TRUE);

        $this->db->insert('users', array(
            'name' => "WarCraft Admin",
            'email' => "admin@warcraft.com",
            'password' => sha1('warcraft_admin'),
            'rol' => 'admin'
        ));

//      themes///////////////////////////////////////////////////////////////////////////////////////////////////
        $this->dbforge->add_field(array(
            'id' => array(
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ),
            'points' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'name' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'type' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'typeicon' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'typeiconext' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'desc' => array(
                'type' => 'TEXT',
                'null' => TRUE,
            ),
            'icon' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'iconext' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'min' => array(
                'type' => 'INT',
                'constraint' => '11',
                'null' => FALSE,
            ),
            'max' => array(
                'type' => 'INT',
                'constraint' => '11',
                'null' => FALSE,
            ),
            'filter' => array(
                'type' => 'INT',
                'constraint' => '11',
                'null' => FALSE,
            ),
            'region' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => FALSE,
            ),
            'createdAt' => array(
                'type' => 'DATETIME',
                'null' => TRUE,
            ),
            'updatedAt' => array(
                'type' => 'DATETIME',
                'null' => TRUE,
            ),
        ));
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table('marks', TRUE);
    }

    public function down()
    {
        $this->dbforge->drop_table('users', TRUE);
        $this->dbforge->drop_table('marks', TRUE);
    }
}