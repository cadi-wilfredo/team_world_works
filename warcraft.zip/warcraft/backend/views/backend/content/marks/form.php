<h2 class="ui header">
    <i class="marker icon"></i>

    <div class="content">Marks</div>
</h2>
<div class="ui attached container">
    <a href="<?php echo site_url('mark/') ?>">
        <button class="ui button blue"><i class="arrow left icon"></i>Go back</button>
    </a>

    <div class="ui horizontal divider">
        Mark form
    </div>
    <form action="<?php echo site_url('mark/processform/') ?>" method="post"
          class="ui form equal width"
          enctype="multipart/form-data">
        <?php if ($mark) { ?>
            <input name="id" type="hidden" value="<?php echo $mark->id ?>">
        <?php } ?>
        <div class="fields">
            <div class="field">
                <label>Name</label>
                <input name="name" placeholder="Name" type="text">
            </div>

            <div class="field">
                <label>Type:</label>

                <div class="ui fluid search selection dropdown">
                    <input name="type" type="hidden" autocomplete="off">
                    <i class="dropdown icon"></i>

                    <div class="default text">Type</div>
                    <div class="menu">
                        <div class="item" data-value="new">
                            New
                        </div>
                        <div class="item" data-value="h_capital">
                            <?php echo assets_img('frontend/images/h_capital.png', array(
                                'class' => 'ui mini avatar image'
                            )) ?>
                            Horde capital
                        </div>
                        <div class="item" data-value="a_capital">
                            <?php echo assets_img('frontend/images/a_capital.png', array(
                                'class' => 'ui mini avatar image'
                            )) ?>
                            Alliance capital
                        </div>
                        <div class="item" data-value="pin-yellow">
                            <?php echo assets_img('frontend/images/pin-yellow.png', array(
                                'class' => 'ui mini avatar image'
                            )) ?>
                            Pin yellow
                        </div>
                        <div class="item" data-value="pin-green">
                            <?php echo assets_img('frontend/images/pin-green.png', array(
                                'class' => 'ui mini avatar image'
                            )) ?>
                            Pin green
                        </div>
                        <div class="item" data-value="pin-red">
                            <?php echo assets_img('frontend/images/pin-red.png', array(
                                'class' => 'ui mini avatar image'
                            )) ?>
                            Pin red
                        </div>
                        <div class="item" data-value="pin-purple">
                            <?php echo assets_img('frontend/images/pin-purple.png', array(
                                'class' => 'ui mini avatar image'
                            )) ?>
                            Pin purple
                        </div>
                        <div class="item" data-value="village">
                            <?php echo assets_img('frontend/images/village.png', array(
                                'class' => 'ui mini avatar image'
                            )) ?>
                            Village
                        </div>
                        <?php foreach ($new as $n) { ?>
                            <div class="item" data-value="<?php echo $n->icon ?>">
                                <?php if ($n->icon) echo assets_img('frontend/images/' . $n->icon . '.' . $n->iconext, array(
                                    'class' => 'ui mini avatar image'
                                )) ?>
                                <?php echo $n->name ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>

            <div class="field">
                <label>Region:</label>

                <div class="ui fluid search selection dropdown">
                    <input name="region" type="hidden">
                    <i class="dropdown icon"></i>

                    <div class="default text">Region</div>
                    <div class="menu">
                        <div class="item" data-value="north">
                            Northrend
                        </div>
                        <div class="item" data-value="kalimdor">
                            Kalimdor
                        </div>
                        <div class="item" data-value="east">
                            Eastern Kingdoms
                        </div>
                        <div class="item" data-value="mal">
                            Maelstrom
                        </div>
                        <div class="item" data-value="out">
                            Outland
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="fields">
            <div class="field">
                <label>Level</label>

                <div class="fields">
                    <div class="field">
                        <input placeholder="Min" id="lvlmin" name="min" type="number" min="0" max="79">
                    </div>
                    <div class="field">
                        <input placeholder="Max" id="lvlmax" name="max" type="number" min="0" max="80">
                    </div>
                </div>
            </div>

            <div class="field">
                <label>Points [X,Y]</label>

                <div class="fields">
                    <button type="button" id="openMap" class="ui icon button blue"><i class="marker icon"></i></button>
                    <div class="field">
                        <input placeholder="X" id="cordX" readonly name="x" type="number" min="0">
                    </div>
                    <div class="field">
                        <input placeholder="Y" id="cordY" readonly name="y" type="number" min="0">
                    </div>
                </div>
            </div>
        </div>

        <div class="fields">
            <div class="field">
                <label>Icon</label>
                <?php if ($mark) { ?>
                    <?php echo assets_img('frontend/images/' . $mark->icon . '.' . $mark->iconext, array('class' => "ui top aligned tiny rounded image", 'title' => $mark->icon)) ?>
                <?php } ?>
                <input name="icon" placeholder="Icon" type="file">
            </div>

            <div class="field">
                <label>Filter:</label>

                <div class="ui fluid search selection dropdown">
                    <input name="filter" type="hidden">
                    <i class="dropdown icon"></i>

                    <div class="default text">Filter</div>
                    <div class="menu">
                        <div class="item" data-value="4" data-text="Cataclysm">
                            Cataclysm
                        </div>
                        <div class="item" data-value="5" data-text="Wrath Of The Lich King">
                            Wrath Of The Lich King
                        </div>
                        <div class="item" data-value="6" data-text="The Burning Crusade">
                            The Burning Crusade
                        </div>
                        <div class="item" data-value="7" data-text="Vanilla WoW">
                            Vanilla WoW
                        </div>
                        <div class="item" data-value="8" data-text="Capital Cities of Alliance">
                            Capital Cities of Alliance
                        </div>
                        <div class="item" data-value="9" data-text="Capital Cities of Horde">
                            Capital Cities of Horde
                        </div>
                        <div class="item" data-value="14" data-text="Neutral Cities">
                            Neutral Cities
                        </div>
                        <div class="item" data-value="15" data-text="Villages">
                            Villages
                        </div>
                        <div class="item" data-value="10" data-text="Raids Cataclysm">
                            Raids Cataclysm
                        </div>
                        <div class="item" data-value="11" data-text="Wrath Of The Lich King">
                            Wrath Of The Lich King
                        </div>
                        <div class="item" data-value="12" data-text="The Burning Crusade">
                            The Burning Crusade
                        </div>
                        <div class="item" data-value="13" data-text="Vanilla WoW">
                            Vanilla WoW
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="field">
            <label>Description</label>
            <textarea name="desc" rows="2"></textarea>
        </div>

        <div class="ui blue submit button">Submit</div>
        <div class="ui reset button">Reset</div>
        <div class="ui clear button">Clear</div>
    </form>
</div>
<div class="ui modal small">
    <div class="header"></div>
    <canvas class="image content" height="880" width="690" id="mapCanvas"
            style="padding: 0px;margin: 0px;border: 0px none;background: transparent none repeat scroll 0% 0%;width: 690px; height: 880px;"></canvas>
</div>