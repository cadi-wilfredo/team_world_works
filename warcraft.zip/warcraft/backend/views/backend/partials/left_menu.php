<div class="ui bottom attached segment pushable">
    <div id="leftmenu" class="ui left vertical sidebar menu">
        <div class="ui top attached tabular menu">
            <a class="item active" data-tab="first"><i class="icon list layout"></i></a>
        </div>
        <div class="menucontainer ui bottom attached tab segment active" data-tab="first">

            <div id="leftmenu" class="ui text visible left vertical large menu accordion inline">
                <div class="item">
                    <a class="title <?php echo $active === 'marks'?'active':'' ?>">
                        <i class="dropdown icon"></i>
                        Settings
                    </a>

                    <div class="content <?php echo $active === 'marks'?'active':'' ?>">
                        <a class="item" href="<?php echo site_url('mark/') ?>">
                            <i class="marker icon"></i>
                            Marks
                        </a>
                    </div>
                </div>
                <div class="item">
                    <a class="title <?php echo $active === 'users'?'active':'' ?>">
                        <i class="dropdown icon"></i>
                        Security
                    </a>

                    <div class="content <?php echo $active === 'users'?'active':'' ?>">
                        <a class="item" href="<?php echo site_url('user/') ?>">
                            <i class="users icon"></i>
                            Users
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <div class="pusher">
        <div class="ui attached segment">
            <!--content-->
            <section class="ui full height">
