<div id="content-large">
    <div id="leftcolumn-large">

        <div class="fullpage-article armory">
            <div class="fullpage-article-content">
                <div class="pvp-menu">
                    <h3>Search</h3>
                    <ul>
                        <li><a href="#!" class="active"><b>Characters</b></a></li>
                        <li><a href="#!"><b>Guilds</b></a></li>
                        <li><a href="#!"><b>Arena Teams</b></a></li>
                    </ul>
                    <h3>PVP Leaders</h3>
                    <ul>
                        <li><a href="#!"><b>Rated BG</b></a></li>
                        <li><a href="#!"><b>Arena 2v2</b></a></li>
                        <li><a href="#!"><b>Arena 3v3</b></a></li>
                        <li><a href="#!"><b>Arena 5v5</b></a></li>
                    </ul>
                </div>

                <div style="float: left;width: 400px;text-align: left;margin-left: 10px;">
                    <form method="get" action="#!">
                        <p>
                            <label for="name">Character Name:</label>
                            <input type="text" value="" name="name" maxlength="50" id="name" class="select">
                            <input type="submit" value="Search">
                        </p>
                    </form>
                </div>
                <div style="float:right;width:350px;text-align:right">
                    <h3 style="margin: 21px 5px;">Found 0 records</h3>
                </div>
                <div class="pvp-right">

                    <p style="text-align:center">Type name of character to search.</p>
                </div>
                <br class="clear">
            </div>
        </div>


    </div>
</div>