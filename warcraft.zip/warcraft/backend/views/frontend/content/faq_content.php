<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1417" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                            <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                            <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                            <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">
        <div id="breadcrumbs">
            <ul style="list-style:none" itemprop="breadcrumb" id="breadcrumbs-position">
                <li><a href="#!">Atlantiss</a></li>
                <li><a href="#!">FAQ</a></li>
            </ul>
        </div>

        <div class="fullpage-article page-content">
            <div itemtype="#!" itemscope="" class="fullpage-article-content">
                <h2 itemprop="name">FAQ</h2>
                <div itemprop="description">
                    <ul style="list-style-type: disc;">
                        <li>Shortcuts used on forum/server/website
                            <ul>
                                <li><strong>FAQ</strong> - Frequently Asked Questions</li>
                                <li><strong>BT</strong> - BugTracker</li>
                                <li><strong>DC</strong> - Disconnect</li>
                                <li><strong>ADM</strong> - Administrator</li>
                                <li><strong>GM</strong> - Game Master</li>
                                <li><strong>Dev</strong> - Developer</li>
                                <li><strong>Rev</strong> - Revision number</li>
                                <li><strong>PW</strong> - private message</li>
                                <li><strong>TS3</strong> - Teamspeak communicator</li>
                                <li><strong>IRC</strong> - IRC communicator</li>
                            </ul>
                        </li>
                    </ul>
                    <ol>
                        <li>Which patch is up on the server?<br>At the moment we are on patch&nbsp;4.3.4 (15595) (expansion Cataclysm). If you have a
                            higher patch you will not be able to connect to the server.<br><br><strong>To play on our server you must &nbsp;download
                                our .exe:</strong><br><a href="#!"><strong>World of
                                    Warcraft.exe</strong></a><br><br><strong>Or client: <a href="#!">click to
                                    download</a></strong></li>
                        <li>Do I have to pay for playing?<br>Playing on our server is completely free. If you wish you can donate money in Vote Panel
                            by buying Premium Points which you can later spend in our shop.<br><br></li>
                        <li>How do I report bugs found in the game?<br>The error reporting is provided by Github.com bugtracker. Any server errors
                            written on the forum or in the ticket system don't have to be considered. Developers will only consider the errors
                            reported. <a href="#!">Click here to go to bugtracker.</a><br><br></li>
                        <li>How do I contact with Administrator / Game Master / Developer?<br>The developer can be contacted in many different ways,
                            but he doesn't have to respond to your question.<br>To communicate with the game master use the ticket system it is the
                            only official channel of communication with GMs. Another form of communication is the forum (private message) or trying to
                            catch the person on the server IRC/TS3.<br>To contact someone from the Administration, write a private message on the
                            forum.<br><br></li>
                        <li>What is it and how to check the revision number?<br>This revision number is the curent game server's application number.
                            It is used to help the DevTeam and players. Each of the developers types a number (rev in which issue was fixed) when
                            closing an Bugtracker issue.<br><br><strong>To check the current Rev on the server, click enter and type the
                                command</strong>: .server info<br><br></li>
                        <li>I would like to help to develop the server and fixing the source code, how do I do this?<br>For those who want to help in
                            the development of the server &nbsp;we prepared a special "corner" where you'll find tips (for example how to repairs
                            quests). The tutorial "how to set up a server for tests" <a
                                href="#!">can be found here</a><br><br></li>
                        <li>Can you give back lost items/gold due to DC/error? <br>No, we won't do that. We suggest to relog after boss kills. However
                            our server uptime is usually around 1-3 days, so these situations won't occur so often.<br><br></li>
                        <li>Can I posses more than one account?<br>Yes, you can.<br><br></li>
                        <li>Can I create characters from two different factions on a single account?<br>Yes, you can.<br><br></li>
                        <li>How often is autosave made?<br>Autosave is made every 3 min.<br><br></li>
                        <li>How can I change my account password and what is the best way to make it safe?<br>You can change your password &nbsp;in
                            your account settings on the home page or via a command in the game ".Account password old new new".<br>To attach a lock
                            to allow logging in to the game with the currently used IP address - type in the game. "Account lock on / off". <strong>This
                                option is not recommended for those with dynamic IP</strong><br><br></li>
                        <li>Are inactive accounts or characters deleted?<br>Inactive accounts or characters are not deleted. Additionally, if you
                            delete your character above level 10 there is a possibility to restore them within 90 days from the day they have been
                            deleted. Nickname of deleted character is laid off, so it is possible for someone to occupy&nbsp; it. For if that happens,
                            you will be charged in the quantity of 200 Vote Points in order to change your nickname.<br><br><strong>Warning! We do not
                                guarantee that every deleted character which meets the requirements will be restored, because unexpected events may
                                occur resulting in character being impossible to restore.</strong><br><br></li>
                        <li>TeamSpeak3 and IRC<br><a href="#!">Click here to check how to configure these communicators.</a></li>
                        <li>Can I transfer a character to your server? <br>Yes but only in between&nbsp;<strong>25.03.2015 and 31.06.2015.</strong>
                        </li>
                    </ol>
                </div>
                <div class="line">
                    Last change
                    <meta content="2013-05-01 21:12:27" itemprop="datePublished">
                    <time itemprop="dateModified" datetime="2015-05-26 20:31:29">26 May 2015</time>
                </div>
            </div>
        </div>

    </div>
</div>