<div id="content-large">
    <div id="leftcolumn-large">
        <div class="fullpage-article">
            <div id="map-container">
                <section class="map-legend">
                    <h1 id="map-name">Eastern Kingdoms</h1>
                </section>
                <section class="map-list">
                    <dl>
                        <dt class="h_azeroth"><span>Azeroth</span></dt>
                        <dd data-type="north" class="north">
                    <span>
                        <b>Northrend</b>
                    </span>
                        </dd>
                        <dd data-type="kalimdor" class="kalimdor">
                    <span>
                        <b>Kalimdor</b>
                    </span>
                        </dd>
                        <dd data-type="east" class="east active">
                    <span>
                        <b>Eastern Kingdoms</b>
                    </span>
                        </dd>
                        <dd data-type="mal" class="mal">
                    <span>
                        <b>Maelstrom</b>
                    </span>
                        </dd>
                        <dt class="h_outlands"><span>Outland</span></dt>
                        <dd data-type="out" class="out">
                    <span>
                        <b>Outland</b>
                    </span>
                        </dd>
                        <dt style="margin-top: 5px;">
                        <div style="padding: 0px 15px;color: #9E815A;border-top: 1px solid #221006;padding-top: 10px;">
                            <b style="font-size: 0.8rem;">Show on Map:</b>
                            <ul id="map-filters" style="list-style:none;padding: 10px;margin: 0px;">
                                <li style="padding: 2px 10px;margin: 0px;">
                                    <label><b style="line-height: 11px;">Dungeons</b></label>
                                    <ul style="list-style:none;padding: 2px 10px 0px 10px;margin: 0px;">
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="4">
                                                <b style="line-height: 11px;">Cataclysm</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="5">
                                                <b style="line-height: 11px;">Wrath Of The Lich King</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="6">
                                                <b style="line-height: 11px;">The Burning Crusade</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="7">
                                                <b style="line-height: 11px;">Vanilla WoW</b>
                                            </label>
                                        </li>
                                    </ul>
                                </li>
                                <li style="padding: 2px 10px;margin: 0px;">
                                    <label><b style="line-height: 11px;">Cities</b></label>
                                    <ul style="list-style:none;padding: 2px 10px 0px 10px;margin: 0px;">
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="8"
                                                       checked="">
                                                <b style="line-height: 11px;">Capital Cities of Alliance</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="9"
                                                       checked="">
                                                <b style="line-height: 11px;">Capital Cities of Horde</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="14"
                                                       checked="">
                                                <b style="line-height: 11px;">Neutral Cities</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="15">
                                                <b style="line-height: 11px;">Villages</b>
                                            </label>
                                        </li>
                                    </ul>
                                </li>
                                <li style="padding: 2px 10px;margin: 0px;">
                                    <label><b style="line-height: 11px;">Raids</b></label>
                                    <ul style="list-style:none;padding: 2px 10px 0px 10px;margin: 0px;">
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="10">
                                                <b style="line-height: 11px;">Cataclysm</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="11">
                                                <b style="line-height: 11px;">Wrath Of The Lich King</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="12">
                                                <b style="line-height: 11px;">The Burning Crusade</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="13">
                                                <b style="line-height: 11px;">Vanilla WoW</b>
                                            </label>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        </dt>
                    </dl>
                    <div class="clear"></div>
                </section>
                <section id="map-section" class="map-preview">
                    <div style="position: relative; display: inline-block; width: 690px; height: 880px;"
                         class="kineticjs-content"
                         role="presentation">
                        <canvas
                            style="padding: 0px; margin: 0px; border: 0px none; background: none repeat scroll 0% 0% transparent; position: absolute; top: 0px; left: 0px; width: 690px; height: 880px;"
                            width="690" height="880"></canvas>
                    </div>
                </section>

                <div style="margin-bottom:100px" class="clear"></div>
            </div>
            <div id="map-ender"></div>
        </div>
    </div>

    <script defer="defer" type="text/javascript">
        $(function () {
            var myMap = new WoWMap();
            var mapdata = {
                "east": {
                    "name": "Eastern Kingdoms",
                    "points": {
                        "1": {
                            "name": "Dun Morogh",
                            "points": [372, 480, 387, 485, 400, 486, 406, 487, 411, 490, 418, 496, 419, 503, 420, 510, 426, 519, 427, 526, 424, 528, 420, 535, 419, 541, 416, 547, 402, 544, 394, 547, 384, 547, 371, 550, 362, 551, 350, 554, 344, 558, 340, 568, 339, 573, 327, 571, 319, 575, 316, 571, 304, 560, 299, 545, 297, 536, 292, 525, 282, 516, 278, 504, 282, 493, 289, 490, 299, 491, 309, 497, 321, 489, 332, 485, 343, 492, 352, 494, 359, 488, 369, 482],
                            "tip": {"lvl": {"min": 1, "max": 10}, "faction": "alliance", "quest": [43, 2, 0]}
                        },
                        "3": {
                            "name": "Badlands",
                            "points": [414, 548, 429, 549, 435, 551, 439, 550, 442, 545, 456, 542, 464, 549, 471, 548, 475, 548, 482, 548, 488, 550, 490, 558, 488, 563, 490, 568, 490, 578, 488, 586, 485, 590, 476, 592, 470, 598, 461, 596, 454, 592, 447, 589, 440, 585, 430, 585, 419, 584, 411, 583, 403, 582, 406, 577, 406, 571, 407, 561, 409, 552],
                            "tip": {"lvl": {"min": 44, "max": 48}, "faction": "neutral", "quest": [23, 4, 40]}
                        },
                        "4": {
                            "name": "Blasted Lands",
                            "points": [423, 690, 428, 690, 433, 692, 438, 689, 442, 688, 450, 691, 454, 695, 461, 700, 461, 704, 459, 708, 460, 717, 463, 721, 464, 727, 464, 734, 466, 737, 468, 742, 464, 742, 459, 746, 457, 750, 455, 754, 448, 752, 442, 750, 440, 750, 439, 754, 435, 755, 430, 754, 430, 757, 422, 760, 417, 759, 417, 751, 411, 742, 404, 736, 407, 729, 409, 722, 413, 715, 417, 711, 421, 709, 421, 702, 421, 696],
                            "tip": {"lvl": {"min": 54, "max": 60}, "faction": "neutral", "quest": [72, 5, 3]}
                        },
                        "8": {
                            "name": "Swamp of Sorrows",
                            "points": [415, 670, 416, 667, 421, 665, 425, 666, 429, 665, 436, 667, 440, 668, 446, 666, 455, 662, 462, 659, 466, 661, 472, 666, 476, 674, 476, 679, 476, 687, 476, 692, 468, 702, 464, 702, 460, 700, 456, 696, 453, 692, 448, 689, 439, 689, 431, 690, 426, 691, 422, 692, 422, 688, 422, 682, 420, 678, 415, 674],
                            "tip": {"lvl": {"min": 52, "max": 54}, "faction": "neutral", "quest": [51, 3, 2]}
                        },
                        "10": {
                            "name": "Duskwood",
                            "points": [323, 678, 330, 674, 334, 676, 339, 675, 342, 674, 344, 671, 349, 669, 354, 670, 360, 667, 367, 670, 374, 670, 382, 671, 390, 671, 393, 668, 393, 679, 396, 684, 401, 689, 402, 697, 400, 702, 401, 705, 396, 708, 390, 709, 384, 706, 378, 711, 373, 708, 366, 709, 355, 710, 349, 715, 345, 715, 338, 716, 337, 711, 336, 709, 340, 706, 336, 704, 330, 703, 328, 700, 324, 695, 323, 690, 323, 685],
                            "tip": {"lvl": {"min": 20, "max": 25}, "faction": "neutral", "quest": [55, 2, 0]}
                        },
                        "11": {
                            "name": "Wetlands",
                            "points": [401, 430, 412, 432, 421, 433, 427, 430, 442, 432, 448, 430, 447, 434, 446, 441, 443, 447, 443, 454, 447, 457, 453, 461, 449, 468, 445, 474, 444, 480, 447, 487, 449, 491, 439, 494, 431, 496, 422, 497, 417, 496, 414, 488, 404, 487, 392, 486, 388, 482, 377, 479, 374, 477, 378, 470, 383, 471, 385, 468, 380, 465, 377, 465, 372, 472, 366, 475, 366, 470, 366, 466, 369, 465, 372, 463, 371, 454, 374, 446, 379, 440, 384, 437, 386, 438, 392, 436, 394, 433],
                            "tip": {"lvl": {"min": 20, "max": 25}, "faction": "neutral", "quest": [55, 0, 0]}
                        },
                        "12": {
                            "name": "Elwynn Forest",
                            "points": [294, 598, 303, 595, 310, 595, 318, 591, 325, 592, 334, 596, 343, 596, 349, 600, 356, 607, 361, 616, 365, 622, 373, 622, 375, 622, 382, 627, 388, 630, 392, 633, 391, 640, 394, 655, 395, 662, 390, 668, 382, 665, 379, 665, 376, 666, 366, 664, 362, 663, 354, 667, 347, 670, 340, 670, 333, 671, 330, 669, 324, 675, 320, 676, 320, 672, 319, 665, 317, 660, 313, 658, 312, 653, 308, 642, 306, 636, 313, 630, 312, 626, 307, 625, 303, 625, 301, 620, 302, 610, 298, 607, 293, 605],
                            "tip": {"lvl": {"min": 1, "max": 10}, "faction": "alliance", "quest": [39, 0, 0]}
                        },
                        "28": {
                            "name": "Western Plaguelands",
                            "points": [389, 244, 380, 258, 380, 266, 382, 272, 383, 278, 382, 285, 377, 290, 370, 294, 371, 300, 367, 307, 371, 310, 380, 315, 383, 322, 390, 332, 402, 327, 407, 320, 416, 323, 424, 324, 435, 319, 439, 314, 439, 305, 436, 303, 430, 300, 427, 299, 420, 301, 422, 293, 421, 288, 419, 282, 414, 274, 413, 263, 410, 257, 409, 252, 410, 249, 407, 241, 402, 236, 389, 237],
                            "tip": {"lvl": {"min": 35, "max": 40}, "faction": "neutral", "quest": [70, 6, 4]}
                        },
                        "33": {
                            "name": "Northern Stranglethorn",
                            "points": [311, 720, 315, 719, 318, 716, 319, 711, 321, 711, 330, 712, 334, 711, 344, 712, 353, 710, 363, 709, 371, 710, 381, 709, 396, 709, 403, 709, 408, 712, 411, 715, 411, 720, 409, 725, 406, 731, 408, 742, 411, 747, 414, 751, 417, 758, 414, 758, 413, 763, 410, 766, 402, 768, 394, 773, 389, 775, 384, 777, 379, 783, 377, 782, 374, 778, 369, 778, 367, 777, 362, 773, 360, 769, 358, 768, 355, 767, 354, 765, 353, 757, 354, 755, 351, 752, 345, 749, 341, 747, 335, 742, 334, 737, 329, 733, 324, 731, 319, 729, 313, 724],
                            "tip": {"lvl": {"min": 25, "max": 30}, "faction": "neutral", "quest": [93, 2, 1]}
                        },
                        "38": {
                            "name": "Loch Modan",
                            "points": [422, 498, 432, 498, 441, 497, 449, 495, 458, 496, 467, 500, 475, 503, 477, 512, 476, 518, 479, 520, 484, 528, 486, 535, 486, 543, 481, 547, 463, 549, 464, 544, 455, 540, 449, 538, 445, 543, 441, 546, 429, 551, 425, 549, 421, 547, 420, 544, 417, 541, 416, 536, 421, 531, 426, 528, 424, 519, 424, 513, 421, 508, 420, 502],
                            "tip": {"lvl": {"min": 10, "max": 20}, "faction": "alliance", "quest": [59, 1, 1]}
                        },
                        "40": {
                            "name": "Westfall",
                            "points": [302, 656, 295, 656, 288, 660, 284, 666, 280, 672, 278, 679, 278, 688, 277, 696, 277, 701, 284, 710, 289, 713, 295, 714, 300, 714, 307, 712, 310, 718, 314, 720, 318, 716, 318, 712, 323, 711, 327, 711, 333, 711, 331, 707, 327, 705, 322, 702, 320, 698, 320, 692, 319, 685, 317, 682, 315, 675, 315, 669, 314, 662, 311, 660, 304, 656],
                            "tip": {"lvl": {"min": 10, "max": 15}, "faction": "alliance", "quest": [35, 6, 0]}
                        },
                        "41": {
                            "name": "Deadwind Pass",
                            "points": [396, 667, 406, 671, 415, 675, 420, 681, 421, 689, 420, 697, 420, 706, 417, 711, 414, 713, 409, 710, 405, 707, 401, 703, 402, 699, 403, 691, 402, 687, 395, 682, 393, 675, 395, 671],
                            "tip": {"lvl": {"min": 55, "max": 60}, "faction": "neutral", "quest": [1, 0, 0]}
                        },
                        "44": {
                            "name": "Redridge Mountains",
                            "points": [392, 632, 398, 628, 404, 627, 408, 628, 414, 625, 419, 624, 424, 623, 429, 628, 432, 626, 439, 624, 446, 622, 451, 624, 457, 626, 462, 630, 465, 634, 467, 641, 468, 646, 467, 652, 464, 653, 464, 655, 462, 660, 458, 662, 452, 666, 448, 669, 443, 668, 439, 668, 431, 664, 426, 668, 423, 666, 418, 665, 416, 667, 414, 670, 404, 667, 401, 663, 398, 660, 396, 654, 395, 650, 395, 644, 396, 640],
                            "tip": {"lvl": {"min": 15, "max": 20}, "faction": "alliance", "quest": [41, 4, 1]}
                        },
                        "45": {
                            "name": "Arathi Highlands",
                            "points": [406, 364, 416, 365, 429, 372, 440, 375, 444, 370, 456, 369, 461, 372, 469, 379, 475, 384, 475, 396, 477, 405, 475, 412, 468, 419, 456, 424, 446, 424, 438, 423, 430, 427, 423, 426, 414, 423, 404, 419, 397, 414, 391, 407, 389, 399, 390, 390, 392, 385, 398, 375, 403, 367],
                            "tip": {"lvl": {"min": 25, "max": 30}, "faction": "neutral", "quest": [47, 1, 0]}
                        },
                        "46": {
                            "name": "Burning Steppes",
                            "points": [354, 598, 356, 591, 358, 588, 363, 584, 367, 589, 376, 589, 388, 587, 392, 584, 404, 583, 416, 584, 426, 584, 437, 585, 447, 590, 454, 595, 452, 600, 450, 600, 452, 602, 454, 603, 455, 605, 454, 610, 454, 617, 452, 620, 438, 624, 434, 627, 432, 627, 430, 627, 428, 624, 423, 622, 413, 623, 410, 625, 406, 627, 403, 625, 398, 627, 394, 630, 391, 629, 387, 626, 379, 621, 376, 621, 370, 621, 368, 621, 365, 617, 360, 609, 358, 605, 353, 601],
                            "tip": {"lvl": {"min": 49, "max": 52}, "faction": "neutral", "quest": [89, 0, 1]}
                        },
                        "47": {
                            "name": "The Hinterlands",
                            "points": [521, 317, 509, 314, 501, 312, 488, 315, 480, 310, 463, 315, 450, 323, 420, 326, 413, 322, 408, 333, 401, 336, 403, 352, 404, 361, 414, 366, 424, 367, 428, 372, 438, 374, 443, 369, 457, 368, 465, 377, 474, 385, 484, 373, 484, 364, 487, 357, 488, 350, 489, 343, 494, 336, 494, 332, 498, 329, 505, 324, 516, 320],
                            "tip": {"lvl": {"min": 30, "max": 35}, "faction": "neutral", "quest": [65, 5, 1]}
                        },
                        "51": {
                            "name": "Searing Gorge",
                            "points": [365, 553, 358, 562, 354, 574, 350, 587, 350, 591, 352, 597, 357, 587, 361, 585, 364, 585, 368, 589, 376, 587, 383, 587, 390, 585, 394, 583, 401, 582, 404, 580, 403, 569, 406, 564, 406, 560, 408, 553, 411, 547, 406, 546, 401, 548, 397, 546, 394, 548, 389, 548, 381, 549, 371, 552],
                            "tip": {"lvl": {"min": 48, "max": 50}, "faction": "neutral", "quest": [41, 2, 1]}
                        },
                        "85": {
                            "name": "Tirisfal Glades",
                            "points": [275, 310, 290, 304, 302, 304, 312, 302, 320, 303, 330, 306, 335, 307, 341, 305, 351, 306, 363, 309, 368, 312, 369, 297, 377, 288, 384, 285, 383, 272, 380, 265, 379, 258, 384, 249, 384, 243, 372, 246, 362, 255, 355, 257, 347, 257, 335, 260, 325, 255, 312, 255, 305, 257, 306, 265, 301, 269, 298, 273, 291, 275, 288, 271, 281, 269, 276, 269, 267, 274, 257, 282, 255, 292, 262, 302, 269, 307],
                            "tip": {"lvl": {"min": 1, "max": 10}, "faction": "horde", "quest": [42, 0, 3]}
                        },
                        "130": {
                            "name": "Silverpine Forest",
                            "points": [276, 311, 284, 307, 292, 302, 301, 303, 306, 300, 318, 304, 323, 305, 327, 307, 334, 311, 339, 307, 344, 309, 348, 313, 348, 321, 343, 327, 338, 333, 328, 338, 325, 342, 325, 353, 331, 360, 332, 366, 327, 368, 323, 370, 317, 378, 308, 380, 304, 380, 297, 375, 292, 371, 287, 360, 284, 354, 282, 344, 284, 334, 284, 328, 281, 320, 277, 315],
                            "tip": {"lvl": {"min": 10, "max": 20}, "faction": "horde", "quest": [45, 3, 2]}
                        },
                        "139": {
                            "name": "Eastern Plaguelands",
                            "points": [417, 263, 419, 261, 417, 255, 429, 250, 432, 242, 443, 243, 458, 239, 466, 241, 483, 244, 490, 239, 505, 242, 511, 253, 523, 256, 523, 267, 524, 260, 524, 277, 529, 289, 534, 299, 534, 308, 531, 314, 523, 312, 513, 313, 505, 314, 495, 316, 487, 315, 478, 311, 461, 315, 455, 321, 440, 323, 425, 325, 439, 317, 441, 312, 440, 309, 436, 305, 431, 303, 429, 300, 425, 298, 426, 281, 417, 273],
                            "tip": {"lvl": {"min": 40, "max": 45}, "faction": "neutral", "quest": [83, 3, 2]}
                        },
                        "267": {
                            "name": "Hillsbrad Foothills",
                            "points": [347, 308, 359, 309, 369, 310, 376, 317, 384, 321, 389, 332, 399, 340, 402, 348, 403, 355, 404, 360, 402, 368, 397, 378, 395, 381, 390, 390, 390, 400, 383, 402, 377, 398, 368, 385, 361, 384, 348, 386, 341, 388, 332, 385, 322, 384, 318, 380, 322, 370, 331, 366, 332, 362, 328, 359, 325, 345, 326, 341, 335, 338, 344, 330, 348, 319, 349, 315],
                            "tip": {"lvl": {"min": 20, "max": 25}, "faction": "neutral", "quest": [62, 1, 7]}
                        },
                        "3430": {
                            "name": "Eversong Woods",
                            "points": [446, 173, 454, 178, 466, 184, 477, 180, 483, 183, 499, 175, 504, 172, 511, 181, 522, 183, 525, 174, 528, 174, 529, 163, 527, 155, 527, 148, 519, 138, 516, 127, 505, 110, 492, 107, 485, 115, 472, 112, 468, 101, 455, 96, 450, 103, 447, 116, 451, 121, 456, 118, 457, 115, 466, 118, 460, 128, 459, 138, 453, 138, 445, 148, 441, 160, 439, 167],
                            "tip": {"lvl": {"min": 1, "max": 10}, "faction": "horde", "quest": [51, 2, 1]}
                        },
                        "3433": {
                            "name": "Ghostlands",
                            "points": [454, 181, 452, 196, 448, 201, 448, 207, 456, 210, 465, 217, 468, 224, 483, 238, 493, 239, 500, 237, 505, 238, 507, 246, 510, 253, 517, 253, 523, 258, 524, 274, 529, 279, 539, 273, 539, 262, 543, 258, 544, 247, 541, 238, 535, 229, 530, 221, 525, 215, 521, 206, 521, 192, 520, 183, 514, 181, 507, 172, 499, 175, 491, 179, 483, 184, 480, 180, 469, 184, 457, 181],
                            "tip": {"lvl": {"min": 10, "max": 20}, "faction": "horde", "quest": [56, 0, 3]}
                        },
                        "4080": {
                            "name": "Isle of Quel'Danas",
                            "points": [482, 69, 489, 69, 494, 63, 494, 48, 501, 28, 497, 23, 488, 28, 478, 22, 467, 25, 464, 39, 472, 46, 478, 53],
                            "tip": {"lvl": {"min": 68, "max": 70}, "faction": "neutral", "quest": [14, 1, 1]}
                        },
                        "4714": {
                            "name": "Gilneas",
                            "points": [291, 369, 303, 380, 312, 379, 319, 386, 316, 392, 314, 400, 319, 406, 318, 413, 313, 419, 307, 424, 307, 426, 302, 431, 295, 429, 291, 427, 288, 427, 280, 430, 275, 430, 271, 426, 267, 424, 261, 420, 254, 413, 253, 406, 245, 406, 249, 401, 253, 399, 255, 389, 257, 384, 261, 376, 267, 378, 270, 383, 276, 391, 280, 391, 277, 384, 276, 381, 279, 375, 283, 371],
                            "tip": {"lvl": {"min": 1, "max": 12}, "faction": "alliance", "quest": [61, 2, 0]}
                        },
                        "4922": {
                            "name": "Twilight Highlands",
                            "points": [459, 430, 469, 437, 476, 439, 480, 436, 483, 431, 493, 431, 505, 432, 504, 428, 508, 425, 515, 424, 522, 428, 526, 430, 535, 433, 537, 439, 539, 445, 541, 447, 542, 455, 538, 457, 537, 463, 535, 470, 541, 471, 549, 473, 550, 479, 547, 482, 541, 482, 539, 479, 536, 476, 533, 478, 535, 487, 535, 489, 539, 489, 545, 489, 549, 498, 546, 499, 540, 503, 541, 508, 529, 511, 528, 515, 515, 519, 509, 516, 504, 523, 496, 534, 489, 540, 484, 549, 488, 539, 485, 534, 482, 524, 477, 520, 476, 515, 473, 508, 472, 501, 465, 498, 462, 497, 454, 493, 449, 490, 447, 487, 445, 484, 445, 476, 448, 468, 450, 463, 451, 461, 449, 458, 445, 453, 442, 448, 445, 438, 450, 431],
                            "tip": {"lvl": {"min": 84, "max": 85}, "faction": "neutral", "quest": [126, 1, 0]}
                        },
                        "5095": {
                            "name": "Tol Barad",
                            "points": [203, 428, 202, 437, 201, 448, 201, 453, 206, 455, 213, 457, 220, 463, 225, 460, 230, 456, 238, 452, 239, 438, 239, 435, 234, 429, 228, 427, 225, 427, 218, 434, 212, 430],
                            "tip": {"lvl": {"min": 85, "max": 85}, "faction": "neutral", "quest": [26, 0, 0]}
                        },
                        "5146": {
                            "name": "Vashj'ir",
                            "points": [208, 476, 216, 479, 222, 475, 226, 472, 232, 472, 236, 480, 245, 489, 254, 499, 256, 508, 255, 515, 251, 531, 249, 546, 252, 553, 253, 560, 250, 566, 246, 570, 243, 579, 243, 587, 244, 592, 245, 599, 240, 606, 232, 611, 218, 609, 208, 604, 203, 598, 194, 596, 176, 602, 165, 598, 155, 592, 139, 592, 125, 587, 110, 589, 98, 591, 91, 584, 88, 577, 88, 570, 89, 562, 96, 545, 110, 539, 126, 509, 152, 508, 169, 500, 178, 498, 191, 500, 200, 474],
                            "tip": {"lvl": {"min": 80, "max": 82}, "faction": "neutral", "quest": [0, 0, 4]}
                        },
                        "5287": {
                            "name": "The Cape of Stranglethorn",
                            "points": [353, 763, 360, 767, 364, 773, 363, 778, 356, 781, 350, 784, 347, 791, 343, 801, 345, 804, 346, 809, 351, 807, 355, 807, 358, 810, 359, 815, 357, 821, 352, 824, 348, 822, 343, 819, 340, 816, 334, 815, 331, 818, 329, 818, 326, 815, 323, 811, 321, 807, 322, 805, 326, 805, 327, 802, 327, 799, 326, 795, 322, 791, 322, 785, 324, 784, 328, 785, 331, 786, 331, 783, 332, 781, 328, 778, 322, 778, 319, 779, 317, 776, 318, 773, 323, 770, 326, 769, 328, 764, 328, 759, 332, 754, 337, 753, 341, 757, 346, 761, 349, 761],
                            "tip": {"lvl": {"min": 30, "max": 35}, "faction": "neutral", "quest": [86, 2, 2]}
                        },
                        "5389": {
                            "name": "Tol Barad Peninsula",
                            "points": [217, 424, 225, 419, 232, 413, 228, 406, 227, 401, 220, 397, 201, 393, 196, 397, 195, 403, 190, 407, 191, 410, 194, 415, 191, 421, 196, 425, 201, 418, 207, 422, 210, 421],
                            "tip": {"lvl": {"min": 85, "max": 85}, "faction": "neutral", "quest": [43, 1, 0]}
                        }
                    },
                    "marks": {
                        "1": {
                            "name": "Ironforge",
                            "points": [327, 496],
                            "type": "a_capital",
                            "desc": "The capital city of the dwarves, a member of the Alliance. It is the ancestral home of the Bronzebeard dwarves.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 8
                        },
                        "2": {
                            "name": "Stormwind City",
                            "points": [316, 614],
                            "type": "a_capital",
                            "desc": "The capital city of the kingdom known as Stormwind and the largest human city of Azeroth. However the city-state also controls or influences other territories, which include Elwynn Forest, Northshire Valley, the Redridge Mountains, Westfall and Duskwood.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 8
                        },
                        "3": {
                            "name": "Undercity",
                            "points": [325, 289],
                            "type": "h_capital",
                            "desc": "The capital city of the Forsaken undead of the Horde. It is located in Tirisfal Glades, at the northern edge of the Eastern Kingdoms.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 9
                        },
                        "4": {
                            "name": "Silvermoon City",
                            "points": [486, 135],
                            "type": "h_capital",
                            "desc": "The crown jewel of the blood elves, nestled in the Eversong Woods in their ancestral lands of Quel'Thalas. At the northernmost tip of the Eastern Kingdoms the beauty of the spires and thoroughfares of Silvermoon stand in stark contrast to the Dead Scar, the tainted path that Arthas tore through the city in his quest for power.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 9
                        },
                        "11": {
                            "name": "The Stockade",
                            "points": [331, 614],
                            "type": "pin-yellow",
                            "desc": "The Stockade is a prison located in the middle of Stormwind City. It contains a number of especially dangerous individuals, amongst them the infamous Hogger himself. It was widely regarded as an irrelevant dungeon for several expansions, as most of the NPCs dropped loot very rarely--however, thanks to Cataclysm, the three bosses now have staple drops.",
                            "icon": "boss",
                            "lvl": {"min": 22, "max": 25},
                            "filter": 7
                        },
                        "15": {
                            "name": "The Deadmines",
                            "points": [297, 708],
                            "type": "pin-yellow",
                            "desc": "Deep beneath the mines of Moonbrook in southwestern Westfall lie the Deadmines. Despite the demise of the Defias Brotherhood's leader Edwin VanCleef at the hands of Alliance militiamen, the Deadmines is still the Brotherhood's most secure hideout since Cataclysm. Here the survivors of Edwin's crew toil alongside new recruits, so that the Defias juggernaut ship can be complete and the kingdom of Stormwind can be brought to its knees. All this is happening under the vigilant eyes of \"Captain\" Cookie... and Vanessa VanCleef.",
                            "icon": "boss",
                            "lvl": {"min": 15, "max": 20},
                            "filter": 7
                        },
                        "16": {
                            "name": "Shadowfang Keep",
                            "points": [295, 340],
                            "type": "pin-yellow",
                            "desc": "Shadowfang Keep is a haunted keep near the borders of Gilneas in southern Silverpine Forest, on a high bluff overlooking Pyrewood Village. It is the former base of operations for the demented archmage Arugal, who wrested the keep from Baron Silverlaine with his worgen \"children\" and held it until he was defeated by agents of the Horde. The keep is now occupied by the followers of renegade Gilnean nobleman Vincent Godfrey, traitor to both his homeland and to the Forsaken who returned him from death.",
                            "icon": "boss",
                            "lvl": {"min": 16, "max": 26},
                            "filter": 7
                        },
                        "17": {
                            "name": "Gnomeregan",
                            "points": [311, 514],
                            "type": "pin-yellow",
                            "desc": "Gnomeregan is a low level instance located in northwestern Dun Morogh. It's mostly known as an Alliance dungeon, given that most of its quests are available specifically for that faction and that its lore deals with the gnomes and their plight. However, with the advent of the dungeon finder, it's easier to navigate to as Horde.",
                            "icon": "boss",
                            "lvl": {"min": 24, "max": 34},
                            "filter": 7
                        },
                        "18": {
                            "name": "SM: Graveyard",
                            "points": [343, 266],
                            "type": "pin-yellow",
                            "desc": "The Graveyard is part of the Scarlet Monastery complex. The Scarlet Monastery is located in Tirisfal Glades.  The monastery is one of the strongholds of the Scarlet Crusade, a group of maddened zealots so dedicated to the defeat of all undead that they frequently attack everyone - even the living.",
                            "icon": "boss",
                            "lvl": {"min": 28, "max": 33},
                            "filter": 7
                        },
                        "19": {
                            "name": "SM: Library",
                            "points": [343, 276],
                            "type": "pin-yellow",
                            "desc": "The Library is part of the Scarlet Monastery complex. The Scarlet Monastery is located in Tirisfal Glades.  The monastery is one of the strongholds of the Scarlet Crusade, a group of maddened zealots so dedicated to the defeat of all undead that they frequently attack everyone - even the living.",
                            "icon": "boss",
                            "lvl": {"min": 32, "max": 36},
                            "filter": 7
                        },
                        "20": {
                            "name": "SM: Armory",
                            "points": [353, 276],
                            "type": "pin-yellow",
                            "desc": "The Armory is part of the Scarlet Monastery complex. The Scarlet Monastery is located in Tirisfal Glades.  The monastery is one of the strongholds of the Scarlet Crusade, a group of maddened zealots so dedicated to the defeat of all undead that they frequently attack everyone - even the living.",
                            "icon": "boss",
                            "lvl": {"min": 35, "max": 37},
                            "filter": 7
                        },
                        "21": {
                            "name": "SM: Cathedral",
                            "points": [353, 266],
                            "type": "pin-yellow",
                            "desc": "The Cathedral is part of the Scarlet Monastery complex. The Scarlet Monastery is located in Tirisfal Glades.  The monastery is one of the strongholds of the Scarlet Crusade, a group of maddened zealots so dedicated to the defeat of all undead that they frequently attack everyone - even the living.",
                            "icon": "boss",
                            "lvl": {"min": 36, "max": 41},
                            "filter": 7
                        },
                        "22": {
                            "name": "Scholomance",
                            "points": [417, 305],
                            "type": "pin-yellow",
                            "desc": "The Scholomance (SKOH-loh-mance), a vile academy for prospective necromancers of the Scourge, is located in the ruins of the palatial House of Barov, on a rise overlooking the abandoned city of Caer Darrow. The enemy level range is 38-48 and requires that you be at least level 33.",
                            "icon": "boss",
                            "lvl": {"min": 38, "max": 48},
                            "filter": 7
                        },
                        "23": {
                            "name": "Stratholme",
                            "points": [425, 242],
                            "type": "pin-yellow",
                            "desc": "A former bastion of humanity, Stratholme is now a place of despair and death after being torn apart by Arthas in a crusade against the plague and Mal'Ganis. In WotLK, Blizzard added another dungeon, The Culling of Stratholme, to the Caverns of Time to let players see how Stratholme came to be.",
                            "icon": "boss",
                            "lvl": {"min": 42, "max": 52},
                            "filter": 7
                        },
                        "24": {
                            "name": "Blackrock Depths",
                            "points": [367, 587],
                            "type": "pin-yellow",
                            "desc": "The Blackrock Depths (BRD) are the deepest parts of Blackrock Mountain, ruled by the Dark Iron dwarves led by Emperor Dagran Thaurissan. Blackrock Depths is one of the few sources of  Dark Iron Ore and the Black Forge required for smelting the ore is located within. It is also the location of the Black Anvil, which is required by blacksmiths for crafting any dark iron equipment.",
                            "icon": "boss",
                            "lvl": {"min": 47, "max": 61},
                            "filter": 7
                        },
                        "25": {
                            "name": "Blackrock Spire",
                            "points": [355, 587],
                            "type": "pin-yellow",
                            "desc": "Blackrock Spire (BRS) is a dungeon at the upper part of Blackrock Mountain, inhabited by members of the Dark Horde such as orcs, forest trolls, and ogres, as well as their new allies, the Black Dragonflight, who are led by the son of Deathwing-- Nefarian. It consists of two five-player dungeons that cover several precarious floors: Lower Blackrock Spire (LBRS) and Upper Blackrock Spire (UBRS), each with their own set of bosses that players must defeat.",
                            "icon": "boss",
                            "lvl": {"min": 55, "max": 65},
                            "filter": 7
                        },
                        "26": {
                            "name": "Magisters' Terrace",
                            "points": [482, 21],
                            "type": "pin-green",
                            "desc": "Magisters' Terrace is a 5-man instance located on the Isle of Quel'Danas. The instance features four bosses: Selin Fireheart, Vexallus, Priestess Delrissa and Kael'thas Sunstrider himself, who has returned despite his \"defeat\" in Tempest Keep: The Eye.",
                            "icon": "boss",
                            "lvl": {"min": 65, "max": 70},
                            "filter": 6
                        },
                        "27": {
                            "name": "Grim Batol",
                            "points": [456, 461],
                            "type": "pin-red",
                            "desc": "Grim Batol, once one of the greatest dwarven fortresses, is now home of the Twilight Hammer and the corrupted Black Dragonflight after the battle between the Wildhammer and the Dark Irons. The 5-man dungeon lies to the west of the Twilight Highlands. Players can enter the dungeon on Normal-mode at level 84, requiring minimum ilvl 305 to queue up. The dungeon is notable for having players ride dragons as vehicles over the extensive trash, bombing them to get them to low HP. With the numerous dragons as trash, it's also an excellent place for skinning.",
                            "icon": "boss",
                            "lvl": {"min": 84, "max": 85},
                            "filter": 4
                        },
                        "28": {
                            "name": "Uldaman",
                            "points": [415, 544],
                            "type": "pin-yellow",
                            "desc": "Uldaman is an ancient Titan vault buried deep within the Khaz Mountains, accessible from the Badlands. Partially excavated, it has since fallen into the hands of the Dark Iron dwarves who seek to corrupt its riches for their master, Ragnaros. It is a great introduction to the Titans and its lore is expanded upon by Uldum and Ulduar, areas which further explain the Titan mythos and the origination of life on Azeroth.",
                            "icon": "boss",
                            "lvl": {"min": 35, "max": 45},
                            "filter": 7
                        },
                        "30": {
                            "name": "Throne of the Tides",
                            "points": [192, 513],
                            "type": "pin-red",
                            "desc": "Throne of the Tides is part of the player-accessible section of the Abyssal Maw complex. It is a 5-player underwater dungeon, with distinctive architecture--including a liquid elevator. It is one of the first Cataclysm dungeons players can queue up for in Normal Mode. In Throne, players battle their way not only through the host of naga that controls the place, but through servants of the Old Gods themselves as well. There were plans to develop the lore in this dungeon in 4.1, but that was scrapped in favor of further developing Firelands.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 85},
                            "filter": 4
                        },
                        "42": {
                            "name": "Sunken Temple",
                            "points": [456, 672],
                            "type": "pin-yellow",
                            "desc": "The Temple of Atal'Hakkar, also called the Sunken Temple, is a shrine erected by the Atal'ai trolls to the Blood God Hakkar. It is located in the Swamp of Sorrows.",
                            "icon": "boss",
                            "lvl": {"min": 40, "max": 55},
                            "filter": 7
                        },
                        "43": {
                            "name": "Blackrock Caverns",
                            "points": [379, 587],
                            "type": "pin-red",
                            "desc": "Another dungeon located in Blackrock Mountains, Blackrock Caverns is a complex of tunnels created by Deathwing. It connects the mountain home of the Dark Iron dwarves with the Twilight Highlands, north-west of the Wetlands. It is populated by members of the Twilight Hammer and elementals. This is one of the first dungeons players can queue for in Cataclysm and chain-runs grant a ton of experience from 80-82. (Characters who complete the main dungeon quest series earn a fun deep-dive helmet for the duration of the instance.) ",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 85},
                            "filter": 4
                        },
                        "77": {
                            "name": "Karazhan",
                            "points": [405, 693],
                            "type": "pin-purple",
                            "desc": "Karazhan is an abandoned ancient tower located in Deadwind Pass. Karazhan is notable for its famous occupant, the last Guardian of Tirisfal, Medivh. You can use Medivh's staff, Atiesh, Greatstaff of the Guardian, to teleport players to the front gate of Karazhan.",
                            "icon": "boss",
                            "lvl": {"min": 70, "max": 70},
                            "filter": 12
                        },
                        "78": {
                            "name": "Molten Core",
                            "points": [347, 575],
                            "type": "pin-purple",
                            "desc": "The Molten Core is located beyond Blackrock Depths in the deepest part of Blackrock Mountain. It is the home of Ragnaros the Firelord--one of the four elemental lieutenants of the Old Gods--and his elemental minions. Molten Core is a 40-man raid instance.",
                            "icon": "boss",
                            "lvl": {"min": 60, "max": 60},
                            "filter": 13
                        },
                        "79": {
                            "name": "Blackwing Lair",
                            "points": [371, 575],
                            "type": "pin-purple",
                            "desc": "Blackwing Lair can be found at the very height of Blackrock Spire and is a 40-man raid instance. It is there in the dark recesses of the mountain's peak that Nefarian has begun to unfold the final stages of his plan to destroy Ragnaros once and for all and lead his army to undisputed supremacy over all the races of Azeroth. To this end, he has recently begun efforts to bolster his forces, much as his father Deathwing had attempted to do in ages past.",
                            "icon": "boss",
                            "lvl": {"min": 60, "max": 60},
                            "filter": 13
                        },
                        "80": {
                            "name": "Blackwing Descent",
                            "points": [359, 575],
                            "type": "pin-purple",
                            "desc": "The culmination of the Blackrock series of instances comes in a new, but familiar form. Blackwing Descent is a raid designed after Blackwing Lair, with its final boss none other but Nefarian himself--resurrected by his father, Deathwing. It is created to serve as an continuation of the story in Blackwing Lair. The raid features a layout similar to its prototype, but with brand new bosses--except for Nefarian, of course. ",
                            "icon": "boss",
                            "lvl": {"min": 85, "max": 85},
                            "filter": 10
                        },
                        "81": {
                            "name": "Baradin Hold",
                            "points": [213, 438],
                            "type": "pin-purple",
                            "desc": "Baradin Hold is the raid instance that opens when your faction controls Tol Barad, similar to the Vault of Archavon. It drops a mix of PvP accessories and tier, as well as PvE tier legs and gloves.",
                            "icon": "boss",
                            "lvl": {"min": 85, "max": 85},
                            "filter": 10
                        },
                        "82": {
                            "name": "The Bastion of Twilight",
                            "points": [481, 502],
                            "type": "pin-purple",
                            "desc": "The Bastion of Twilight is a Tier 11 raid dungeon located in the southwestern part of the Twilight Highlands, high in the sky. It serves as the main base of operation for the Twilight Hammer. The leader of the cult, Cho'gall himself, is the last boss encounter in this raid, but players that have defeated Cho'gall on heroic can unlock Sinestra.",
                            "icon": "boss",
                            "lvl": {"min": 85, "max": 85},
                            "filter": 10
                        },
                        "125": {
                            "name": "Tranquillien",
                            "points": [469, 177],
                            "type": "village",
                            "desc": "Tranquillien is a town located in the Ghostlands, on the western slope of Sungraze Peak overlooking the Dead Scar. It is surrounded by hostile forces, most notably the Scourge of Deatholme. Resources are therefore in perennial short supply, and communications from Silvermoon City are at best infrequent. Tranquillien is populated by both blood elves and the Forsaken. The two races have formed a faction that is overseen by Dame Auriferous and High Executor Mavren, along with their lieutenants, Advisor Valwyn and Deathstalker Maltendis.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "126": {
                            "name": "Light's Hope Chapel",
                            "points": [501, 268],
                            "type": "village",
                            "desc": "Light's Hope Chapel  is the Argent Dawn's base of operations in the Eastern Plaguelands, currently used for diplomatic negotiations between the Argent Dawn and Scarlet Crusade. Located in the far east of the region, it serves as quest hub for both Horde and Alliance heroes. Scourgestones may be turned in here for reputation with the Dawn. Underneath the chapel is a catacomb which houses the remains of the heroes of Lordaeron. Many of the remains were exhumed and moved to the chapel so they could not be resurrected in the service of the Lich King.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "127": {
                            "name": "Bulwark",
                            "points": [349, 285],
                            "type": "village",
                            "desc": "The Bulwark is the Forsaken's last bastion of defense against the main forces of the Scourge. It lies in southeastern Tirisfal Glades, and forms the border with the Western Plaguelands beyond. The Argent Dawn and Forsaken defenders on the Bulwark have teamed up to protect the land from the hordes of undead to the east, and send experienced adventurers of the Horde to battle the minions of the Lich King.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "128": {
                            "name": "Andorhal",
                            "points": [374, 289],
                            "type": "village",
                            "desc": "The city of Andorhal is a destroyed human city located in the Western Plaguelands, formerly one of the largest cities in northern Lordaeron. Today, the ruined city is firmly in the Scourge's grip, with a population of 30,120, mainly undead. After several years though, Andorhal becomes a battleground between the Horde and the Alliance with the remaining Scourge forces trapped in-between. The Alliance side has been slightly rebuilt and the Horde side is decimated by the Forsaken's chemicals and potions.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "129": {
                            "name": "Sepulcher",
                            "points": [279, 333],
                            "type": "village",
                            "desc": "The Sepulcher (also known as the Silverpine Sepulcher), as its name suggests, was once nothing more than a graveyard along the road to Lordaeron's capital city. Since the end of the Third War however, the enterprising Forsaken have converted the old crypt into their base of operations for Silverpine Forest. With Worgen to the south, the Scourge to the east, and the forces of Dalaran to the southeast, it is one of the only places of safety for the Horde in the entire zone.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "130": {
                            "name": "Tarren Mill",
                            "points": [364, 340],
                            "type": "village",
                            "desc": "Tarren Mill is a Forsaken town located in the northern Hillsbrad Foothills. Prior to the Third War, Tarren Mill was a simple Lordaeron town. It was destroyed by the Scourge and claimed by the Forsaken afterword, where it served as the staging point against the Alliance forces of Southshore and Dun Garok. As time passed, Banshee Queen Sylvanas Windrunner had the town improved and reinforced. Tarren Mill now stands as a bastion of Forsaken power, while its former rival Southshore lays destroyed.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "131": {
                            "name": "Aerie Peak",
                            "points": [399, 338],
                            "type": "village",
                            "desc": "Aerie Peak is the capital of the Wildhammer dwarves affiliated with the Alliance and located in The Hinterlands, complete with a Gryphon master. Also found here is a Master Leatherworking trainer. Aerie Peak, the large Wildhammer city, is carved into an enormous mountainside. The city is located in the northwestern Hinterlands and overlooks Darrowmere Lake. Aerie Peak resembles a gargantuan gryphon head, with open spaces at its eyes and nostrils. Generations of Wildhammers worked on this undertaking, and the sculpture is an excellent likeness. Even the individual feathers are apparent. Wildhammer structures and battlements jut from the cliff\u2019s base. Gryphons make their nests in the carved head and the mountain and forever flap around the place like bees about a real gryphon\u2019s head.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "132": {
                            "name": "Refuge Pointe",
                            "points": [413, 378],
                            "type": "village",
                            "desc": "Refuge Pointe is all that remains of the once great kingdom of Stromgarde. With their Keep in ruins, most of the populace fled south, while the proud remnants of Stromgarde's elite army stayed behind, determined to fight on to reclaim their land. It is from Refuge Pointe that the Alliance's military operations in the area are conducted, most of which is concerned with aiding the Stromgarde army retake their former capital.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "133": {
                            "name": "Hammerfall",
                            "points": [442, 375],
                            "type": "village",
                            "desc": "Hammerfall was formerly one of the largest of the Alliance internment camps. It was attacked and destroyed by Thrall and the Horde in order to free the orcs held captive there. Shortly after the end of the Third War, the Horde re-occupied the ruins of Hammerfall to use as a forward base in the Arathi Highlands. The city is so named in honor to Orgrim Doomhammer, who was killed by a human knight, a lance strike through the back during the camp's liberation.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "134": {
                            "name": "Revantusk Village",
                            "points": [474, 362],
                            "type": "village",
                            "desc": "Revantusk Village is the only visitable settlement of the Revantusk tribe of trolls. You can find the village on the coast of the Hinterlands. Before patch 1.11, you could get quests there which increased your reputation with the Revantusk troll faction. Now it is just a Horde settlement with reputation going to the Darkspear Trolls.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "135": {
                            "name": "Menethil Harbor",
                            "points": [359, 458],
                            "type": "village",
                            "desc": "Menethil Harbor (men-a-thill) is a port town on the western shore of the Wetlands. It has a boat that sails to Theramore Isle in Dustwallow Marsh, on the continent of Kalimdor, and an icebreaker that goes to Valgarde in the Howling Fjord on the continent of Northrend. Within the city are many vendors; a First Aid Trainer, the Deepwater Tavern, and a Gryphon Flight Master.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "136": {
                            "name": "Thelsamar",
                            "points": [428, 509],
                            "type": "village",
                            "desc": "Thelsamar is a dwarven town on the west side of Loch Modan, located north of Grizzlepaw Ridge and northeast of Stonesplinter Valley. The town has a Gryphon roost, an inn, and several vendors and profession trainers. A north-south road runs just west of town, leading to the passes into Dun Morogh and the Wetlands.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "137": {
                            "name": "Iron Summit",
                            "points": [365, 567],
                            "type": "village",
                            "desc": "The Iron Summit is a new camp located northeast of Blackrock Mountain in the Searing Gorge, added after the Cataclysm. While being a neutral quest hub, the loyalty of the Summit's leader is questionable, at best.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "138": {
                            "name": "New Kargath",
                            "points": [419, 556],
                            "type": "village",
                            "desc": "New Kargath, built atop Apocryphan's Rest near the shattered Ruins of Kargath, is the new Horde bastion within the Badlands, erected after the Cataclysm. It is a full-fledged town and appears to be under constant attack by members of the Black dragonflight.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "139": {
                            "name": "Fuselight",
                            "points": [457, 550],
                            "type": "village",
                            "desc": "Fuselight is a new town in the Badlands. It is run by the Steamwheedle Cartel goblins, and unlike most of the smaller towns the few quests there will award reputation with them.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "140": {
                            "name": "Chiselgrip",
                            "points": [395, 595],
                            "type": "village",
                            "desc": "Chiselgrip is a neutral Thorium Brotherhood camp located southwest of the Ruins of Thaurissan in the Burning Steppes. It serves as a quest hub from which you strike undercover at the Blackrock clan, after making the necessary preparations at Flamestar Post. It contains no vendors, but has a flight path and two forges located near Stebben Oreknuckle.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "141": {
                            "name": "Lakeshire",
                            "points": [405, 631],
                            "type": "village",
                            "desc": "Lakeshire, aka Township of Lakeshire, is an ancient human town that sits on the banks of the majestic and large Lake Everstill - from which the town derives its name. It's located in Redridge Mountains, and has 1,500 citizens \u2014 mostly farmers, poachers, and travellers \u2014 that reside there under the watchful and often worried eye of elected Magistrate Solomon. The town is a considered a serene and quiet place. Even with the occasional incursions by the orcs, it is a prime example of how peaceful this area was before the coming of the Horde and the Great Wars.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "142": {
                            "name": "Bogpaddle",
                            "points": [455, 656],
                            "type": "village",
                            "desc": "Bogpaddle is a new neutral goblin port in Swamp of Sorrows ruled by Trade Baron Silversnap. He refers the town as \"the only beachfront resort and military-grade weapons yard in the Eastern Kingdoms\", and his abode has become a popular spot with the forces of both Stonard and Marshtide Watch despite the ongoing war. Carousers from both sides can be found in Bogpaddle in addition to the goblins who party on the beach.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "143": {
                            "name": "Sentinel Hill",
                            "points": [299, 676],
                            "type": "village",
                            "desc": "Sentinel Hill is a People's Militia outpost in Westfall and their last stronghold in the region. It is here that the men and women of the People's Militia make their final stand against the Defias Brotherhood in a desperate last attempt to reclaim their homes. Its current population is around 300.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "144": {
                            "name": "Darkshire",
                            "points": [370, 683],
                            "type": "village",
                            "desc": "Darkshire, previously called Grand Hamlet, is a once-quaint little woodland village located in Duskwood, but it has fallen on literally dark times. The surrounding forests have been filled with an evil malaise that cloaks the land in constant darkness. The walking dead choke the graveyards, and foul creatures known as worgen have overrun many of the outlying farmsteads. Even worse, Stormwind has all but abandoned the village and the surrounding area, as most of the Stormwind army is currently off fighting on the Horde\/Alliance front. This has left the stubborn people of Duskwood little choice but to defend themselves.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "145": {
                            "name": "Dreadmaul Hold",
                            "points": [415, 695],
                            "type": "village",
                            "desc": "Originally the Horde town of Rockard in the northwest corner of the Blasted Lands, it served as a sister town to Stonard during the First War, both the last defense before Blackrock Spire. The humans of Azeroth made a plan to destroy Blackrock Spire, attacking and destroying both Rockard and Stonard in the process. However they didn't manage to destroy Blackrock Spire and were defeated by the Horde. Dreadmaul Hold became the main encampment of the powerful Dreadmaul Ogres after they took over the town. Venturing into the Hold is extremely dangerous and adventurers are cautioned not to go in alone.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "146": {
                            "name": "Nethergarde Keep",
                            "points": [435, 694],
                            "type": "village",
                            "desc": "Nethergarde Keep, a Dalaran fortress of dour mages and paladins, keeps watch over the Dark Portal, and the demons and ogres that would abuse its power. Nethergarde Keep is a heavily defended Alliance town located in the Blasted Lands. The stronghold is home to about 300 members of the Alliance. Although technically it is a castle like Northwatch Hold in the Barrens, none of the Guards are PvP-enabled except the Gryphon Master and a few questgivers.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "147": {
                            "name": "Grom'gol Base Camp",
                            "points": [337, 730],
                            "type": "village",
                            "desc": "Grom'Gol Base Camp is an Orcish camp built in Stranglethorn Vale, to the north of Booty Bay, a neutral port of goblins and pirates.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "148": {
                            "name": "Fort Livingston",
                            "points": [357, 740],
                            "type": "village",
                            "desc": "Fort Livingston is a new Alliance camp in Northern Stranglethorn.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "149": {
                            "name": "Booty Bay",
                            "points": [320, 771],
                            "type": "village",
                            "desc": "Booty Bay is a large pirate city nestled into the cliffs surrounding a beautiful blue lagoon on the southern tip of Stranglethorn Vale. The city is entered by traversing through the bleached-white jaws of a giant shark, or you can travel there with a Flight Master. Horde players usually access the city using the boat from Ratchet; Alliance low level players in the Eastern Kingdoms can brave the road from Duskwood or swim along the coast from Westfall, while those in Kalimdor may risk the roads through Ashenvale and the Northern Barrens to take the Ratchet boat.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        }
                    }
                },
                "kalimdor": {
                    "name": "Kalimdor",
                    "points": {
                        "14": {
                            "name": "Durotar",
                            "points": [458, 369, 462, 365, 465, 359, 469, 353, 475, 354, 481, 352, 486, 349, 490, 348, 493, 352, 507, 356, 509, 355, 510, 361, 508, 362, 502, 369, 496, 375, 496, 381, 499, 387, 502, 392, 501, 401, 502, 411, 502, 418, 502, 424, 502, 434, 504, 437, 505, 444, 504, 451, 502, 457, 496, 464, 494, 469, 490, 471, 485, 470, 478, 469, 471, 467, 467, 463, 463, 458, 462, 451, 459, 442, 457, 437, 455, 429, 454, 419, 455, 408, 455, 399, 457, 392, 461, 384, 463, 370, 461, 374],
                            "tip": {"lvl": {"min": 1, "max": 10}, "faction": "horde", "quest": [43, 0, 1]}
                        },
                        "15": {
                            "name": "Dustwallow Marsh",
                            "points": [431, 507, 436, 509, 441, 513, 447, 512, 452, 511, 457, 508, 456, 515, 455, 517, 458, 520, 459, 521, 465, 522, 467, 524, 470, 528, 470, 534, 469, 538, 471, 542, 473, 546, 474, 550, 478, 553, 480, 556, 483, 557, 485, 560, 485, 563, 485, 565, 483, 567, 481, 568, 478, 568, 474, 566, 472, 562, 468, 557, 466, 556, 463, 553, 458, 549, 454, 546, 449, 543, 447, 540, 445, 539, 441, 539, 440, 543, 442, 547, 444, 552, 448, 554, 451, 558, 456, 559, 462, 564, 464, 569, 464, 571, 462, 574, 458, 577, 455, 579, 460, 580, 462, 582, 463, 583, 465, 585, 467, 586, 471, 586, 475, 583, 479, 584, 480, 581, 482, 579, 485, 578, 490, 581, 491, 582, 491, 587, 489, 588, 489, 590, 491, 592, 493, 597, 493, 598, 490, 602, 489, 604, 492, 607, 493, 613, 492, 615, 487, 615, 486, 613, 477, 611, 469, 612, 456, 606, 452, 606, 449, 607, 445, 611, 440, 609, 437, 610, 433, 606, 429, 601, 424, 594, 416, 585, 411, 580, 412, 569, 411, 561, 409, 556, 413, 549, 415, 538, 414, 528, 416, 522],
                            "tip": {"lvl": {"min": 35, "max": 40}, "faction": "neutral", "quest": [102, 6, 5]}
                        },
                        "16": {
                            "name": "Azshara",
                            "points": [464, 299, 464, 305, 465, 310, 467, 313, 467, 317, 465, 321, 463, 325, 458, 335, 455, 341, 455, 351, 454, 358, 455, 362, 458, 367, 464, 365, 464, 362, 468, 358, 473, 355, 479, 354, 486, 353, 490, 350, 499, 353, 506, 355, 511, 353, 521, 346, 523, 350, 530, 349, 540, 351, 553, 348, 552, 352, 548, 357, 544, 360, 542, 364, 552, 363, 562, 360, 570, 356, 574, 354, 579, 350, 581, 348, 578, 344, 576, 339, 576, 335, 576, 333, 579, 332, 583, 330, 585, 330, 588, 331, 593, 327, 597, 325, 601, 325, 606, 323, 610, 323, 614, 321, 617, 319, 619, 315, 620, 310, 619, 303, 619, 297, 616, 294, 606, 282, 608, 281, 606, 281, 603, 272, 598, 268, 593, 264, 590, 261, 586, 259, 577, 256, 572, 253, 563, 253, 559, 254, 557, 256, 555, 260, 553, 257, 547, 256, 543, 257, 540, 262, 538, 260, 532, 260, 522, 262, 518, 264, 510, 266, 505, 269, 503, 272, 499, 278, 498, 283, 495, 288, 487, 292, 478, 293, 469, 297],
                            "tip": {"lvl": {"min": 10, "max": 20}, "faction": "horde", "quest": [114, 0, 2]}
                        },
                        "17": {
                            "name": "Northern Barrens",
                            "points": [358, 381, 363, 379, 366, 381, 370, 385, 376, 386, 382, 387, 391, 389, 396, 387, 402, 382, 409, 381, 417, 379, 422, 376, 431, 374, 440, 369, 446, 365, 452, 366, 456, 374, 459, 379, 456, 384, 455, 390, 453, 401, 452, 409, 452, 416, 451, 424, 453, 435, 455, 442, 459, 448, 461, 457, 458, 461, 453, 464, 454, 468, 455, 472, 460, 475, 464, 478, 461, 487, 460, 492, 452, 492, 443, 490, 432, 488, 424, 488, 418, 484, 412, 479, 406, 475, 400, 473, 396, 472, 395, 467, 391, 462, 387, 455, 385, 444, 383, 441, 379, 436, 371, 432, 363, 431, 364, 428, 361, 422, 358, 419, 354, 415, 352, 412, 353, 402, 354, 393, 356, 387],
                            "tip": {"lvl": {"min": 10, "max": 20}, "faction": "horde", "quest": [71, 7, 3]}
                        },
                        "141": {
                            "name": "Teldrassil",
                            "points": [225, 98, 231, 107, 236, 111, 242, 110, 242, 120, 248, 128, 258, 132, 265, 130, 267, 121, 273, 130, 278, 130, 285, 126, 292, 126, 299, 124, 306, 117, 316, 112, 323, 106, 326, 96, 330, 84, 330, 77, 324, 72, 322, 65, 320, 55, 311, 49, 304, 45, 297, 39, 286, 39, 278, 37, 273, 39, 266, 39, 262, 37, 256, 40, 254, 41, 251, 45, 247, 53, 243, 54, 240, 60, 240, 65, 228, 69, 224, 76, 224, 85, 223, 95],
                            "tip": {"lvl": {"min": 1, "max": 10}, "faction": "alliance", "quest": [36, 1, 2]}
                        },
                        "148": {
                            "name": "Darkshore",
                            "points": [295, 294, 301, 293, 305, 290, 312, 286, 321, 284, 327, 282, 329, 275, 331, 268, 332, 260, 333, 250, 332, 241, 333, 233, 337, 225, 338, 218, 340, 213, 339, 206, 343, 204, 348, 200, 351, 195, 354, 189, 360, 185, 366, 184, 369, 185, 377, 184, 383, 183, 388, 182, 393, 182, 395, 179, 396, 172, 392, 167, 392, 154, 392, 146, 391, 141, 385, 141, 381, 146, 374, 149, 369, 151, 364, 152, 358, 156, 356, 161, 350, 165, 341, 172, 333, 174, 323, 173, 319, 178, 315, 181, 315, 191, 307, 188, 304, 194, 301, 197, 305, 202, 298, 206, 298, 210, 299, 211, 303, 213, 303, 218, 303, 223, 303, 232, 304, 239, 306, 247, 307, 252, 311, 257, 311, 261, 307, 263, 302, 260, 301, 264, 298, 268, 297, 268, 292, 269, 288, 272, 286, 277, 283, 282, 284, 285, 287, 288, 287, 292, 293, 292],
                            "tip": {"lvl": {"min": 10, "max": 20}, "faction": "alliance", "quest": [91, 8, 1]}
                        },
                        "215": {
                            "name": "Mulgore",
                            "points": [315, 442, 323, 443, 331, 444, 341, 443, 349, 442, 349, 446, 352, 452, 355, 454, 359, 458, 362, 460, 365, 463, 365, 467, 365, 473, 363, 482, 363, 488, 365, 493, 368, 498, 371, 503, 376, 512, 378, 524, 376, 528, 368, 530, 363, 531, 363, 535, 362, 540, 362, 549, 360, 552, 356, 555, 355, 559, 355, 563, 345, 566, 340, 568, 328, 563, 318, 559, 312, 550, 309, 538, 309, 528, 310, 516, 311, 508, 309, 502, 307, 497, 307, 490, 311, 485, 308, 480, 304, 473, 303, 460, 308, 454, 311, 447, 312, 442],
                            "tip": {"lvl": {"min": 1, "max": 10}, "faction": "horde", "quest": [43, 1, 0]}
                        },
                        "331": {
                            "name": "Ashenvale",
                            "points": [299, 294, 303, 292, 308, 290, 308, 288, 312, 286, 319, 283, 322, 282, 326, 280, 327, 287, 330, 291, 336, 294, 341, 296, 344, 301, 349, 308, 356, 312, 369, 318, 369, 313, 375, 311, 381, 313, 388, 313, 392, 319, 400, 323, 408, 325, 414, 322, 425, 323, 434, 322, 440, 316, 446, 311, 454, 303, 462, 310, 464, 319, 458, 328, 454, 334, 452, 339, 449, 347, 448, 353, 450, 360, 450, 365, 446, 367, 440, 369, 436, 373, 428, 376, 421, 378, 418, 381, 411, 383, 403, 384, 398, 389, 392, 390, 385, 389, 380, 387, 374, 388, 370, 386, 369, 384, 366, 382, 362, 381, 357, 381, 356, 377, 348, 372, 344, 371, 340, 371, 331, 369, 324, 371, 311, 366, 301, 359, 296, 349, 294, 345, 286, 336, 275, 327, 275, 321, 285, 318, 291, 313, 295, 302, 295, 298],
                            "tip": {"lvl": {"min": 20, "max": 25}, "faction": "neutral", "quest": [135, 14, 4]}
                        },
                        "357": {
                            "name": "Feralas",
                            "points": [249, 656, 251, 652, 252, 647, 254, 644, 256, 640, 263, 638, 267, 637, 271, 638, 273, 639, 277, 640, 280, 640, 282, 640, 285, 640, 287, 638, 290, 636, 291, 633, 294, 633, 296, 634, 301, 633, 306, 632, 312, 632, 316, 632, 320, 632, 323, 632, 328, 632, 331, 632, 336, 632, 341, 632, 344, 632, 345, 632, 346, 632, 347, 632, 355, 632, 355, 631, 356, 629, 356, 626, 356, 624, 355, 623, 353, 621, 352, 621, 350, 620, 349, 619, 346, 618, 345, 617, 344, 614, 344, 612, 344, 610, 344, 606, 344, 605, 345, 601, 346, 598, 346, 595, 347, 592, 347, 590, 348, 587, 349, 584, 350, 580, 352, 573, 352, 573, 354, 573, 357, 574, 359, 575, 361, 574, 362, 571, 362, 570, 360, 569, 358, 567, 357, 566, 354, 566, 352, 565, 349, 565, 345, 565, 341, 567, 339, 566, 335, 565, 332, 563, 325, 561, 319, 559, 317, 557, 316, 554, 314, 549, 312, 543, 310, 541, 309, 539, 308, 535, 309, 531, 309, 522, 308, 521, 308, 516, 309, 514, 305, 517, 303, 519, 300, 520, 295, 521, 289, 522, 287, 522, 282, 522, 280, 521, 276, 518, 272, 516, 268, 516, 265, 514, 261, 513, 259, 513, 257, 512, 254, 513, 252, 513, 247, 514, 246, 514, 240, 516, 238, 516, 233, 517, 226, 518, 224, 518, 223, 518, 219, 518, 216, 521, 215, 522, 215, 523, 215, 526, 215, 529, 215, 530, 215, 532, 215, 536, 217, 543, 218, 547, 218, 549, 219, 553, 219, 555, 220, 557, 221, 559, 222, 560, 222, 561, 223, 562, 228, 562, 229, 563, 231, 565, 233, 566, 235, 567, 236, 569, 237, 570, 238, 571, 239, 573, 240, 574, 241, 575, 242, 577, 243, 579, 243, 581, 243, 583, 241, 583, 238, 583, 237, 583, 234, 583, 232, 583, 231, 583, 230, 581, 228, 579, 228, 578, 226, 577, 225, 576, 222, 574, 221, 574, 219, 573, 218, 572, 217, 572, 216, 572, 213, 572, 211, 572, 207, 572, 206, 572, 202, 572, 201, 572, 199, 573, 196, 574, 193, 576, 192, 577, 192, 577, 192, 580, 190, 581, 189, 586, 189, 588, 188, 590, 188, 595, 187, 596, 187, 602, 186, 606, 186, 608, 185, 612, 185, 617, 185, 618, 186, 621, 186, 623, 186, 625, 186, 628, 186, 630, 186, 634, 187, 638, 187, 641, 187, 642, 188, 647, 188, 649, 188, 651, 188, 653, 188, 656, 188, 656, 188, 659, 189, 661, 191, 666, 193, 669, 195, 670, 197, 671, 199, 672, 201, 672, 204, 673, 206, 673, 208, 673, 209, 673, 211, 673, 216, 671, 219, 671, 222, 670, 223, 668, 224, 666, 224, 665, 225, 663, 226, 662, 226, 661, 227, 658, 228, 656, 228, 655, 228, 653, 229, 650, 228, 649, 227, 644, 227, 642, 227, 639, 227, 637, 227, 632, 228, 629, 226, 628, 226, 626, 226, 623, 225, 622, 224, 621, 223, 616, 221, 613, 221, 611, 220, 609, 220, 606, 220, 604, 220, 600, 221, 598, 222, 595, 223, 591, 224, 590, 225, 586, 225, 584, 226, 584, 227, 584, 228, 584, 229, 583, 230, 583, 231, 584, 232, 583, 243, 583, 243, 584, 243, 585, 243, 587, 244, 590, 245, 591, 244, 594, 246, 597, 248, 600, 249, 601, 250, 602, 251, 603, 252, 605, 252, 607, 251, 609, 249, 612, 248, 615, 247, 620, 247, 622, 247, 624, 246, 629, 246, 632, 246, 634, 244, 637, 244, 638, 243, 640, 243, 643, 242, 646, 242, 647, 243, 649, 243, 650, 246, 652, 247, 656],
                            "tip": {"lvl": {"min": 35, "max": 40}, "faction": "neutral", "quest": [94, 0, 3]}
                        },
                        "361": {
                            "name": "Felwood",
                            "points": [395, 182, 398, 189, 398, 195, 399, 198, 401, 203, 402, 210, 400, 215, 396, 222, 391, 225, 383, 229, 374, 235, 367, 240, 362, 247, 358, 256, 364, 264, 366, 272, 367, 279, 371, 283, 377, 284, 381, 288, 385, 291, 391, 297, 390, 307, 388, 315, 379, 312, 373, 312, 368, 315, 358, 316, 351, 311, 340, 300, 339, 295, 334, 293, 330, 289, 328, 279, 328, 272, 328, 265, 329, 257, 329, 249, 328, 240, 329, 227, 332, 217, 337, 207, 341, 200, 349, 194, 354, 189, 363, 184, 369, 186, 378, 185, 384, 183, 392, 183],
                            "tip": {"lvl": {"min": 45, "max": 50}, "faction": "neutral", "quest": [81, 0, 1]}
                        },
                        "400": {
                            "name": "Thousand Needles",
                            "points": [351, 578, 358, 580, 362, 582, 371, 585, 377, 590, 388, 588, 393, 594, 400, 600, 408, 604, 417, 609, 424, 611, 428, 606, 433, 608, 437, 610, 448, 609, 451, 608, 457, 605, 465, 608, 470, 611, 482, 613, 489, 617, 490, 622, 489, 628, 482, 632, 485, 635, 490, 637, 492, 646, 489, 650, 482, 659, 470, 661, 461, 665, 451, 670, 443, 668, 437, 660, 436, 651, 430, 642, 420, 638, 410, 636, 405, 639, 397, 644, 388, 642, 373, 637, 363, 634, 357, 634, 357, 630, 352, 622, 347, 616, 344, 607, 347, 597, 349, 588, 349, 583],
                            "tip": {"lvl": {"min": 40, "max": 45}, "faction": "neutral", "quest": [105, 7, 0]}
                        },
                        "405": {
                            "name": "Desolace",
                            "points": [252, 420, 257, 420, 260, 423, 266, 420, 274, 420, 277, 417, 283, 415, 285, 418, 293, 419, 298, 421, 302, 424, 306, 428, 308, 434, 310, 439, 311, 445, 307, 450, 304, 456, 301, 463, 302, 472, 304, 476, 309, 480, 308, 486, 307, 490, 307, 496, 308, 502, 309, 506, 309, 511, 301, 519, 292, 521, 285, 523, 274, 519, 266, 516, 258, 514, 249, 514, 240, 516, 226, 517, 217, 520, 215, 519, 214, 510, 213, 505, 218, 497, 218, 493, 214, 488, 211, 473, 214, 472, 216, 466, 217, 461, 225, 458, 235, 454, 235, 448, 237, 442, 242, 438, 249, 432, 251, 427, 251, 422],
                            "tip": {"lvl": {"min": 30, "max": 35}, "faction": "neutral", "quest": [84, 8, 4]}
                        },
                        "406": {
                            "name": "Stonetalon Mountains",
                            "points": [329, 372, 336, 372, 340, 371, 346, 371, 351, 374, 355, 376, 356, 386, 355, 398, 354, 407, 354, 412, 355, 417, 359, 421, 363, 426, 364, 429, 362, 432, 359, 438, 355, 440, 348, 444, 335, 445, 325, 444, 315, 442, 311, 440, 305, 431, 304, 425, 299, 422, 290, 419, 280, 419, 269, 419, 257, 420, 248, 420, 240, 415, 240, 409, 244, 399, 248, 392, 245, 389, 243, 382, 238, 375, 238, 370, 232, 361, 228, 355, 222, 347, 218, 336, 224, 326, 231, 321, 242, 320, 253, 318, 264, 319, 271, 323, 276, 328, 281, 330, 285, 331, 289, 337, 291, 342, 295, 350, 301, 356, 305, 362, 315, 367, 325, 370],
                            "tip": {"lvl": {"min": 25, "max": 30}, "faction": "neutral", "quest": [79, 10, 17]}
                        },
                        "440": {
                            "name": "Tanaris",
                            "points": [402, 643, 402, 649, 405, 656, 412, 665, 412, 677, 413, 689, 409, 700, 399, 712, 385, 725, 389, 729, 392, 737, 396, 742, 395, 749, 394, 756, 399, 761, 410, 763, 416, 765, 423, 768, 426, 776, 428, 783, 436, 770, 442, 770, 446, 775, 452, 785, 460, 785, 469, 782, 474, 773, 475, 764, 481, 747, 480, 739, 486, 733, 496, 724, 504, 716, 510, 710, 506, 706, 500, 702, 491, 699, 488, 703, 479, 706, 467, 706, 460, 702, 458, 694, 457, 686, 459, 677, 462, 673, 474, 669, 484, 667, 489, 665, 486, 661, 481, 661, 472, 663, 467, 665, 458, 668, 453, 669, 445, 664, 435, 661, 435, 655, 432, 650, 429, 645, 423, 641, 415, 640, 405, 641],
                            "tip": {"lvl": {"min": 45, "max": 50}, "faction": "neutral", "quest": [76, 7, 0]}
                        },
                        "490": {
                            "name": "Un'Goro Crater",
                            "points": [355, 635, 347, 645, 338, 655, 335, 662, 330, 665, 327, 668, 327, 682, 329, 693, 329, 708, 332, 711, 354, 717, 365, 721, 373, 721, 381, 718, 390, 718, 395, 718, 400, 709, 405, 705, 413, 695, 413, 684, 415, 671, 410, 661, 403, 655, 400, 645, 396, 644, 381, 639, 371, 636],
                            "tip": {"lvl": {"min": 50, "max": 55}, "faction": "neutral", "quest": [58, 2, 2]}
                        },
                        "493": {
                            "name": "Moonglade",
                            "points": [390, 142, 391, 153, 391, 162, 397, 182, 399, 180, 415, 184, 429, 182, 437, 177, 441, 165, 443, 157, 442, 145, 439, 134, 435, 127, 425, 126, 420, 130, 404, 133, 394, 137, 390, 139],
                            "tip": {"lvl": {"min": 55, "max": 60}, "faction": "neutral", "quest": [0, 0, 0]}
                        },
                        "616": {
                            "name": "Mount Hyjal",
                            "points": [398, 224, 408, 222, 415, 223, 423, 220, 427, 218, 434, 217, 443, 221, 449, 223, 456, 225, 461, 227, 466, 235, 469, 241, 473, 249, 473, 256, 479, 258, 487, 258, 494, 262, 498, 268, 503, 272, 503, 275, 499, 280, 496, 286, 490, 293, 483, 295, 474, 297, 464, 301, 461, 300, 454, 299, 447, 306, 444, 311, 437, 319, 430, 323, 422, 322, 407, 325, 402, 324, 392, 318, 389, 311, 388, 304, 388, 295, 385, 290, 375, 283, 365, 277, 364, 268, 360, 262, 359, 256, 359, 251, 361, 241, 367, 237, 375, 233, 386, 230, 393, 226],
                            "tip": {"lvl": {"min": 80, "max": 82}, "faction": "neutral", "quest": [134, 13, 0]}
                        },
                        "618": {
                            "name": "Winterspring",
                            "points": [441, 130, 442, 139, 443, 152, 442, 158, 440, 172, 432, 180, 420, 183, 402, 182, 395, 183, 398, 192, 400, 200, 401, 212, 398, 218, 396, 224, 401, 222, 414, 222, 423, 219, 428, 218, 441, 220, 448, 222, 461, 226, 465, 232, 469, 241, 471, 248, 473, 253, 476, 255, 485, 257, 491, 259, 496, 265, 503, 272, 505, 262, 511, 256, 511, 248, 517, 239, 521, 235, 527, 226, 526, 215, 521, 205, 518, 200, 515, 192, 520, 186, 525, 171, 531, 161, 525, 150, 515, 146, 505, 143, 498, 137, 487, 132, 481, 131, 472, 124, 467, 117, 459, 118, 451, 121, 442, 128],
                            "tip": {"lvl": {"min": 50, "max": 55}, "faction": "neutral", "quest": [82, 0, 2]}
                        },
                        "1377": {
                            "name": "Silithus",
                            "points": [249, 657, 255, 641, 261, 640, 268, 639, 276, 639, 283, 641, 292, 638, 295, 635, 304, 633, 317, 633, 333, 633, 347, 634, 355, 634, 348, 644, 339, 652, 331, 662, 327, 670, 327, 679, 328, 687, 326, 700, 325, 711, 316, 717, 312, 717, 307, 715, 300, 713, 295, 714, 290, 715, 281, 716, 275, 713, 267, 713, 256, 711, 242, 712, 238, 715, 231, 715, 227, 718, 219, 717, 220, 711, 221, 704, 225, 697, 228, 689, 230, 683, 235, 676, 240, 669, 243, 663, 246, 662, 250, 660],
                            "tip": {"lvl": {"min": 55, "max": 60}, "faction": "neutral", "quest": [29, 1, 0]}
                        },
                        "3524": {
                            "name": "Azuremyst Isle",
                            "points": [104, 201, 113, 206, 119, 205, 127, 206, 130, 198, 132, 191, 141, 186, 148, 187, 156, 189, 163, 193, 170, 199, 176, 204, 182, 209, 195, 212, 202, 213, 205, 220, 205, 230, 203, 234, 207, 235, 206, 242, 200, 247, 199, 252, 196, 245, 194, 241, 187, 240, 180, 241, 181, 244, 170, 243, 168, 240, 161, 243, 154, 244, 144, 246, 140, 247, 132, 251, 131, 255, 124, 255, 118, 253, 113, 249, 112, 245, 112, 236, 114, 225, 111, 216, 106, 213, 102, 212, 101, 205],
                            "tip": {"lvl": {"min": 1, "max": 10}, "faction": "alliance", "quest": [48, 1, 0]}
                        },
                        "3525": {
                            "name": "Bloodmyst Isle",
                            "points": [85, 124, 84, 131, 81, 136, 82, 148, 78, 153, 80, 158, 84, 159, 88, 157, 93, 158, 99, 159, 100, 164, 99, 174, 102, 170, 105, 174, 106, 177, 113, 177, 121, 178, 122, 170, 125, 167, 129, 174, 134, 176, 141, 175, 146, 170, 146, 160, 142, 155, 140, 149, 138, 141, 148, 132, 152, 129, 153, 120, 154, 115, 152, 111, 146, 115, 137, 121, 127, 126, 119, 128, 110, 130, 102, 131, 95, 131, 92, 128, 89, 124],
                            "tip": {"lvl": {"min": 10, "max": 20}, "faction": "alliance", "quest": [64, 4, 1]}
                        },
                        "4709": {
                            "name": "Southern Barrens",
                            "points": [350, 445, 353, 440, 356, 441, 359, 435, 361, 433, 367, 432, 376, 435, 379, 438, 382, 444, 387, 451, 388, 457, 393, 467, 396, 472, 403, 475, 411, 481, 421, 484, 427, 486, 437, 487, 442, 488, 446, 490, 451, 493, 453, 496, 453, 503, 455, 507, 455, 512, 450, 513, 444, 513, 437, 510, 432, 506, 416, 521, 416, 531, 415, 539, 413, 545, 412, 551, 409, 555, 411, 562, 414, 567, 411, 574, 413, 581, 414, 584, 420, 588, 424, 593, 427, 597, 429, 600, 427, 604, 423, 607, 417, 609, 412, 605, 405, 600, 398, 596, 391, 590, 389, 588, 380, 587, 372, 588, 365, 582, 365, 576, 364, 572, 361, 568, 357, 564, 356, 560, 357, 556, 365, 550, 362, 550, 363, 543, 363, 535, 366, 528, 370, 527, 375, 529, 377, 525, 378, 518, 376, 509, 372, 503, 365, 491, 362, 479, 365, 469, 364, 462, 360, 459, 355, 455, 351, 449],
                            "tip": {"lvl": {"min": 30, "max": 35}, "faction": "neutral", "quest": [81, 10, 10]}
                        },
                        "5034": {
                            "name": "Uldum",
                            "points": [289, 718, 294, 715, 298, 714, 300, 713, 303, 717, 306, 714, 309, 716, 313, 719, 317, 718, 319, 716, 320, 715, 321, 717, 323, 715, 325, 713, 328, 713, 331, 713, 334, 715, 336, 717, 340, 714, 345, 716, 348, 717, 351, 718, 355, 718, 358, 719, 362, 721, 369, 723, 373, 724, 374, 722, 379, 720, 382, 720, 385, 719, 387, 719, 387, 723, 388, 726, 388, 729, 388, 731, 391, 733, 393, 737, 394, 740, 395, 743, 394, 748, 393, 752, 395, 755, 396, 759, 400, 760, 404, 762, 407, 763, 410, 763, 416, 765, 420, 766, 423, 768, 424, 771, 425, 773, 426, 776, 428, 782, 427, 786, 427, 790, 425, 793, 423, 796, 421, 800, 420, 803, 417, 805, 414, 805, 410, 808, 405, 810, 401, 813, 396, 816, 395, 818, 392, 819, 386, 820, 381, 823, 379, 826, 375, 829, 374, 831, 367, 831, 362, 830, 356, 830, 351, 830, 345, 830, 343, 830, 341, 826, 340, 822, 338, 819, 335, 818, 329, 815, 323, 812, 321, 810, 315, 810, 311, 809, 307, 805, 303, 802, 298, 801, 293, 800, 288, 799, 285, 800, 278, 799, 274, 797, 273, 795, 269, 790, 269, 786, 269, 782, 274, 778, 277, 776, 281, 773, 284, 770, 288, 767, 291, 764, 293, 760, 293, 756, 294, 753, 294, 748, 294, 744, 295, 742, 297, 740, 299, 737, 297, 733, 296, 729, 294, 725, 292, 723, 290, 721],
                            "tip": {"lvl": {"min": 83, "max": 85}, "faction": "neutral", "quest": [112, 3, 0]}
                        }
                    },
                    "marks": {
                        "5": {
                            "name": "Orgrimmar",
                            "points": [471, 374],
                            "type": "h_capital",
                            "desc": "The capital city of the orcs, and the Horde as a whole. Found at the northern edge of Durotar, the imposing city is home to the newly appointed Warchief, Garrosh Hellscream. As with all capital cities, it has banks, class and profession trainers and auction houses.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 9
                        },
                        "6": {
                            "name": "The Exodar",
                            "points": [120, 219],
                            "type": "a_capital",
                            "desc": "The capital city of the draenei who chose to depart from Draenor. Formerly a dimensional ship satellite structure of the dimensional fortress known as Tempest Keep, it recently crashed on Azeroth.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 8
                        },
                        "7": {
                            "name": "Darnassus",
                            "points": [235, 86],
                            "type": "a_capital",
                            "desc": "The capital city of the night elves of the Alliance. The high priestess, Tyrande Whisperwind and the Archdruid Malfurion Stormrage reside in the Temple of the Moon surrounded by sisters of Elune and Draenei ambassadors.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 8
                        },
                        "8": {
                            "name": "Thunder Bluff",
                            "points": [319, 472],
                            "type": "h_capital",
                            "desc": "The tauren capital city located in the northern part of the region of Mulgore on the continent of Kalimdor. The entire city is built on bluffs several hundred feet above the surrounding landscape, and is accessible by elevators on the southwestern and northeastern sides.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 9
                        },
                        "12": {
                            "name": "Halls of Origination",
                            "points": [345, 746],
                            "type": "pin-red",
                            "desc": "The Halls of Origination are part of the Titan research facility of Uldum. Along with Ulduar and Uldaman, it was used by the Titans thousands of years ago. Unlike the other two, the Halls' purpose was not to be a prison--it was used for research and development of new races. One of those races was the Tol'vir - a mix between humans and cats, most of which populate the other Uldum dungeon, the Lost City of the Tol'vir, where it is rumored that a deadly secret is hidden. ",
                            "icon": "boss",
                            "lvl": {"min": 84, "max": 85},
                            "filter": 4
                        },
                        "13": {
                            "name": "The Vortex Pinnacle",
                            "points": [405, 823],
                            "type": "pin-red",
                            "desc": "The Vortex Pinnacle is a level 82-84 5-man dungeon located inside the Skywall, the air domain of the Elemental Plane. The entrance can be found in the skies of Uldum. Here Al'Akir's armies of air elementals and commanders below the top of the chain gather their strength.",
                            "icon": "boss",
                            "lvl": {"min": 82, "max": 84},
                            "filter": 4
                        },
                        "14": {
                            "name": "Ragefire Chasm",
                            "points": [483, 374],
                            "type": "pin-yellow",
                            "desc": "Ragefire Chasm (RFC) is an dungeon located in Orgrimmar, and contains demons and dark magic that parties must face and defeat. The entry portal is in the Cleft of Shadow, next to Neeru Fireblade's tent. ",
                            "icon": "boss",
                            "lvl": {"min": 15, "max": 20},
                            "filter": 7
                        },
                        "31": {
                            "name": "Wailing Caverns",
                            "points": [393, 403],
                            "type": "pin-yellow",
                            "desc": "A winding mess of catacombs, Wailing Caverns is a highly atmospheric dungeon located in the Northern Barrens. It was recently changed in Cataclysm to be more straight forward and many bosses were moved, largely because of adventurers getting lost in its confusing structure.",
                            "icon": "boss",
                            "lvl": {"min": 15, "max": 20},
                            "filter": 7
                        },
                        "32": {
                            "name": "Blackfathom Deeps",
                            "points": [316, 283],
                            "type": "pin-yellow",
                            "desc": "Blackfathom Deeps (BFD) is a partially underwater dungeon in northwestern Ashenvale. It is accessed by a stair-lined shaft that requires one to swim through an underwater entrance. The Deeps are comprised of a series of watery caverns leading deep to a temple devoted to the Old Gods. The Twilight's Hammer cult runs this shrine, and joined forces with local naga and satyr to defend the holy creature, Aku'mai.",
                            "icon": "boss",
                            "lvl": {"min": 18, "max": 25},
                            "filter": 7
                        },
                        "33": {
                            "name": "Razorfen Kraul",
                            "points": [390, 570],
                            "type": "pin-yellow",
                            "desc": "Razorfen Kraul (RFK) is the ancestral home of the quilboar, obscured by thorns that grew from the corpse of the demigod Agamaggan. It is found in the lower region of Southern Barrens. Parties that journey here must navigate the confusing tunnels and defeat the quilboar bosses found inside.",
                            "icon": "boss",
                            "lvl": {"min": 21, "max": 35},
                            "filter": 7
                        },
                        "34": {
                            "name": "Maraudon",
                            "points": [226, 476],
                            "type": "pin-yellow",
                            "desc": "Maraudon is a system of caverns located in the Valley of Spears, east of Shadowprey Village in Desolace. It is a combination of ancient centaur burial grounds and a temple dedicated to the elemental earth. Maraudon is broken up into different levels and zones; since Cataclysm, these have been remodeled and retooled to be a smoother experience for adventurers. There are two entrances to the dungeon, one through a pathway lined with orange crystals while the other is lined with purple ones, though the entire instance can be accessed while inside, regardless of the entrance used.",
                            "icon": "boss",
                            "lvl": {"min": 30, "max": 44},
                            "filter": 7
                        },
                        "35": {
                            "name": "Dire Maul",
                            "points": [279, 569],
                            "type": "pin-yellow",
                            "desc": "Dire Maul is an ancient night elf city turned to ruins located in Feralas; split into three different zones, it's overrun with ogre tribes, ghosts of its prior inhabitants, and elementals.",
                            "icon": "boss",
                            "lvl": {"min": 36, "max": 52},
                            "filter": 7
                        },
                        "36": {
                            "name": "Razorfen Downs",
                            "points": [365, 562],
                            "type": "pin-yellow",
                            "desc": "Razorfen Downs (RFD) is the capital of the quilboar, hidden within brambles and tunnels in Thousand Needles. The Scourge has taken over much of the Downs and, as such, the mobs that populate Razorfen Downs are predominantly undead. Parties must navigate the tunnels to defeat the quilboar and undead residing within Razorfen Downs.",
                            "icon": "boss",
                            "lvl": {"min": 35, "max": 45},
                            "filter": 7
                        },
                        "37": {
                            "name": "Zul'Farrak",
                            "points": [415, 654],
                            "type": "pin-yellow",
                            "desc": "Zul'Farrak is a troll city located in northwestern Tanaris. Due to its massive size, players can use mounts in the zone. While the bosses can be defeated in any order, the instance comes to a climax when players are able to rescue a band of mercenaries trapped in cages by the Sandfury trolls. This is particularly notable as it was one of World of Warcraft's first scripted events.",
                            "icon": "boss",
                            "lvl": {"min": 39, "max": 44},
                            "filter": 7
                        },
                        "38": {
                            "name": "The Black Morass",
                            "points": [462, 716],
                            "type": "pin-green",
                            "desc": "Located in the eastern part of Tanaris, the Caverns of Time (CoT) contain various portals to different key time periods and events in Warcraft history. The caverns act as a crossroads for the various timelines--through them one can travel back and forth along the ebb and flow of time. The Caverns of Time are home to the Brood of Nozdormu and the bronze dragonflight. It is their sacred charge to guard the caverns against the intrusion of mortals, whose interference would assuredly disrupt the flow of time. Recently, a mysterious force called the Infinite Dragonflight has begun to meddle with time.",
                            "icon": "boss",
                            "lvl": {"min": 65, "max": 70},
                            "filter": 6
                        },
                        "39": {
                            "name": "Old Hillsbrad Foothills",
                            "points": [468, 708],
                            "type": "pin-green",
                            "desc": "Located in the eastern part of Tanaris, the Caverns of Time contain various portals to different key time periods and events in Warcraft history. The caverns act as a crossroads for the various timelines--through them one can travel back and forth along the ebb and flow of time. Old Hillsbrad Foothills is one of the timeways accessible in the Caverns of Time. The setting is seven years before WoW's present, to when the future Warchief Thrall was a slave of Aedelas Blackmoore, master of Durnholde Keep. The questing involves helping Thrall escape. The instance area in question spans from Southshore (where familiar personalities of WoW present can be found) to Tarren Mill.",
                            "icon": "boss",
                            "lvl": {"min": 63, "max": 70},
                            "filter": 6
                        },
                        "40": {
                            "name": "Culling of Stratholme",
                            "points": [473, 716],
                            "type": "pin-blue",
                            "desc": "Located in the eastern part of Tanaris, the Caverns of Time contain various portals to different key time periods and events in Warcraft history. The caverns act as a crossroads for the various timelines; through them one can travel back and forth across time. The Caverns of Time are home to the Brood of Nozdormu and the bronze dragonflight. Recently, a mysterious force called the Infinite Dragonflight has begun to meddle with time--the bronze dragonflight is recruiting heroes to make sure that the events that took place in the past remain as they were.",
                            "icon": "boss",
                            "lvl": {"min": 79, "max": 80},
                            "filter": 5
                        },
                        "41": {
                            "name": "Lost City of the Tol'vir",
                            "points": [345, 781],
                            "type": "pin-red",
                            "desc": "The Lost City of the Tol'vir is one of the three 5-man dungeons in Uldum. On Normal-mode it is designed for level 84-85 players. The dungeon is populated by a faction of the Tol'vir, the Neferset--a mysterious race of \"cat-people\" created eons ago by the Titans to maintain and safeguard their research facilities in Uldum. The Neferset initially swore loyalty to Deathwing but after their betrayal, are now hostile to all.",
                            "icon": "boss",
                            "lvl": {"min": 84, "max": 85},
                            "filter": 4
                        },
                        "72": {
                            "name": "Ruins of Ahn'Qiraj",
                            "points": [236, 702],
                            "type": "pin-purple",
                            "desc": "The Ruins of Ahn'Qiraj (AQ20) is a 20-man outdoor raid dungeon located in southern Silithus. It was released with Patch 1.9 during a massive world event called the Gates of Ahn'Qiraj. It was meant to serve as a dual instance to the original Zul'Gurub, allowing more casual players to raid with lower numbers for lesser gear.",
                            "icon": "boss",
                            "lvl": {"min": 60, "max": 60},
                            "filter": 13
                        },
                        "73": {
                            "name": "Temple of Ahn'Qiraj",
                            "points": [245, 702],
                            "type": "pin-purple",
                            "desc": "Temple of Ahn'Qiraj (AQ40) is a 40-man raid dungeon located in southwestern Silithus. It was released during a massive world event called the Gates of Ahn'Qiraj in which players rang a gong to receive a legendary silithid mount.",
                            "icon": "boss",
                            "lvl": {"min": 60, "max": 60},
                            "filter": 13
                        },
                        "74": {
                            "name": "Hyjal Summit",
                            "points": [468, 724],
                            "type": "pin-purple",
                            "desc": "Hyjal is the site of Nordrassil, the first World Tree. It's brought back through the Caverns of Time so that players can relive the major event of Warcraft history, fighting with famous figures such as Jaina and Thrall.",
                            "icon": "boss",
                            "lvl": {"min": 70, "max": 70},
                            "filter": 12
                        },
                        "75": {
                            "name": "Onyxia's Lair",
                            "points": [437, 567],
                            "type": "pin-purple",
                            "desc": "Onyxia's Lair is a small cave system located in the southern parts of Dustwallow Marsh. It is home to Onyxia and her guards, the remaining members of the insidious Black Dragonflight. There also her brood of new eggs is hidden, awaiting maturation. Should anyone ever threaten Onyxia within her lair - within distance of her precious eggs - her wrath would be terrible beyond comprehension.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 11
                        },
                        "76": {
                            "name": "Throne of the Four Winds",
                            "points": [293, 800],
                            "type": "pin-purple",
                            "desc": "The Throne of the Four Winds is a Tier 11 raid dungeon located inside the Skywall, a floating area reached by flying in Southern Uldum. It features only two boss encounters--the Conclave of Wind (a Djinn Council that must die at the same time) and the elemental Lord of Air, Al'Akir. This zone was controversial for having all pieces of loot have random stats--some items were BiS, others had awful combinations.",
                            "icon": "boss",
                            "lvl": {"min": 85, "max": 85},
                            "filter": 10
                        },
                        "96": {
                            "name": "Ratchet",
                            "points": [442, 457],
                            "type": "village",
                            "desc": "Situated on the east road from the Crossroads, Ratchet is the first neutral settlement that most Horde players will come across in their travels. Most of the quests available cater for players between levels 15 and 25, but there are a few higher level quests that emerge later on in the game. Ratchet is a port town governed by the trade princes. It is a neutral town populated mostly by goblins, so all races are welcome there, no matter how much gold they have to spend.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "97": {
                            "name": "The Crossroads",
                            "points": [402, 416],
                            "type": "village",
                            "desc": "The Crossroads is the largest Horde town in the Barrens, aptly named for the crossing of the main north-south road (from the Gold Road) and the road from Ratchet in the east all the way to the Stonetalon Mountains in the west. Combined with its central location and the Wyvern flight routes, the Crossroads offers access to nearly all Horde outposts in Kalimdor. As such, this small crossing is the usually the first place you will see large gatherings of players outside of Orgrimmar or Thunder Bluff.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "98": {
                            "name": "Splintertree Post",
                            "points": [402, 344],
                            "type": "village",
                            "desc": "Splintertree Post is a Horde outpost in Ashenvale, lying just northwest of Felfire Hill.Like most Horde outposts, Splintertree is mainly populated by orcs and tauren, all of whom are primarily scouts and guards. There are several quest givers, a heavy armor vendor for repairs, an inn, mailbox, stable master, and a flight path maintained by flight master Vhulgra. There is also quite a big cave dug by horde peons in the back of Splintertree Post. It is referred to as Splintertree Mine. Like the Crossroads to the south, Splintertree Post is often raided by Alliance parties on PvP servers.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "99": {
                            "name": "Astranaar",
                            "points": [330, 325],
                            "type": "village",
                            "desc": "Astranaar, aka Astrannar, is a night elven town situated on the east-west road that divides Ashenvale in two. Like the Redridge Mountains and Duskwood regions in the Eastern Kingdoms, Ashenvale is often attacked by Horde as it is one of the first-tier contested zones for the Alliance. However, the danger is two-fold since Ashenvale houses two Horde towns, one in the Zoram Strand and the other to the east at Splintertree Post. Exercise extreme caution around Astranaar. When questing, set your hearthstone to the inn whenever feasible in order to avoid having to dodge groups of Horde who like to gather a short distance away from the town in preparation to raid it.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "100": {
                            "name": "Zoram'gar Outpost",
                            "points": [282, 315],
                            "type": "village",
                            "desc": "Zoram'gar Outpost is a Horde outpost located on the Zoram Strand of Ashenvale. It is the very last attempt in gaining control over Ashenvale by the Horde without breaking the \"truce\". Zoram'gar is troll controlled. After the Cataclysm, the Horde reinforced and expanded the outpost, and it now looks more akin to the orcish holds in Northrend.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "101": {
                            "name": "Whisperwind Grove",
                            "points": [352, 208],
                            "type": "village",
                            "desc": "Whisperwind Grove, located in Felwood, is a neutral Night Elf town (possibly Cenarion Circle) that rests just south of Irontree Woods. It is a full fledged quest hub with a flight master, inn, and mailbox.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "102": {
                            "name": "Lor'danel",
                            "points": [323, 165],
                            "type": "village",
                            "desc": "Lor'danel is a seaside night elf settlement in northern Darkshore, founded after the destruction of Auberdine in the Cataclysm. It is built on a patch of land between two waterfalls. Water flows in from the sea into a whirlpool deeper inland, and the town is connected to the mainland by large and long wood bridges. Unlike the rest of Darkshore, the ground and trees here are vibrant green.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "103": {
                            "name": "Nighthaven",
                            "points": [396, 147],
                            "type": "village",
                            "desc": "Nighthaven is the capital and only town in Moonglade. Being in Moonglade, it is involved in many of the druid quests. This city once held the largest concentration of night elves anywhere on Kalimdor. Massive trees, ancients, and many forest beasts fill the surrounding woods. Nighthaven has survived for centuries despite demon and undead attacks, and the night elves protect their home fiercely. They are very cautious of whom they let enter the village. High elves are not allowed under any circumstances, and anyone smelling of arcane power is likewise turned away. Those allowed entry find Nighthaven hospitable, though a subdued and even eerie place. Night elves run the inns, taverns, and shops, and their way of life is rooted in nature. This spiritual heritage manifests in many small ways that foreigners may find unsettling \u2014 from how the buildings are constructed to mesh with the surrounding woods to a wildness that seems to lurk just beneath a quiet demeanor. While visitors may come and go as they please for the most part, they are never allowed near moon wells. In addition, any high elves seen near a moon well are attacked on sight.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "104": {
                            "name": "Everlook",
                            "points": [473, 182],
                            "type": "village",
                            "desc": "Everlook is a trading post run by the goblins of the Steamwheedle Cartel. It lies at the crossroads of Winterspring's main trade routes.This town is the last point of civilization before reaching Hyjal Summit. It is run by goblins as a trading post and is officially neutral to all races and factions. Even so, pilgrims allowed to venture up to the World Tree stop here, but otherwise this is the highest that merchants and explorers may venture without the night elves\u2019 permission. Everlook would offer a commanding view of Kalimdor, if it were not at such a high altitude that clouds constantly shroud the mountain\u2019s lower flanks.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "105": {
                            "name": "Bilgewater Harbor",
                            "points": [544, 296],
                            "type": "village",
                            "desc": "From its roots as a humble \"city-in-a-box\" to the bustling metropolis it is today, Bilgewater Harbor straddles the line between myth and legend. At least, that's what the brochure says. The orc commanders might argue differently, though. It isn't exactly easy to maintain discipline in an otherwise lawless city where every vice you can imagine is available for just a handful of silver and debauchery is half off.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "106": {
                            "name": "Nordrassil",
                            "points": [440, 233],
                            "type": "village",
                            "desc": "Nordrassil is the original World Tree of the night elves, meaning \"crown of the heavens\" in their language. The key point of interest on Hyjal is Nordrassil, the World Tree. It stands thousands of feet high, and its vast canopy almost blocks out the sky. Although the tree suffered much damage in the Third War, it is healing itself. It did not flower or grow leaves the year past the war, but the druids hoped that the coming year it would begin to grow again. Guarded by three dragonflights, the World Tree Nordrassil is slowly regrowing. The bones of Archimonde, the great demon lord who led the invasion of Azeroth in the Third War, still hang from the massive tree\u2019s mighty branches. Many speculate that when the tree regrows completely, the night elves will regain their immortality; but that day may never come if they fail to assist the dragons against the continuing threat of the Burning Legion. Even though Nordrassil is healing, it will take another century or two for the World Tree to regain its former glory and power.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "107": {
                            "name": "Krom'gar Fortress",
                            "points": [315, 393],
                            "type": "village",
                            "desc": "Krom'gar Fortress is a Horde town built within Windshear Crag, opposite the new Alliance town of Windshear Hold in Stonetalon Mountains, complete with an inn and flight master, as well as a Horde-controlled mine.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "108": {
                            "name": "Windshear Hold",
                            "points": [303, 384],
                            "type": "village",
                            "desc": "Windshear Hold (called Windshear Fortress on flight maps) is an Alliance town located in Windshear Crag, Stonetalon Mountains. It features many different alliance races.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "109": {
                            "name": "Nijel's Point",
                            "points": [272, 411],
                            "type": "village",
                            "desc": "Nijel's Point is an Alliance outpost located in the northern mountains of Desolace. It features both human and night elven NPCs and structures, and holds flight paths to Feathermoon Stronghold, Theramore Isle, and Auberdine. Nobody seems to know (or at least say) who Nijel is or was, not even the people living there. Most probably, he was the founder of the ancient town there which now lie in ruins.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "110": {
                            "name": "Karnum's Glade",
                            "points": [262, 458],
                            "type": "village",
                            "desc": "Karnum's Glade is a Cenarion Circle respite located in the middle of the Cenarion Wildlands in Desolace and under the care and direction of Karnum Marshweaver.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "111": {
                            "name": "Shadowprey Village",
                            "points": [213, 488],
                            "type": "village",
                            "desc": "Shadowprey Village is located on the southern end of the coast of Desolace. This village is home to a number of professional troll fishermen, whose catches help supply food to the Ghost Walker Post and are always in high demand. Primarily a troll fishing village, Shadowprey is also a travel node for Horde adventurers. It lies along the Sar\u2019theris Strand, south of the Valley of Spears. Nearby a representative of the Cenarion Circle, the dryad Selendra, investigates the whereabouts of Zaetar\u2019s remains. The trolls tolerate her presence because they are aware that the centaur are a threat to them as well, and the Alliance here helps their cause against the Burning Blade. In the WoW Game Manual, this village is called \"Jagged Spear Village\".",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "112": {
                            "name": "Fort Triumph",
                            "points": [392, 533],
                            "type": "village",
                            "desc": "Fort Triumph is a new Alliance outpost in Southern Barrens. The fort is on the eastern side of the Battlescar, with the Horde outpost Desolation Hold located on the western side. The Triumph Battalion is the 5th of Theramore. The Battalion is an Infantry that is fighting for Southern Barrens. The Fort is working with Theramore and Northwatch Hold to take control over Southern Barrens. The Fort is used as a headquarter for the Battalion.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "113": {
                            "name": "Desolation Hold",
                            "points": [380, 536],
                            "type": "village",
                            "desc": "Desolation Hold is a new Horde outpost in Southern Barrens. It is located on the western side of the Battlescar, with the Alliance outpost Fort Triumph on the eastern side.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "114": {
                            "name": "Theramore Isle",
                            "points": [471, 549],
                            "type": "village",
                            "desc": "Theramore Isle, the capital of the Dustwallow Marsh, is the Alliance's only human stronghold in Kalimdor. With a population of 9,500 people it is the home and sanctuary of Jaina Proudmoore. Theramore is a rocky island east of Dustwallow; the city, which bears the same name as the island, is alternatively known as Theramore Keep. It was originally settled with the sole purpose of survival. Lead by Jaina Proudmoore, a small contingent of the Kul Tiras navy, with what few survivors they could bring, had fled the Eastern Kingdoms during the great Scourge of Lordaeron. Built primarily as a military fortress, Theramore served as the Alliance's base of operations against the Burning Legion during the latter part of the Third War. Their bravery and sacrifice during the final battle earned the respect of Warchief Thrall, who decreed that Jaina and her kin would have a home in Kalimdor for evermore. It has since grown into a splendid little town, and serves as a safe harbor and trading port. Approach from the sea is extremely difficult due to the jagged rocks jutting out of Dustwallow Bay, pirates, and ancient beasts that live in the mirky depths of the ancient sea.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "115": {
                            "name": "Mudsprocket",
                            "points": [417, 583],
                            "type": "village",
                            "desc": "Mudsprocket, is a goblin town in the south-west of Dustwallow Marsh. It is a quest hub with a flight master, inn, graveyard, anvil, forge and mailbox. This town's faction is tied with Gadgetzan.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "116": {
                            "name": "Feathermoon Stronghold",
                            "points": [240, 573],
                            "type": "village",
                            "desc": "Prior to the Cataclysm, Feathermoon Stronghold was the name of the night elf island fortress located off the western coast of Feralas on Sardor Isle on the continent of Kalimdor. It had a hippogryph point and could be reached from Auberdine, Nijel's Point, and Thalanaar. The stronghold was established by General Shandris Feathermoon, who for the past ten thousand years has been Tyrande Whisperwind's right hand in the Sentinels. Feathermoon was most easily accessible by a boat taken from Feralas in the Forgotten Coast, though many Alliance players who didn't like to wait for the boat preferred to swim.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "117": {
                            "name": "Camp Mojache",
                            "points": [303, 570],
                            "type": "village",
                            "desc": "Camp Mojache is a tauren village in eastern Feralas overlooking the scenic Wildwind Lake. The camp straddles a swift-flowing stream that feeds the lake. If you want to see a fine example of what a \"civilized barbarian\" looks like, here\u2019s the place to go. The tauren of this village dress in simple animal skins, live in flimsy huts, and dance in strange mystic rituals. They have a written language, practice leatherworking and tailoring, and understand their environment better than he ever could. They also love to tell stories. They were the main reason the ogres hadn\u2019t taken over all of Feralas. The tauren, it seems, are involved in an endless effort to keep the ogres from encroaching on their lands.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "118": {
                            "name": "Fizzle &amp; Pozzik's Speedbarge",
                            "points": [452, 633],
                            "type": "village",
                            "desc": "Fizzle &amp; Pozzik's Speedbarge is a massive floating raceway located on the Shimmering Deep (the lake that was once the Shimmering Flats) in Thousand Needles. With the flooding of the Flats and the loss of the Mirage Raceway, Fizzle Brassbolts and Pozzik have moved their racing operations to this floating racetrack. The remnants of the raceway are located on the \"lake bed\" beneath the barge. This location houses many Goblins and Gnomes who regularly bicker and squabble in petty bar brawls.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "119": {
                            "name": "Cenarion Hold",
                            "points": [282, 658],
                            "type": "village",
                            "desc": "Cenarion Hold is a location of utmost strategic importance in Silithus. The Cenarion Circle has taken over the duty of defending the ancient night elven settlement against the increasingly hostile and aggressive Silithid and other forces that have set foot in this troubled region recently. The town can be reached either by Gryphon or Wyvern from Gadgetzan. If you don't know the flightpath yet, it can only be reached by travelling to the north-western corner of the Un'Goro Crater, where a wide path extends out of the crater and into Silithus. The merchants of Cenarion Hold gladly sell their goods to any adventurer who passes through since business is hard to come by in these trying times. See Cenarion Circle for information on summoning the Dukes and Lords who drop rare and epic items.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "120": {
                            "name": "Marshal's Stand",
                            "points": [358, 688],
                            "type": "village",
                            "desc": "Marshal's Stand is located southeast of Fire Plume Ridge in Un'Goro Crater. It contains most of the NPCs of Marshal's Refuge from before it was overrun by Stone Guardians. Unlike the Refuge, Marshal's Stand has an inn, as well as the usual neutral flight master. If you are hostile with Gadgetzan you will be attacked by level 85 bruisers when you land here.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "121": {
                            "name": "Gadgetzan",
                            "points": [447, 665],
                            "type": "village",
                            "desc": "The neutral goblin trading outpost of Gadgetzan is the only spot of civilization in the entire desert of Tanaris. Explorers can find most gear that they need here, as well as a place to escape from the blistering sun and other dangers of the desert. Rising out of the northern Tanaris desert like an oasis, Gadgetzan (Gadgetzar or Gadgetar in some tongues) is the headquarters of the Steamwheedle Cartel, the largest of the Goblin Cartels. Here some of the best goblin engineers, miners and alchemists play their trade. The goblins believe in profit above loyalty, thus Gadgetzan is considered neutral territory in the Horde\/Alliance conflict. Anyone with a fat wallet or services to offer is welcome in Gadgetzan. Both governments officially recognize goblin neutrality, and for those who don't, the streets are heavily patrolled by goblin bruisers ready to pound to a pulp anyone disrupting their trade by instigating conflict. Why the goblins choose to build their trading towns in such inhospitable locations is anyone's guess, but once again, they defy logic and the hot sun with their wondrous city of Gadgetzan.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "122": {
                            "name": "Ramkahen",
                            "points": [340, 743],
                            "type": "village",
                            "desc": "The cat-people of the Ramkahen are the distant but direct descendants of the Tol'vir \u2013 much like what the Dwarves are to the Earthen. Protecting Titan secrets remains part of their rigid tradition despite losing their stone bodies. The Ramkahen will have their own faction called Ramkahen, which players will be able to gain reputation with, while questing in Uldum.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "123": {
                            "name": "Schnottz's Landing",
                            "points": [282, 786],
                            "type": "village",
                            "desc": "Schnottz's Landing can be found in the southwest corner of Uldum, west of the Ruins of Ammon. This is where Commander Schnottz has set up his command post, sending his troops into various parts of Uldum to unearth and loot riches and artifacts from the tombs and ruins. Near the Landing is a dock where two ships are docked; further to the west floats a third ship. Closer to the western mountains is Schnottz's Hostel, where various guests of the Commander's are staying. It should be noted that most of the following inhabitants below are phased out after quests are completed for the subzone. Those that remain are the mobs within the boats and the bodyguards.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "124": {
                            "name": "Blood Watch",
                            "points": [121, 133],
                            "type": "village",
                            "desc": "Blood Watch is the main draenei settlement on Bloodmyst Isle. It is in fact many big crystal pieces of the Exodar that have been converted into their base of operations on the island.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        }
                    }
                },
                "out": {
                    "name": "Outland",
                    "points": {
                        "3483": {
                            "name": "Hellfire Peninsula",
                            "points": [333, 310, 332, 314, 327, 320, 328, 327, 325, 334, 323, 344, 317, 346, 312, 349, 313, 353, 309, 356, 309, 362, 318, 370, 327, 376, 333, 386, 332, 394, 335, 398, 343, 406, 349, 410, 355, 418, 364, 420, 377, 423, 387, 428, 389, 434, 393, 438, 396, 441, 399, 451, 414, 458, 426, 455, 434, 453, 443, 450, 453, 454, 461, 462, 467, 470, 475, 466, 488, 457, 495, 457, 505, 460, 511, 458, 516, 452, 519, 445, 531, 438, 540, 437, 549, 438, 555, 433, 557, 427, 562, 420, 565, 411, 566, 405, 560, 401, 564, 393, 569, 380, 570, 367, 568, 354, 565, 347, 567, 334, 574, 335, 582, 330, 587, 324, 586, 318, 583, 315, 579, 315, 575, 316, 571, 321, 567, 326, 562, 323, 559, 318, 552, 316, 544, 316, 541, 320, 540, 324, 537, 333, 536, 338, 532, 343, 528, 347, 525, 342, 525, 337, 526, 332, 529, 328, 527, 324, 523, 325, 518, 327, 516, 325, 513, 322, 514, 314, 520, 311, 524, 302, 527, 297, 524, 291, 517, 291, 513, 284, 512, 278, 506, 275, 497, 274, 489, 273, 478, 270, 467, 269, 459, 274, 454, 278, 452, 283, 451, 291, 446, 298, 441, 300, 437, 304, 429, 298, 424, 292, 421, 290, 415, 288, 407, 290, 403, 294, 397, 300, 391, 303, 381, 309, 365, 307, 352, 314, 344, 312, 335, 308],
                            "tip": {"lvl": {"min": 58, "max": 63}, "faction": "neutral", "quest": [164, 1, 1]}
                        },
                        "3518": {
                            "name": "Nagrand",
                            "points": [103, 363, 118, 365, 134, 369, 152, 368, 168, 367, 177, 364, 183, 364, 187, 366, 194, 367, 199, 366, 207, 367, 217, 369, 223, 369, 229, 371, 238, 376, 248, 373, 251, 378, 255, 386, 255, 394, 261, 400, 258, 409, 269, 412, 268, 417, 266, 420, 265, 430, 273, 437, 278, 445, 281, 452, 282, 459, 288, 462, 291, 469, 296, 480, 295, 488, 289, 492, 284, 496, 275, 502, 271, 508, 269, 521, 267, 529, 259, 537, 257, 541, 261, 558, 264, 569, 264, 585, 259, 587, 256, 579, 253, 574, 250, 571, 248, 569, 243, 565, 237, 558, 233, 556, 225, 554, 220, 555, 218, 562, 216, 566, 210, 565, 207, 566, 201, 566, 198, 562, 196, 559, 188, 555, 181, 558, 174, 563, 168, 562, 163, 559, 155, 555, 144, 555, 140, 558, 135, 559, 131, 553, 119, 541, 113, 523, 107, 517, 100, 510, 94, 507, 90, 499, 82, 488, 74, 481, 72, 473, 63, 467, 58, 452, 49, 439, 46, 432, 48, 421, 51, 411, 53, 409, 57, 404, 65, 403, 76, 401, 86, 400, 92, 398, 101, 392, 106, 379, 105, 370],
                            "tip": {"lvl": {"min": 64, "max": 67}, "faction": "neutral", "quest": [129, 3, 2]}
                        },
                        "3519": {
                            "name": "Terokkar Forest",
                            "points": [333, 391, 338, 403, 347, 411, 356, 417, 365, 423, 380, 427, 390, 428, 395, 440, 399, 443, 404, 451, 409, 455, 421, 456, 425, 454, 429, 453, 437, 464, 444, 470, 442, 481, 439, 491, 440, 500, 430, 511, 421, 517, 419, 521, 424, 527, 423, 533, 430, 536, 433, 541, 435, 548, 440, 549, 443, 559, 447, 572, 451, 587, 449, 599, 441, 617, 439, 622, 435, 620, 431, 618, 428, 617, 425, 617, 419, 613, 415, 610, 408, 612, 399, 606, 393, 609, 385, 615, 376, 627, 371, 622, 366, 617, 363, 608, 359, 602, 348, 599, 342, 599, 335, 598, 327, 603, 319, 607, 315, 605, 307, 598, 301, 593, 295, 587, 285, 587, 279, 592, 274, 595, 268, 591, 266, 583, 263, 569, 263, 559, 257, 547, 257, 535, 264, 532, 270, 520, 277, 514, 275, 509, 274, 505, 273, 504, 287, 498, 291, 492, 293, 484, 296, 482, 294, 477, 291, 467, 291, 463, 285, 460, 282, 458, 282, 453, 278, 444, 277, 438, 270, 433, 267, 429, 271, 419, 283, 414, 292, 411, 301, 411, 307, 411, 312, 410, 317, 405, 322, 399, 332, 394],
                            "tip": {"lvl": {"min": 62, "max": 65}, "faction": "neutral", "quest": [98, 0, 2]}
                        },
                        "3520": {
                            "name": "Shadowmoon Valley",
                            "points": [447, 498, 457, 492, 465, 488, 476, 488, 490, 484, 501, 483, 504, 477, 506, 472, 513, 473, 516, 477, 516, 487, 521, 490, 526, 485, 529, 480, 533, 478, 540, 479, 547, 482, 552, 489, 559, 494, 568, 495, 576, 497, 581, 503, 591, 511, 601, 513, 606, 519, 621, 523, 632, 526, 638, 526, 644, 532, 650, 540, 649, 550, 644, 565, 639, 572, 630, 577, 620, 580, 610, 583, 604, 591, 590, 604, 591, 611, 598, 614, 613, 619, 616, 624, 614, 640, 608, 649, 592, 654, 577, 651, 563, 648, 555, 640, 556, 630, 546, 630, 535, 637, 521, 644, 510, 638, 499, 634, 483, 636, 467, 636, 459, 629, 450, 626, 445, 626, 437, 624, 434, 617, 425, 617, 421, 613, 419, 610, 411, 608, 420, 601, 420, 594, 429, 587, 430, 585, 436, 586, 445, 579, 446, 572, 446, 557, 442, 550, 435, 548, 433, 539, 427, 533, 422, 529, 417, 520, 421, 516, 431, 507, 439, 499, 441, 496],
                            "tip": {"lvl": {"min": 67, "max": 70}, "faction": "neutral", "quest": [175, 6, 8]}
                        },
                        "3521": {
                            "name": "Zangarmarsh",
                            "points": [299, 411, 308, 408, 313, 403, 320, 398, 332, 390, 332, 383, 328, 381, 323, 375, 318, 369, 314, 365, 311, 363, 309, 358, 310, 353, 309, 349, 314, 346, 321, 342, 322, 340, 324, 332, 324, 326, 325, 320, 329, 312, 331, 307, 325, 302, 330, 296, 327, 288, 320, 284, 312, 284, 296, 285, 287, 283, 284, 288, 280, 295, 270, 302, 262, 299, 249, 299, 238, 298, 231, 299, 226, 300, 222, 296, 218, 293, 205, 293, 188, 291, 188, 288, 184, 279, 176, 277, 163, 272, 158, 270, 148, 268, 138, 266, 132, 261, 122, 261, 117, 261, 117, 264, 114, 272, 113, 278, 112, 282, 114, 290, 115, 299, 112, 300, 107, 304, 104, 307, 101, 312, 98, 318, 94, 323, 91, 329, 91, 340, 93, 346, 95, 352, 99, 358, 104, 364, 111, 364, 121, 364, 129, 364, 135, 365, 142, 366, 149, 367, 157, 366, 165, 364, 175, 364, 182, 362, 187, 363, 197, 365, 209, 366, 222, 368, 231, 370, 237, 372, 250, 378, 260, 379, 258, 385, 256, 386, 257, 393, 262, 392, 266, 392, 271, 392, 273, 395, 279, 396, 284, 398, 292, 404, 297, 408],
                            "tip": {"lvl": {"min": 60, "max": 64}, "faction": "neutral", "quest": [93, 0, 2]}
                        },
                        "3522": {
                            "name": "Blade's Edge Mountains",
                            "points": [194, 131, 200, 127, 208, 124, 218, 123, 229, 121, 239, 122, 243, 130, 245, 142, 252, 144, 256, 137, 254, 131, 254, 123, 257, 116, 261, 111, 267, 107, 273, 106, 282, 104, 291, 104, 302, 103, 314, 102, 322, 100, 330, 102, 334, 106, 337, 112, 340, 118, 341, 125, 345, 130, 349, 136, 353, 143, 359, 149, 359, 156, 358, 164, 356, 169, 351, 173, 349, 178, 347, 184, 345, 194, 345, 203, 345, 211, 348, 218, 351, 226, 352, 244, 351, 253, 346, 267, 341, 280, 338, 285, 333, 284, 319, 282, 304, 284, 289, 282, 284, 285, 283, 292, 280, 297, 277, 300, 268, 299, 258, 299, 249, 299, 241, 300, 237, 298, 230, 300, 225, 295, 210, 295, 203, 290, 196, 292, 192, 289, 187, 285, 185, 280, 179, 275, 174, 274, 173, 270, 173, 263, 172, 258, 172, 256, 174, 251, 177, 249, 178, 245, 178, 239, 177, 236, 177, 231, 178, 223, 179, 215, 179, 206, 181, 192, 182, 184, 183, 179, 188, 173, 193, 167, 196, 161, 191, 154, 189, 146, 190, 136],
                            "tip": {"lvl": {"min": 65, "max": 68}, "faction": "neutral", "quest": [143, 3, 4]}
                        },
                        "3523": {
                            "name": "Netherstorm",
                            "points": [363, 149, 358, 172, 353, 187, 353, 214, 358, 230, 374, 235, 387, 241, 395, 247, 414, 238, 429, 240, 452, 241, 458, 239, 462, 239, 473, 245, 510, 213, 523, 183, 549, 135, 557, 70, 536, 49, 461, 35, 417, 40, 347, 65, 333, 86, 338, 100, 346, 114, 357, 130],
                            "tip": {"lvl": {"min": 67, "max": 70}, "faction": "neutral", "quest": [152, 1, 1]}
                        }
                    },
                    "marks": {
                        "10": {
                            "name": "Shattrath City",
                            "points": [280, 429],
                            "type": "n_capital",
                            "desc": "The major hub in Outland situated in the northwestern portion of Terokkar Forest. It is a capital-sized sanctuary city populated by ancient heroes and naaru. It is the first capital available to both sides.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 14
                        },
                        "59": {
                            "name": "Hellfire Ramparts",
                            "points": [405, 339],
                            "type": "pin-green",
                            "desc": "The Hellfire Ramparts (often known as just \"Ramparts\") are the first wing of the Hellfire Citadel instance in Hellfire Peninsula. The citadel itself sits in the center of the zone, in the middle of a broken-up wall that divided the zone before the conflict began. The Ramparts takes place atop this wall along the sides of the citadel.",
                            "icon": "boss",
                            "lvl": {"min": 57, "max": 70},
                            "filter": 6
                        },
                        "60": {
                            "name": "The Blood Furnace",
                            "points": [405, 349],
                            "type": "pin-green",
                            "desc": "The Blood Furnace is the second wing of the Hellfire Citadel. It is located above Hellfire Ramparts, inside of the tower that overlooks the ramparts themselves. The entrance is on the Alliance (Southern) side of the Citadel, up a ramp. Through this instance, players discover that it is Magtheridon that is entrapped by the Fel Orcs' sorcery, and they're using his blood to manufacture a new Fel Horde, infused with his demonic energy.",
                            "icon": "boss",
                            "lvl": {"min": 58, "max": 70},
                            "filter": 6
                        },
                        "61": {
                            "name": "The Shattered Halls",
                            "points": [405, 359],
                            "type": "pin-green",
                            "desc": "Hellfire Citadel is the headquarters of the Fel Orcs of Outland; it's an impenetrable bastion that once served as the base of operations for the orcs throughout the First and Second Wars. Kargath Bladefist and his Fel orcs now make their home in the citadel.",
                            "icon": "boss",
                            "lvl": {"min": 65, "max": 70},
                            "filter": 6
                        },
                        "62": {
                            "name": "The Slave Pens",
                            "points": [206, 290],
                            "type": "pin-green",
                            "desc": "Coilfang Reservoir is an instance located in Zangarmarsh. The structure itself is a subterranean water pumping station, operated by the Naga. The dungeon is made up of gigantic caverns with huge pipes descending from the ceiling powered by titanic crystal capacitors. While the entrance to the Reservoir is underwater, the instance itself is only partially submerged, similar to the Blackfathom Deeps.",
                            "icon": "boss",
                            "lvl": {"min": 59, "max": 70},
                            "filter": 6
                        },
                        "63": {
                            "name": "The Underbog",
                            "points": [194, 303],
                            "type": "pin-green",
                            "desc": "The Underbog is the second 5-man wing of the Coilfang Reservoir, located in Zangarmarsh. The only Naga presence in this section defends the structure they built to house their hydra god, Ghaz'an.",
                            "icon": "boss",
                            "lvl": {"min": 60, "max": 70},
                            "filter": 6
                        },
                        "64": {
                            "name": "The Steamvault",
                            "points": [218, 303],
                            "type": "pin-green",
                            "desc": "Coilfang Reservoir is an instance located in Zangarmarsh. The structure itself is a subterranean water pumping station, operated by the Naga. The dungeon is made up of gigantic caverns with huge pipes descending from the ceiling powered by titanic crystal capacitors. While the entrance to the Reservoir is underwater, the instance itself is only partially submerged, similar to the Blackfathom Deeps.",
                            "icon": "boss",
                            "lvl": {"min": 65, "max": 70},
                            "filter": 6
                        },
                        "65": {
                            "name": "Mana-Tombs",
                            "points": [323, 495],
                            "type": "pin-green",
                            "desc": "Auchindoun is a former draenei holy site and Horde fortress in the middle of the Bone Wastes in Outland's Terokkar Forest. It was a hallowed ground until the Shadow Council took over, summoned an extremely powerful demon as old as time itself, and destroyed half of Terokkar Forest in the process. Different factions now vie for power in this magical spot: Ethereals suck the arcane energy from the Mana-Tombs, the Burning Legion harvests souls inside the Auchenai Crypts, arakkoa zealots work dark magic in the Sethekk Halls, and the Shadow Council plots its domination of Outland from within the Shadow Labyrinth.",
                            "icon": "boss",
                            "lvl": {"min": 61, "max": 70},
                            "filter": 6
                        },
                        "66": {
                            "name": "Auchenai Crypts",
                            "points": [291, 518],
                            "type": "pin-green",
                            "desc": "Auchindoun is a former draenei holy site and Horde fortress in the middle of the Bone Wastes in Outland's Terokkar Forest. It was a hallowed ground until the Shadow Council took over, summoned an extremely powerful demon as old as time itself, and destroyed half of Terokkar Forest in the process. Different factions now vie for power in this magical spot: Ethereals suck the arcane energy from the Mana-Tombs, the Burning Legion harvests souls inside the Auchenai Crypts, arakkoa zealots work dark magic in the Sethekk Halls, and the Shadow Council plots its domination of Outland from within the Shadow Labyrinth.",
                            "icon": "boss",
                            "lvl": {"min": 62, "max": 70},
                            "filter": 6
                        },
                        "67": {
                            "name": "Shadow Labyrinth",
                            "points": [322, 544],
                            "type": "pin-green",
                            "desc": "Auchindoun is a former draenei holy site and Horde fortress in the middle of the Bone Wastes in Outland's Terokkar Forest. It was a hallowed ground until the Shadow Council took over, summoned an extremely powerful demon as old as time itself, and destroyed half of Terokkar Forest in the process. Different factions now vie for power in this magical spot: Ethereals suck the arcane energy from the Mana-Tombs, the Burning Legion harvests souls inside the Auchenai Crypts, arakkoa zealots work dark magic in the Sethekk Halls, and the Shadow Council plots its domination of Outland from within the Shadow Labyrinth.",
                            "icon": "boss",
                            "lvl": {"min": 65, "max": 70},
                            "filter": 6
                        },
                        "68": {
                            "name": "Sethekk Halls",
                            "points": [357, 520],
                            "type": "pin-green",
                            "desc": "Auchindoun is a former draenei holy site and Horde fortress in the middle of the Bone Wastes in Outland's Terokkar Forest. It was a hallowed ground until the Shadow Council took over, summoned an extremely powerful demon as old as time itself, and destroyed half of Terokkar Forest in the process. Different factions now vie for power in this magical spot: Ethereals suck the arcane energy from the Mana-Tombs, the Burning Legion harvests souls inside the Auchenai Crypts, arakkoa zealots work dark magic in the Sethekk Halls, and the Shadow Council plots its domination of Outland from within the Shadow Labyrinth.",
                            "icon": "boss",
                            "lvl": {"min": 63, "max": 70},
                            "filter": 6
                        },
                        "69": {
                            "name": "The Mechanar",
                            "points": [507, 176],
                            "type": "pin-green",
                            "desc": "Tempest Keep is a former Naaru fortress in the Netherstorm in Outland. This crystalline fortress is now ruled by Kael'thas Sunstrider, the lord of the blood elves, and dominated by scores of his brethren. The structure is divided into three wings in the skies--satellites of the gigantic structure--with the fourth wing, the Exodar, now in the world of Azeroth as the Draenei capital.",
                            "icon": "boss",
                            "lvl": {"min": 65, "max": 70},
                            "filter": 6
                        },
                        "70": {
                            "name": "The Botanica",
                            "points": [508, 150],
                            "type": "pin-green",
                            "desc": "Tempest Keep is a former Naaru fortress in the Netherstorm in Outland. This crystalline fortress is now ruled by Kael'thas Sunstrider, the lord of the blood elves, and dominated by scores of his brethren. The structure is divided into three wings in the skies--satellites of the gigantic structure--with the fourth wing, the Exodar, now in the world of Azeroth as the Draenei capital. ",
                            "icon": "boss",
                            "lvl": {"min": 65, "max": 70},
                            "filter": 6
                        },
                        "71": {
                            "name": "The Arcatraz",
                            "points": [508, 162],
                            "type": "pin-green",
                            "desc": "Tempest Keep is a former Naaru fortress in the Netherstorm in Outland. This crystalline fortress is now ruled by Kael'thas Sunstrider, the lord of the blood elves, and dominated by scores of his brethren. The structure is divided into three wings in the skies--satellites of the gigantic structure--with the fourth wing, the Exodar, now in the world of Azeroth as the Draenei capital.",
                            "icon": "boss",
                            "lvl": {"min": 65, "max": 70},
                            "filter": 6
                        },
                        "91": {
                            "name": "Gruul's Lair",
                            "points": [306, 179],
                            "type": "pin-purple",
                            "desc": "Gruul's Lair is home to Gruul the Dragonkiller, the gronn overlord who rules over the ogres of Blade's Edge Mountains.",
                            "icon": "boss",
                            "lvl": {"min": 70, "max": 70},
                            "filter": 12
                        },
                        "92": {
                            "name": "Magtheridon's Lair",
                            "points": [405, 369],
                            "type": "pin-purple",
                            "desc": "Hellfire Citadel is the headquarters of the Fel Orcs of Outland; Magtheridon's Lair is a raid wing of the Hellfire Citadel dungeon in Hellfire Peninsula. It is a quick raid encounter similar in concept to Onyxia's Lair and even drops an epic bag similar to that encounter. It also drops Tier 4 chests.",
                            "icon": "boss",
                            "lvl": {"min": 70, "max": 70},
                            "filter": 12
                        },
                        "93": {
                            "name": "Serpentshrine Cavern",
                            "points": [206, 303],
                            "type": "pin-purple",
                            "desc": "Serpentshrine Cavern is the final wing of Coilfang Reservoir, where Lady Vashj has made her watery lair. It is a 25-man raid instance with six bosses. Tier 5 leg, helm, and glove tokens drop from this instance.",
                            "icon": "boss",
                            "lvl": {"min": 70, "max": 70},
                            "filter": 12
                        },
                        "94": {
                            "name": "The Eye",
                            "points": [520, 162],
                            "type": "pin-purple",
                            "desc": "Tempest Keep is a former Naaru fortress in the Netherstorm in Outland. This crystalline fortress is now ruled by Kael'thas Sunstrider, the lord of the blood elves, and dominated by scores of his brethren. The structure is divided into three wings in the skies--satellites of the gigantic structure--with the fourth wing, the Exodar, now in the world of Azeroth as the Draenei capital.",
                            "icon": "boss",
                            "lvl": {"min": 70, "max": 70},
                            "filter": 12
                        },
                        "95": {
                            "name": "Black Temple",
                            "points": [566, 527],
                            "type": "pin-purple",
                            "desc": "The Black Temple is the fortress-citadel of Illidan Stormrage, Lord of Outland. It contains tier 6 set pieces as well as many notable items, including The Twin Blades of Azzinoth. It's also known for providing reputation for Ashtongue Deathsworn, easily earned through clearing the raid a few times.",
                            "icon": "boss",
                            "lvl": {"min": 70, "max": 70},
                            "filter": 12
                        },
                        "182": {
                            "name": "Altar of Sha'tar",
                            "points": [554, 507],
                            "type": "village",
                            "desc": "Altar of Sha'tar is an Aldor-controlled temple in the northern area (62,30) of the Shadowmoon Valley. It is the staging grounds for the warriors of the Aldor of Shattrath City to face the forces of Illidan.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "183": {
                            "name": "Sanctum of the Stars",
                            "points": [526, 559],
                            "type": "village",
                            "desc": "Sanctum of the Stars is a Scryers-only base located in southeast Shadowmoon Valley.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "184": {
                            "name": "Wildhammer Stronghold",
                            "points": [470, 556],
                            "type": "village",
                            "desc": "Wildhammer Stronghold is an Alliance town in the Shadowmoon Valley of Outland. As its name implies, it was founded by its current thane Kurdran Wildhammer who was one of the survivors of the original Alliance Expedition.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "185": {
                            "name": "Shadowmoon Village",
                            "points": [454, 512],
                            "type": "village",
                            "desc": "Shadowmoon Village is a Horde settlement located in Shadowmoon Valley, Outland. It is defended by Kor'kron guards, the elite guards of Thrall's fortress of Grommash Hold in Orgrimmar, back on Azeroth. Horde players who have reached the level of 70 are able to purchase personal flying mounts here. Shadowmoon Village also has a flight path and an inn. Several scouts are locked in battle with Infernals on the outside walls. It is possible that the orcs here are the only uncorrupted ones of the Shadowmoon clan left. Shadowmoon Village is commanded by Overlord Or'barokh.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "186": {
                            "name": "Allerian Stronghold",
                            "points": [370, 491],
                            "type": "village",
                            "desc": "Allerian Stronghold is an Alliance town in Terokkar Forest. Its name is in honor of Alleria Windrunner, although she does not currently reside here. The place is full of high elves and features some of the only high elf buildings in-game.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "187": {
                            "name": "Stonebreaker Hold",
                            "points": [349, 467],
                            "type": "village",
                            "desc": "Stonebreaker Hold is a Horde town in central Terokkar Forest. There is a flightpath, Innkeeper, and various quest giving NPCs.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "188": {
                            "name": "Telaar",
                            "points": [183, 486],
                            "type": "village",
                            "desc": "Telaar is the Kurenai-factioned Alliance town in southern Nagrand. The flight point is at 54,75, on top of the inn. It is accessed via exterior ramps on either side of the building.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "189": {
                            "name": "Garadar",
                            "points": [194, 400],
                            "type": "village",
                            "desc": "Garadar, the home ground of the Mag'har, is located in northern Nagrand. It was presumably named for Garad, the father of Durotan and grandfather of Thrall. The faction military chief of Garadar is Garrosh Hellscream, son of Grom Hellscream. He is aided by Jorin Deadeye, son of Kilrogg Deadeye. The spiritual leader of the Mag'har is Greatmother Geyah \u2014 Durotan's mother and Thrall's grandmother \u2014 who resides in the large circular hospice that serves as the inn. There is also a Horde flight path here connecting Garadar to the rest of Outland.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "190": {
                            "name": "Honor Hold",
                            "points": [446, 378],
                            "type": "village",
                            "desc": "Honor Hold is the primary Alliance town on Hellfire Peninsula. A refuge of human, elven, draenei and dwarven explorers, Honor Hold is the first major town Alliance explorers will encounter while traversing Outland. The town holds a flight path, inn and a variety of profession trainers and vendors. Vestiges of the Sons of Lothar, veterans of the Alliance that first came into Draenor, have steadfastly held on to this Hellfire outpost. They are now joined by the armies from Stormwind and Ironforge.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "191": {
                            "name": "Thrallmar",
                            "points": [444, 331],
                            "type": "village",
                            "desc": "Thrallmar is a Horde town found in Hellfire Peninsula , Outland. It was founded and now led by Nazgrel, commander of Thrall's security, as an opportunity to gain resources and to have a decent control over what's going on in this demon-infested area. The residents of the town form a faction of its own; reputation is raised by performing quests for them. These quests generally involve killing fel orcs in Hellfire Citadel.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "192": {
                            "name": "Falcon Watch",
                            "points": [361, 370],
                            "type": "village",
                            "desc": "Falcon Watch is a Horde-aligned blood elf settlement in the western area of the Hellfire Peninsula. Its current leader is Ranger Captain Venn'ren. There are several quest givers and vendors here, as well as a flight master and an innkeeper.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "193": {
                            "name": "Temple of Telhamat",
                            "points": [349, 320],
                            "type": "village",
                            "desc": "Temple of Telhamat is a draenei stronghold and religious site on the northwestern frontier of the Hellfire Peninsula. The temple is an Alliance port of call and a good gateway for travelers venturing into Zangarmarsh.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "194": {
                            "name": "Swamprat Post",
                            "points": [301, 314],
                            "type": "village",
                            "desc": "Swamprat Post is a troll fishing village in northeastern Zangarmarsh. It is Horde-aligned, and is the second point Horde characters will get to in the marsh after Cenarion Refuge, if they follow the quests exclusively. It contains a flight path.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "195": {
                            "name": "Cenarion Refuge",
                            "points": [289, 338],
                            "type": "village",
                            "desc": "Cenarion Refuge is a neutral faction town in Zangarmarsh. The town was originally founded by the Cenarion Circle, who came to Outland to study the local flora and fauna. Their presence became so large in outland, that the Cenarion Expedition was formed as Outland's sub-faction of the Cenarion Circle.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "196": {
                            "name": "Telredor",
                            "points": [257, 307],
                            "type": "village",
                            "desc": "Telredor is an Alliance-aligned draenei town located on top of a giant mushroom in eastern Zangarmarsh. Originally a calm settlement of draenei anchorites, many draenei refugees flocked to it when the orcs started attacking their villages. Telredor turned out to be an impregnable fortress, and a safe haven for many draenei. They followed Velen in joining the Alliance, and some members of allied races have come to the town to research the marshes and do business.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "197": {
                            "name": "Orebor Harborage",
                            "points": [188, 275],
                            "type": "village",
                            "desc": "Orebor Harborage is an Alliance-affiliated town in northern Zangarmarsh. It is comprised mostly of Kurenai, a faction of Broken who seek to reestablish their ties with the uncorrupted draenei. Orebor has a flight path and vendors selling armor and cooking supplies, as well as various NPCs who offer quests, mainly for gaining reputation with the Kurenai. The town also allows access to the Blade's Edge Mountains to the north.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "198": {
                            "name": "Zabra'jin",
                            "points": [156, 317],
                            "type": "village",
                            "desc": "Zabra'jin is a large Horde-aligned troll town in Zangarmarsh with huts connecting to a few mushrooms and wood planks holding the other buildings above the marsh. There is a flight path located here as well as a forge.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "199": {
                            "name": "Sporeggar",
                            "points": [126, 322],
                            "type": "village",
                            "desc": "Sporeggar is a town found along the western edge of Zangarmarsh which is populated by the sporelings. The sporelings are a mostly peaceful race of mushroom-men native to Outland. Unfortunately, the changing climate of the marsh has put them in danger. Adventurers that assist their survival will be justly rewarded.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "200": {
                            "name": "Cosmowrench",
                            "points": [498, 160],
                            "type": "village",
                            "desc": "Cosmowrench is a small goblin outpost having foundation in the easternmost part of Netherstorm, very close to Tempest Keep. It resembles a miniature version of Area 52. Originally, only the flight master, Harpax, was present here, but others were later added, including a couple of vendors, quest givers, a barber shop and the ever-present goblin bruisers.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "201": {
                            "name": "Stormspire",
                            "points": [429, 98],
                            "type": "village",
                            "desc": "The Stormspire is a neutral Consortium-run town located in Netherstorm. It is located beneath the interconnected eco-domes of Sutheron and Skyperch. Lush jungle vegetation grows within the settlement creating a sharp contrast with the purple, arcane-channeled sky.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "202": {
                            "name": "Area 52",
                            "points": [390, 158],
                            "type": "village",
                            "desc": "Area 52 is a neutral goblin-run town found on the southwestern most island of Netherstorm. It is a settlement structured much like Gadgetzan and Everlook, with a short wall surrounding a small hovel of buildings. The goblins are seen building a rocket ship to journey into the Twisting Nether named the X-52 Nether-Rocket.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "203": {
                            "name": "Evergrove",
                            "points": [286, 162],
                            "type": "village",
                            "desc": "Evergrove is a Cenarion Expedition outpost located in Ruuan Weald in the Blade's Edge Mountains. Unlike the other outposts belonging to the Cenarion expedition in Outland, this outpost is manned almost entirely by night elves. All available services, including a flight point, are offered to both Horde and Alliance.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "204": {
                            "name": "Toshley's Station",
                            "points": [292, 228],
                            "type": "village",
                            "desc": "Toshley's Station is a gnome-run Alliance village found in Blade's Edge Mountains. Gnomes perform their craziest experiments here. It is managed by Toshley, and was the only known gnome-only town until Fizzcrank Airstrip in the Borean Tundra was added later.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "205": {
                            "name": "Thunderlord Stronghold",
                            "points": [268, 204],
                            "type": "village",
                            "desc": "Thunderlord Stronghold is a Horde town in the Blade's Edge Mountains. It was the stronghold of the Thunderlord clan until the ogre clans exterminated them. Now, new Horde forces hold it in honor of the original clan. After the opening of the Dark Portal, Rexxar traveled here in search of his own race.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "206": {
                            "name": "Sylvanaar",
                            "points": [215, 221],
                            "type": "village",
                            "desc": "Sylvanaar is a night elf settlement in Blade's Edge Mountains. It is located in the Living Grove, and overlooks the expansive Bloodmaul Ravine below. Sylvanaar has an inn, a stable master, and a flight master which offers flight paths that connect to Toshley's Station and Orebor Harborage. It also has two moonwells.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        }
                    }
                },
                "north": {
                    "name": "Northrend",
                    "points": {
                        "65": {
                            "name": "Dragonblight",
                            "points": [293, 365, 294, 352, 298, 348, 301, 343, 301, 339, 311, 336, 324, 330, 331, 328, 341, 331, 348, 333, 359, 327, 365, 328, 377, 331, 383, 332, 391, 336, 399, 340, 406, 338, 413, 338, 417, 345, 427, 343, 432, 343, 435, 344, 435, 351, 435, 359, 439, 362, 436, 370, 436, 379, 436, 385, 441, 394, 444, 404, 443, 415, 442, 430, 439, 442, 433, 441, 431, 435, 430, 428, 427, 433, 425, 432, 418, 432, 413, 434, 407, 438, 404, 443, 399, 443, 396, 447, 393, 452, 387, 444, 381, 443, 377, 440, 373, 434, 368, 439, 362, 441, 355, 440, 352, 436, 349, 434, 343, 435, 335, 437, 326, 440, 306, 440, 298, 440, 289, 438, 286, 435, 283, 427, 277, 426, 270, 422, 261, 420, 256, 416, 249, 408, 245, 414, 240, 414, 233, 416, 233, 410, 236, 402, 238, 395, 239, 383, 244, 380, 253, 380, 259, 384, 263, 380, 271, 379, 280, 378, 285, 378, 291, 374, 291, 371],
                            "tip": {"lvl": {"min": 71, "max": 75}, "faction": "neutral", "quest": [215, 10, 3]}
                        },
                        "66": {
                            "name": "Zul'Drak",
                            "points": [433, 306, 439, 295, 445, 290, 458, 287, 470, 282, 476, 278, 485, 276, 499, 274, 502, 270, 512, 267, 519, 267, 526, 266, 535, 268, 550, 266, 554, 252, 560, 246, 562, 239, 581, 223, 609, 249, 592, 270, 582, 281, 581, 287, 580, 297, 581, 309, 577, 317, 575, 327, 570, 331, 565, 332, 559, 337, 543, 339, 535, 347, 520, 356, 512, 364, 502, 367, 492, 374, 479, 379, 463, 378, 459, 374, 450, 374, 442, 374, 444, 365, 453, 359, 455, 352, 446, 350, 436, 356, 437, 350, 437, 344, 433, 342, 431, 341, 432, 337, 436, 328, 434, 325, 430, 323, 430, 311],
                            "tip": {"lvl": {"min": 74, "max": 76}, "faction": "neutral", "quest": [116, 6, 3]}
                        },
                        "67": {
                            "name": "The Storm Peaks",
                            "points": [351, 183, 354, 194, 348, 207, 343, 217, 351, 231, 356, 265, 356, 274, 360, 281, 367, 280, 374, 286, 384, 297, 396, 300, 414, 300, 419, 299, 429, 309, 438, 298, 448, 294, 459, 287, 471, 280, 479, 276, 494, 274, 501, 271, 517, 269, 535, 267, 552, 266, 555, 251, 561, 244, 561, 240, 549, 233, 551, 227, 543, 216, 546, 207, 535, 197, 528, 184, 514, 174, 508, 178, 500, 168, 493, 162, 478, 162, 467, 163, 463, 164, 463, 155, 461, 148, 460, 138, 456, 132, 449, 121, 438, 114, 426, 115, 415, 116, 407, 119, 393, 125, 391, 131, 383, 139, 385, 148, 383, 155, 386, 160, 393, 167, 401, 171, 397, 173, 385, 172, 373, 171, 363, 171, 355, 177],
                            "tip": {"lvl": {"min": 77, "max": 80}, "faction": "neutral", "quest": [135, 8, 8]}
                        },
                        "210": {
                            "name": "Icecrown",
                            "points": [162, 255, 182, 260, 189, 261, 193, 266, 198, 275, 204, 280, 218, 288, 225, 296, 225, 303, 231, 306, 233, 310, 242, 308, 251, 307, 259, 311, 266, 315, 271, 317, 279, 321, 285, 327, 289, 335, 294, 340, 299, 345, 305, 346, 307, 343, 315, 339, 320, 334, 323, 331, 332, 329, 327, 326, 322, 323, 321, 318, 321, 312, 319, 307, 319, 300, 322, 290, 324, 282, 331, 277, 334, 273, 342, 274, 348, 275, 355, 273, 355, 265, 354, 253, 352, 241, 351, 230, 346, 223, 344, 215, 349, 205, 351, 196, 352, 189, 351, 184, 347, 184, 342, 185, 334, 186, 329, 187, 325, 185, 317, 177, 314, 171, 310, 172, 307, 176, 303, 173, 300, 173, 298, 173, 290, 174, 285, 175, 279, 175, 273, 171, 265, 165, 260, 164, 257, 166, 251, 164, 247, 165, 239, 168, 239, 170, 231, 178, 228, 182, 221, 183, 214, 184, 210, 188, 207, 192, 202, 198, 198, 205, 201, 205, 201, 210, 199, 216, 199, 223, 196, 226, 190, 234, 183, 234, 171, 238, 165, 243, 160, 247, 159, 254],
                            "tip": {"lvl": {"min": 77, "max": 80}, "faction": "neutral", "quest": [220, 11, 2]}
                        },
                        "394": {
                            "name": "Grizzly Hills",
                            "points": [446, 381, 443, 385, 447, 391, 447, 399, 446, 416, 443, 428, 450, 430, 451, 436, 458, 440, 469, 443, 481, 443, 491, 449, 503, 445, 507, 439, 510, 430, 513, 421, 515, 414, 522, 410, 528, 400, 534, 397, 538, 398, 546, 397, 554, 398, 560, 399, 564, 407, 572, 407, 579, 409, 583, 402, 589, 399, 597, 397, 605, 397, 615, 399, 618, 396, 612, 392, 609, 388, 609, 383, 603, 375, 597, 369, 593, 365, 597, 356, 600, 351, 603, 342, 601, 337, 601, 327, 599, 318, 590, 314, 585, 311, 578, 315, 578, 319, 577, 323, 571, 329, 566, 330, 561, 335, 556, 339, 545, 338, 542, 339, 535, 346, 528, 352, 520, 357, 513, 361, 504, 367, 501, 372, 491, 377, 477, 378, 463, 378, 450, 378],
                            "tip": {"lvl": {"min": 73, "max": 75}, "faction": "neutral", "quest": [146, 10, 3]}
                        },
                        "495": {
                            "name": "Howling Fjord",
                            "points": [495, 450, 505, 443, 509, 430, 512, 419, 519, 413, 524, 404, 529, 398, 536, 400, 546, 398, 557, 396, 564, 407, 575, 408, 579, 410, 581, 406, 582, 401, 586, 400, 591, 400, 596, 397, 604, 396, 611, 401, 618, 403, 620, 412, 627, 422, 637, 432, 641, 442, 641, 448, 640, 455, 640, 464, 644, 470, 648, 481, 651, 488, 656, 500, 654, 511, 660, 516, 659, 524, 654, 527, 645, 525, 647, 531, 649, 538, 648, 544, 642, 551, 638, 556, 626, 560, 627, 566, 625, 569, 620, 571, 614, 568, 607, 572, 604, 577, 592, 575, 586, 573, 585, 568, 580, 566, 578, 568, 572, 563, 566, 564, 556, 560, 556, 558, 546, 556, 542, 551, 540, 543, 539, 533, 536, 529, 532, 527, 529, 526, 528, 531, 528, 537, 522, 545, 518, 551, 513, 549, 508, 547, 503, 544, 504, 537, 500, 535, 498, 529, 499, 522, 504, 516, 503, 510, 509, 511, 513, 509, 512, 508, 506, 502, 506, 498, 508, 494, 511, 488, 505, 488, 498, 485, 492, 475, 498, 470, 491, 467, 493, 459, 494, 456],
                            "tip": {"lvl": {"min": 68, "max": 72}, "faction": "neutral", "quest": [188, 14, 6]}
                        },
                        "3537": {
                            "name": "Borean Tundra",
                            "points": [226, 374, 231, 376, 234, 386, 235, 390, 233, 397, 229, 407, 226, 415, 221, 417, 207, 431, 209, 426, 202, 429, 193, 432, 180, 434, 169, 430, 163, 429, 161, 428, 159, 429, 158, 437, 156, 444, 149, 450, 146, 454, 145, 459, 140, 468, 136, 467, 130, 465, 131, 469, 130, 474, 124, 478, 112, 480, 105, 477, 99, 472, 89, 467, 93, 466, 90, 464, 86, 462, 83, 462, 78, 459, 78, 455, 68, 453, 70, 448, 73, 445, 73, 442, 71, 437, 69, 433, 69, 424, 76, 423, 81, 418, 79, 416, 73, 419, 62, 419, 55, 420, 47, 419, 41, 418, 35, 413, 34, 404, 34, 401, 31, 399, 23, 395, 26, 388, 27, 384, 31, 377, 35, 370, 38, 366, 41, 363, 44, 359, 44, 354, 46, 352, 50, 350, 56, 346, 58, 342, 60, 344, 62, 349, 64, 352, 67, 354, 70, 357, 73, 359, 78, 361, 80, 365, 84, 368, 88, 371, 92, 372, 98, 373, 104, 378, 103, 385, 98, 393, 96, 397, 90, 405, 87, 408, 84, 412, 82, 414, 85, 416, 89, 417, 95, 415, 95, 411, 95, 407, 98, 404, 103, 401, 107, 397, 111, 394, 114, 387, 113, 384, 111, 379, 108, 374, 106, 368, 103, 363, 101, 361, 101, 357, 105, 353, 108, 352, 112, 355, 120, 355, 126, 355, 137, 358, 146, 358, 155, 364, 168, 361, 178, 360, 190, 356, 191, 354, 205, 359, 216, 363, 219, 369],
                            "tip": {"lvl": {"min": 68, "max": 72}, "faction": "neutral", "quest": [216, 5, 5]}
                        },
                        "3711": {
                            "name": "Sholazar Basin",
                            "points": [108, 350, 118, 356, 124, 354, 131, 357, 140, 358, 147, 359, 153, 362, 158, 364, 168, 364, 181, 361, 188, 358, 194, 353, 200, 350, 195, 346, 194, 340, 199, 340, 205, 340, 209, 338, 212, 334, 215, 332, 217, 328, 221, 325, 225, 322, 231, 318, 235, 310, 232, 307, 230, 308, 228, 306, 227, 299, 226, 294, 222, 289, 216, 284, 209, 281, 203, 278, 198, 273, 193, 265, 189, 258, 183, 261, 172, 259, 161, 256, 154, 254, 153, 253, 149, 257, 147, 255, 145, 259, 142, 257, 141, 261, 137, 260, 136, 265, 132, 264, 131, 271, 125, 271, 126, 275, 122, 275, 121, 279, 117, 278, 114, 279, 108, 282, 105, 285, 101, 287, 99, 291, 98, 295, 99, 300, 97, 308, 97, 311, 99, 319, 99, 328, 96, 328, 94, 333, 99, 338, 99, 344, 99, 349, 103, 350],
                            "tip": {"lvl": {"min": 76, "max": 78}, "faction": "neutral", "quest": [95, 4, 0]}
                        },
                        "4197": {
                            "name": "Wintergrasp",
                            "points": [209, 338, 215, 331, 220, 325, 226, 321, 232, 316, 236, 309, 240, 306, 248, 307, 254, 308, 259, 310, 264, 313, 268, 315, 275, 319, 278, 322, 282, 324, 284, 326, 287, 330, 291, 335, 291, 339, 296, 342, 300, 343, 299, 350, 294, 351, 292, 352, 292, 357, 292, 364, 288, 364, 275, 366, 272, 366, 270, 364, 267, 356, 265, 357, 265, 364, 265, 365, 262, 366, 260, 363, 258, 361, 254, 362, 254, 365, 255, 370, 254, 373, 246, 374, 241, 373, 239, 373, 234, 373, 225, 376, 223, 372, 218, 366, 216, 364, 210, 360, 204, 357, 190, 356, 193, 352, 193, 348, 191, 342, 193, 336, 197, 337, 202, 337, 207, 338],
                            "tip": {"lvl": {"min": 77, "max": 80}, "faction": "neutral", "quest": [27, 0, 0]}
                        },
                        "4395": {
                            "name": "Crystalsong Forest",
                            "points": [323, 289, 327, 280, 335, 275, 346, 276, 354, 274, 359, 279, 369, 279, 373, 285, 379, 290, 385, 295, 395, 300, 406, 302, 416, 298, 425, 303, 431, 309, 430, 315, 429, 321, 433, 323, 437, 329, 434, 339, 429, 341, 419, 345, 414, 341, 404, 338, 401, 339, 394, 338, 383, 333, 380, 331, 375, 330, 366, 327, 358, 327, 349, 332, 331, 329, 326, 326, 322, 320, 322, 313, 322, 307, 321, 299, 321, 294],
                            "tip": {"lvl": {"min": 80, "max": 80}, "faction": "neutral", "quest": [6, 0, 0]}
                        }
                    },
                    "marks": {
                        "9": {
                            "name": "Dalaran",
                            "points": [327, 285],
                            "type": "n_capital",
                            "desc": "The magocratic city-state which was once located by the Lordamere Lake on the Alterac Mountains shore in the Eastern Kingdoms. With the beginning of the War against the Lich King its leaders, the Kirin Tor, have used their powers to move the city over the Crystalsong Forest in Northrend in order to use it as a front to attack the armies of the Lich King.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 14
                        },
                        "44": {
                            "name": "Utgarde Keep",
                            "points": [579, 482],
                            "type": "pin-blue",
                            "desc": "Utgarde Keep is the first dungeon hub located on the shores of Lake Cauldros in the Howling Fjord of Northrend. Inhabited by the vrykul who are led by King Ymiron, a half-giant Viking-like race bent on proving their strength to the Lich King, they are raising the most worthy of their warriors to serve him beyond the grave here at their main base of operations.",
                            "icon": "boss",
                            "lvl": {"min": 69, "max": 72},
                            "filter": 5
                        },
                        "45": {
                            "name": "Utgarde Pinnacle",
                            "points": [602, 482],
                            "type": "pin-blue",
                            "desc": "Utgarde Keep is the first dungeon hub located on the shores of Lake Cauldros in the Howling Fjord of Northrend. Inhabited by the vrykul (led by King Ymiron), a half-giant Viking-like race bent on proving their strength to the Lich King, they are raising the most worthy of their warriors to serve him at the main base of operations.",
                            "icon": "boss",
                            "lvl": {"min": 79, "max": 80},
                            "filter": 5
                        },
                        "46": {
                            "name": "The Nexus",
                            "points": [60, 386],
                            "type": "pin-blue",
                            "desc": "The Nexus, a dungeon hub, is an ice fortress found in the center of Coldarra, in Northrend's Borean Tundra. It is a column of magical energy surrounded by levitating earth-covered rings with ice caves underneath. The Nexus is an extensive series of caves and tunnels under Coldarra.",
                            "icon": "boss",
                            "lvl": {"min": 70, "max": 73},
                            "filter": 5
                        },
                        "47": {
                            "name": "The Oculus",
                            "points": [60, 374],
                            "type": "pin-blue",
                            "desc": "The Nexus, a dungeon hub, is an ancient ice fortress found in the center of Coldarra, in Northrend's Borean Tundra. It is a column of magical energy surrounded by levitating earth-covered rings with ice caves underneath. The Nexus is an extensive series of caves and tunnels under Coldarra, containing wings leading to two 5 man dungeons and one 25 man raid. ",
                            "icon": "boss",
                            "lvl": {"min": 79, "max": 80},
                            "filter": 5
                        },
                        "48": {
                            "name": "The Old Kingdom",
                            "points": [288, 391],
                            "type": "pin-blue",
                            "desc": "Azjol-Nerub is a vast underground dungeon hub home to the arachnid-like nerubian who were defeated by the Lich King in the War of the Spider. Located in icy Dragonblight, Azjol-Nerub can be divided into two sections: the Old Kingdom and the Upper Kingdom. In addition, many of the deepest areas in Azjol-Nerub are invaded by Faceless Ones.",
                            "icon": "boss",
                            "lvl": {"min": 73, "max": 78},
                            "filter": 5
                        },
                        "49": {
                            "name": "Azjol-Nerub",
                            "points": [292, 397],
                            "type": "pin-blue",
                            "desc": "Azjol-Nerub is a vast underground dungeon hub home to the ruins of the arachnid-like nerubian empire. Located in icy Dragonblight, Azjol-Nerub can be divided into two sections: the Old Kingdom and the Upper Kingdom. Many of the deepest areas in Azjol-Nerub are held by Faceless Ones.",
                            "icon": "boss",
                            "lvl": {"min": 72, "max": 74},
                            "filter": 5
                        },
                        "50": {
                            "name": "Drak'Tharon Keep",
                            "points": [462, 355],
                            "type": "pin-blue",
                            "desc": "Drak'Tharon Keep is an ancient ice troll stronghold located in the northwestern part of the Grizzly Hills. The Scourge drove the trolls out and took possession, and now the strange dungeon is filled with dinosaurs and lizards as well as teeming with undead. Players are sent in to learn the secrets behind Drakuru as they defeat the bosses inside.",
                            "icon": "boss",
                            "lvl": {"min": 74, "max": 76},
                            "filter": 5
                        },
                        "51": {
                            "name": "The Violet Hold",
                            "points": [344, 285],
                            "type": "pin-blue",
                            "desc": "Beneath the floating city of Dalaran is the 5 man dungeon The Violet Hold. Kirin Tor prison guards are fending off invaders of the blue dragonflight who, under orders from Malygos, are using magical portals to enter the hold. Players will relieve the guards and attempt to halt the invasion once and for all, defeating two random bosses before taking on Cyanigosa.",
                            "icon": "boss",
                            "lvl": {"min": 75, "max": 77},
                            "filter": 5
                        },
                        "52": {
                            "name": "Gundrak",
                            "points": [578, 231],
                            "type": "pin-blue",
                            "desc": "Gundrak is the capital of the Ice Trolls. Located in Zul'Drak, the instance contains two entrances which all lead into a main circle. The Drakkari tribe rule Zul'Drak from here, constantly battling the mighty forces of the Scourge.",
                            "icon": "boss",
                            "lvl": {"min": 76, "max": 78},
                            "filter": 5
                        },
                        "53": {
                            "name": "Halls of Stone",
                            "points": [406, 158],
                            "type": "pin-blue",
                            "desc": "Ulduar is a dungeon hub located at The Storm Peaks of Northrend, revealing many details about the Titans and their activities. In particular, Halls of Stone is controlled by storm giants and crystal golems. These giants are a dying race desperately avoiding their fate, avoiding conflict with the Scourge.",
                            "icon": "boss",
                            "lvl": {"min": 77, "max": 78},
                            "filter": 5
                        },
                        "54": {
                            "name": "Halls of Lightning",
                            "points": [430, 158],
                            "type": "pin-blue",
                            "desc": "Ulduar is a dungeon hub located at The Storm Peaks of Northrend, revealing many details about the Titans and their activities. Halls of LIghtning is home to Loken, a corrupted Titan watcher. ",
                            "icon": "boss",
                            "lvl": {"min": 79, "max": 80},
                            "filter": 5
                        },
                        "55": {
                            "name": "Trial of the Champion",
                            "points": [316, 182],
                            "type": "pin-blue",
                            "desc": "Trial of the Champion is a 5-man instance located in the northeast corner of Icecrown, inside the Crusaders' Coliseum at the Argent Tournament grounds. The entrance can be found on the north side of the building. One member of your party needs to talk to a NPC present to start each encounter.",
                            "icon": "boss",
                            "lvl": {"min": 78, "max": 80},
                            "filter": 5
                        },
                        "56": {
                            "name": "Forge of Souls",
                            "points": [240, 261],
                            "type": "pin-blue",
                            "desc": "The Forge of Souls is the first wing of the dungeon complex known as the Frozen Halls, located within Icecrown Citadel. The instance portal is located to the left inside the secured area of Icecrown Citadel, near the meeting stone. No attunement is required for entry, but completing the instance is required to gain entrance to the Pit of Saron.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 5
                        },
                        "57": {
                            "name": "Pit of Saron",
                            "points": [246, 272],
                            "type": "pin-blue",
                            "desc": "The Pit of Saron is the second wing of the Frozen Halls, located within Icecrown Citadel. The The Forge of Souls must be completed before a player can access the Pit of Saron, and this dungeon must be completed in order to access the Halls of Reflection.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 5
                        },
                        "58": {
                            "name": "Halls of Reflection",
                            "points": [252, 261],
                            "type": "pin-blue",
                            "desc": "Halls of Reflection is the third and final wing of the Frozen Halls, located within Icecrown Citadel. The The Forge of Souls and Pit of Saron must be completed before a player can enter the Halls of Reflection for the first time.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 5
                        },
                        "83": {
                            "name": "Naxxramas",
                            "points": [396, 363],
                            "type": "pin-purple",
                            "desc": "Naxxramas is an introductory level-80 raid dungeon floating above Dragonblight in Northrend. It is a Scourge necropolis, the seat of the Arch Lich Kel'Thuzad. The 40-man classic version of Naxxramas is no longer available, having been permanently closed with the release of the Wrath of the Lich King expansion.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 11
                        },
                        "84": {
                            "name": "Vault of Archavon",
                            "points": [242, 317],
                            "type": "pin-purple",
                            "desc": "Vault of Archavon is a raid instance located within Wintergrasp's fortress. It is accessible to the winning faction that claims victory over Wintergrasp. Players who wish to enter this instance may also use the portal activated in Dalaran, though it will only be available to players of the winning faction.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 11
                        },
                        "85": {
                            "name": "The Obsidian Sanctum",
                            "points": [348, 374],
                            "type": "pin-purple",
                            "desc": "The Obsidian Sanctum, a part of the Chamber of Aspects, is a secret chamber where members of the Black Dragonflight would convene whenever they wished to meet.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 11
                        },
                        "86": {
                            "name": "Ruby Sanctum",
                            "points": [358, 374],
                            "type": "pin-purple",
                            "desc": "The Ruby Sanctum, a part of the Chamber of Aspects, is a secret meeting place for members of the Red Dragonflight.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 11
                        },
                        "87": {
                            "name": "The Eye of Eternity",
                            "points": [60, 362],
                            "type": "pin-purple",
                            "desc": "The Nexus, a dungeon hub, is an ancient ice fortress found in the center of Coldarra, in Northrend's Borean Tundra. It is a column of magical energy surrounded by levitating earth-covered rings with ice caves underneath. The Nexus is an extensive series of caves and tunnels that riddles Coldarra, containing wings leading to two 5 man dungeons and one 25 man raid.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 11
                        },
                        "88": {
                            "name": "Ulduar",
                            "points": [418, 148],
                            "type": "pin-purple",
                            "desc": "Ulduar is a raid dungeon in the Titan complex of Ulduar, located within the The Storm Peaks. It serves as the prison of the old god Yogg-Saron as well as the current residence of most of the titanic watchers who have fallen under his influence. It is notable for its interactive ways of starting hardmodes--instead of switching the difficulty of the encounter before fighting, players would have to start the encounter in a certain way to unlock the hardmode. For example: defeating Thorim's gauntlet in 3 minutes or less would trigger his hardmode.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 11
                        },
                        "89": {
                            "name": "Trial of the Crusader",
                            "points": [328, 182],
                            "type": "pin-purple",
                            "desc": "Trial of the Crusader is located in the Argent Tournament Grounds, in north-east corner of Icecrown. The entrance portal is located on the east side of the Argent Coliseum, near the Tier 9 and Emblem of Triumph vendors.",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 11
                        },
                        "90": {
                            "name": "Icecrown Citadel",
                            "points": [258, 272],
                            "type": "pin-purple",
                            "desc": "The Icecrown Citadel is the final raid instance in Wrath of the Lich King, and its final boss is none other than Arthas Menethil, the Lich King himself!",
                            "icon": "boss",
                            "lvl": {"min": 80, "max": 80},
                            "filter": 11
                        },
                        "150": {
                            "name": "Kamagua",
                            "points": [508, 529],
                            "type": "village",
                            "desc": "Kamagua is a tuskarr settlement on the Isle of Spears in the Howling Fjord within the icy barren wastes of Northrend. The Kalu'ak, a tuskarr faction, run the area. You can reach this location via a boat from Moa'ki Harbor, Dragonblight.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "151": {
                            "name": "Westguard Keep",
                            "points": [517, 508],
                            "type": "village",
                            "desc": "Westguard Keep is situated atop the Howling Fjord cliffs on its western side. It has a joint human\/dwarven population similar to Valgarde.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "152": {
                            "name": "New Agamand",
                            "points": [567, 535],
                            "type": "village",
                            "desc": "New Agamand is a Forsaken town in the Howling Fjord. Players are sent here after finishing the plague-related quest chains at Vengeance Landing. The town is presumably named after the Agamand family and their haunted mills, a symbol of the prosperity of Tirisfal Glades before the Plague of Undeath. Unlike other towns controlled by the Forsaken \u2014 which are actually ruined villages in northern Lordaeron, for the most part \u2014 this town appears to be a new construction. This town allows one of the first glimpses into Forsaken architectural style. New Agamand is at the front line of the Forsaken efforts against the Scourge. Since Sylvanas Windrunner's rise to power, the Royal Apothecary Society in the Undercity have been developing a \"New Plague\" intended to wipe out the Scourge. After several years of research, the Forsaken are now ready to unleash their ultimate weapon against Arthas' forces, and it will be at New Agamand where the testing begins.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "153": {
                            "name": "Valgarde",
                            "points": [586, 523],
                            "type": "village",
                            "desc": "Formerly the only established Alliance settlement in Northrend, Valgarde is the obvious arrival point for anyone traveling to Northrend. It is a rough seaport and you can find all races, occupations and characters floating through here. Valgarde is an excellent place to find information about Northrend in general, and to hire guides or buy equipment before setting out. It is also the only place in Northrend where you can hire passage off this ice-coated land, back to warmer and more civilized continents. Of course, Drakkari trolls, furbolgs and occasional monsters attack the town frequently, but its strong walls never fail and the watchtowers provide ample warning.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "154": {
                            "name": "Vengeance Landing",
                            "points": [636, 470],
                            "type": "village",
                            "desc": "Vengeance Landing is the military outpost for the Hand of Vengeance in the Howling Fjord, northeast of Daggercap Bay and Utgarde Keep 76.7, 28.9. Its main feature is its zeppelin tower which is the Horde's main point of arrival in eastern Northrend from Tirisfal Glades, just outside of Undercity.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "155": {
                            "name": "Fort Wildervar",
                            "points": [599, 441],
                            "type": "village",
                            "desc": "Fort Wildervar is the Alliance's northernmost outpost in Howling Fjord, at the base of Frostblade Peak, north of Caldemere Lake and The Frozen Glade, northwest of Giants' Run and east of Camp Winterhoof.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "156": {
                            "name": "Camp Winterhoof",
                            "points": [566, 435],
                            "type": "village",
                            "desc": "Camp Winterhoof is located at the northern edge of Howling Fjord, west of Fort Wildervar. It is where Chieftain Ashtotem and his Taunka reside.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "157": {
                            "name": "Camp Oneqwah",
                            "points": [568, 382],
                            "type": "village",
                            "desc": "Camp Oneqwah is an area in centraleastern Grizzly Hills between Grizzlemaw and the coast. Tormak the Scarred and his Taunka reside here. The camp is rather close to Solstice Village, so they might be fighting them. The Taunka from villages across Northrend are planning to evacuate here.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "158": {
                            "name": "Westfall Brigade Encampment",
                            "points": [553, 349],
                            "type": "village",
                            "desc": "Westfall Brigade Encampment is an Alliance settlement in Grizzly Hills. The People's Militia has become the Westfall Brigade and is under the command of Gryan Stoutmantle, who himself has received a promotion to Captain. They have relocated from Sentinel Hill to Westfall Brigade Encampment in the Grizzly Hills, joining the war against the Scourge.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "159": {
                            "name": "Amberpine Lodge",
                            "points": [489, 399],
                            "type": "village",
                            "desc": "Amberpine Lodge is the primary Alliance outpost in the western area of the Grizzly Hills. Previously referred to as a lodge maintained for hunters and trappers, Amberpine has been recently commandeered for military use. This is the first town encountered with breadcrumb quests by way of The Hills Have Us.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "160": {
                            "name": "Conquest Hold",
                            "points": [460, 410],
                            "type": "village",
                            "desc": "Conquest Hold is the main Horde camp in the Grizzly Hills. Conqueror Krenna, known to be aggressive even for an orc, rules over the forces stationed there.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "161": {
                            "name": "Zim'Torga",
                            "points": [517, 291],
                            "type": "village",
                            "desc": "Zim'Torga is a neutral troll encampment controlled by the Zandalari. It is between the Argent Stand and Gundrak in Zul'Drak.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "162": {
                            "name": "Argent Stand",
                            "points": [475, 318],
                            "type": "village",
                            "desc": "The Argent Stand is a base for the Argent Crusade in Zul'Drak. It is a large troll structure taken by the Crusade and serves as the main Argent Crusade questing hub in the region. From it, they defend the second tier of Zul'Drak from being invaded by the Scourge.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "163": {
                            "name": "Crusaders' Pinnacle",
                            "points": [338, 263],
                            "type": "village",
                            "desc": "Mockingly named by the Scourge, Crusaders' Pinnacle is a small mountain plateau northwest of Argent Vanguard and north of Dalaran in Icecrown.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "164": {
                            "name": "Frosthold",
                            "points": [378, 249],
                            "type": "village",
                            "desc": "Frosthold is an Alliance town aligned with the Frostborn in southwestern Storm Peaks, south of the Temple of Storms and northwest of K3, on the same mountain as Stormcrest. It is home to the whole frost dwarf race and their king, Yorg Stormheart. The town is located in and around a large pit of ice. Closed doors hints that more of the city is inside the mountain.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "165": {
                            "name": "K3",
                            "points": [415, 276],
                            "type": "village",
                            "desc": "K3  is a neutral goblin base camp located on the southern base of Storm Peaks on the continent of Northrend. The goblins are out to loot the titan machines in the peaks but are having problems with the local wildlife.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "166": {
                            "name": "Brunnhildar Village",
                            "points": [436, 244],
                            "type": "village",
                            "desc": "Brunnhildar Village is a village situated above Snowblind Terrace and to the east of Sifreldar Village in the southern area of the Storm Peaks.  It is inhabited by level 79-80 frost vrykul known as the hyldnir.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "167": {
                            "name": "Camp Tunka'lo",
                            "points": [490, 202],
                            "type": "village",
                            "desc": "Camp Tunka'lo is located in eastern Storm Peaks, above and to the north of Dun Niffelem, to the south of the Plain of Echoes and to the southeast of the Temple of Life.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "168": {
                            "name": "The Grom'arsh Crash-Site",
                            "points": [384, 208],
                            "type": "village",
                            "desc": "The Grom'arsh Crash-Site  can be found to the east of the Temple of Storms, southeast of the Snowdrift Plains, west of the Terrace of the Makers, and north of the Engine of the Makers within the Storm Peaks. It is an encampment built around a recently crashed zeppelin. It is likely named after the zeppelin, which is, in turn, likely named after the orc hero Grom Hellscream or derived from the orcish word for giant.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "169": {
                            "name": "Shadow Vault",
                            "points": [245, 178],
                            "type": "village",
                            "desc": "The Shadow Vault is a neutral quest hub for the Knights of the Ebon Blade, located near Aldur'thar: The Desolation Gate in northern Icecrown. The Shadow Vault was originally controlled by the Scourge, and players are given a quest chain \u2014 started by either Thassarian onboard the Skybreaker or Koltira Deathweaver onboard the Orgrim's Hammer, the flying battleships that patrol the skies of Icecrown \u2014 starting with the quest, It's All Fun and Games (Alliance) or It's All Fun and Games (Horde), to work with the Ebon Blade in taking it as a base. Once the chain is complete upon their return to the death knight questgiver on either one of the battleships, the Ebon Blade NPCs will appear in and around the Vault through the new phasing system.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "170": {
                            "name": "Nesingwary Base Camp",
                            "points": [111, 301],
                            "type": "village",
                            "desc": "The Nesingwary Base Camp is Hemet Nesingwary's new location in Northrend. The base camp is located in western Sholazar Basin, just north of The Seabreach Flow, inside the Path of the Lifewarden, southwest of The Suntouched Pillar and west of the Wildgrowth Mangal.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "171": {
                            "name": "Bor'gorok Outpost",
                            "points": [106, 349],
                            "type": "village",
                            "desc": "Bor'gorok Outpost is a Horde outpost south of the entrance to Sholazar Basin and east of Winterfin Retreat in the most northern part of the Borean Tundra.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "172": {
                            "name": "Fizzcrank Airstrip",
                            "points": [128, 370],
                            "type": "village",
                            "desc": "Fizzcrank Airstrip is a gnome base in Borean Tundra, overshadowed by the crashed necropolis of Talramas.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "173": {
                            "name": "Warsong Hold",
                            "points": [92, 421],
                            "type": "village",
                            "desc": "Warsong Hold  is the headquarters of the Horde forces in Northrend. It was constructed and is owned by the Warsong Offensive, lead by Garrosh Hellscream \u2014 formerly chieftain of the Mag'har in Outland. This massive fortress is located in southern Borean Tundra, just a short distance from the coastline.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "174": {
                            "name": "Valiance Keep",
                            "points": [134, 450],
                            "type": "village",
                            "desc": "Valiance Keep is the major Alliance settlement in the Borean Tundra, similar to Warsong Hold for the Horde. It has a large icebreaker in the center of the town and has regular transport service from Stormwind Harbor via another icebreaker, The Kraken.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "175": {
                            "name": "Taunka'le Village",
                            "points": [179, 400],
                            "type": "village",
                            "desc": "Taunka'le Village is a taunka village found just southeast of the Geyser Fields in the Borean Tundra.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "176": {
                            "name": "Stars' Rest",
                            "points": [283, 398],
                            "type": "village",
                            "desc": "Stars' Rest is a small Alliance camp located south of Icemist Village in the Dragonblight. The camp is a night elf camp built within the ruins of the past. Frost nymphs have appeared from the nearby forest to help the night elves. There is a moonwell here as well.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "177": {
                            "name": "Agmar's Hammer",
                            "points": [298, 386],
                            "type": "village",
                            "desc": "Agmar's Hammer is the Horde base in the Dragonblight zone of Northrend. It is lead by Overlord Agmar, and demonstrates the new, more aggressive Horde look",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "178": {
                            "name": "Moa'ki Harbor",
                            "points": [329, 425],
                            "type": "village",
                            "desc": "Moa'ki Harbor is a tuskarr port in south-central the Dragonblight. Tuskarr turtle boats to Unu'pe in Borean Tundra and Kamagua in Howling Fjord depart from here.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "179": {
                            "name": "Wyrmrest Temple",
                            "points": [355, 366],
                            "type": "village",
                            "desc": "Wyrmrest Temple is an ancient Titan city located in The Dragonblight on Northrend. Formerly home to the Storm Giants, it has been taken over by the Wyrmrest Accord. It was the ancient meeting place of the dragonflights.",
                            "icon": "neutral",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "180": {
                            "name": "Venomspite",
                            "points": [389, 407],
                            "type": "village",
                            "desc": "Venomspite is a Forsaken town in eastern Dragonblight. Here, the Hand of Vengeance are continuing their plague experiments, and Horde players are sent here by a special flight path that requires you to have finished the primary quest chains at New Agamand in Howling Fjord and to be level 71. To the north lies the equivalent questing hub of the Alliance called Wintergarde Keep.",
                            "icon": "horde",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        },
                        "181": {
                            "name": "Wintergarde Keep",
                            "points": [391, 381],
                            "type": "village",
                            "desc": "Wintergarde Keep is the main Alliance base in Dragonblight. The lower half of this tiered city is now taken over by the Scourge and the remainder is besieged by forces operating out of Naxxramas, which hovers in the skies outside of the keep.",
                            "icon": "alliance",
                            "lvl": {"min": 0, "max": 0},
                            "filter": 15
                        }

                    }
                },
                "mal": {
                    "name": "Maelstrom",
                    "points": {
                        "4720": {
                            "name": "The Lost Isles",
                            "points": [120, 474, 87, 482, 52, 458, 33, 413, 52, 376, 77, 355, 120, 348, 156, 378, 165, 408, 165, 438, 122, 467],
                            "tip": {"lvl": {"min": 5, "max": 12}, "faction": "horde", "quest": [71, 1, 1]}
                        },
                        "4737": {
                            "name": "Kezan",
                            "points": [193, 435, 151, 496, 154, 531, 182, 571, 221, 594, 296, 593, 318, 582, 331, 522, 311, 477, 278, 445, 257, 431, 239, 423],
                            "tip": {"lvl": {"min": 1, "max": 5}, "faction": "horde", "quest": [27, 3, 0]}
                        },
                        "5042": {
                            "name": "Deepholm",
                            "points": [175, 117, 169, 172, 160, 228, 160, 273, 159, 318, 179, 358, 194, 383, 214, 407, 223, 419, 249, 426, 288, 446, 329, 464, 373, 477, 426, 481, 467, 484, 511, 468, 556, 446, 582, 415, 609, 391, 637, 359, 654, 318, 664, 281, 670, 251, 666, 215, 655, 189, 654, 166, 650, 138, 641, 118, 623, 92, 602, 65, 570, 44, 546, 30, 523, 24, 482, 12, 456, 13, 404, 13, 364, 19, 313, 29, 276, 47, 242, 70, 207, 101],
                            "tip": {"lvl": {"min": 82, "max": 83}, "faction": "neutral", "quest": [122, 11, 0]}
                        }
                    },
                    "marks": {
                        "29": {
                            "name": "The Stonecore",
                            "points": [410, 223],
                            "type": "pin-red",
                            "desc": "The Stonecore is a 5-man dungeon designed for players leveling through Deepholm. It is located high in the Temple of Earth and requires a flying mount to reach. Once a sacred ground for the denizens of Deepholm, the Stonecore has almost completely fallen under the control of the Twilight Hammer. The High Priestess Azil herself is in charge here, but players may be more excited to see Millhouse Manastorm, who makes a brief appearance in the beginning of the dungeon.",
                            "icon": "boss",
                            "lvl": {"min": 82, "max": 85},
                            "filter": 4
                        }
                    }
                }
            };

            var east = $.parseJSON('<?php echo $regions['east'] ?>');
            var out = $.parseJSON('<?php echo $regions['out'] ?>');
            var kalimdor = $.parseJSON('<?php echo $regions['kalimdor'] ?>');
            var north = $.parseJSON('<?php echo $regions['north'] ?>');
            var mal = $.parseJSON('<?php echo $regions['mal'] ?>');

            $.each(mal, function (i, item) {
                mapdata.mal.marks[Math.random() * (1000 - 10000)] = {
                    "name": item.name,
                    "points": $.parseJSON(item.points),
                    "type": item.icon,
                    "desc": item.desc,
                    "icon": item.typeicon,
                    "lvl": {"min": item.min, "max": item.max},
                    "filter": item.filter
                };
            });
            $.each(kalimdor, function (i, item) {
                mapdata.kalimdor.marks[Math.random() * (1000 - 10000)] = {
                    "name": item.name,
                    "points": $.parseJSON(item.points),
                    "type": item.icon,
                    "desc": item.desc,
                    "icon": item.typeicon,
                    "lvl": {"min": item.min, "max": item.max},
                    "filter": item.filter
                };
            });
            $.each(out, function (i, item) {
                mapdata.out.marks[Math.random() * (1000 - 10000)] = {
                    "name": item.name,
                    "points": $.parseJSON(item.points),
                    "type": item.icon,
                    "desc": item.desc,
                    "icon": item.typeicon,
                    "lvl": {"min": item.min, "max": item.max},
                    "filter": item.filter
                };
            });
            $.each(north, function (i, item) {
                mapdata.north.marks[Math.random() * (1000 - 10000)] = {
                    "name": item.name,
                    "points": $.parseJSON(item.points),
                    "type": item.icon,
                    "desc": item.desc,
                    "icon": item.typeicon,
                    "lvl": {"min": item.min, "max": item.max},
                    "filter": item.filter
                };
            });
            $.each(east, function (i, item) {
                mapdata.east.marks[Math.random() * (1000 - 10000)] = {
                    "name": item.name,
                    "points": $.parseJSON(item.points),
                    "type": item.icon,
                    "desc": item.desc,
                    "icon": item.typeicon,
                    "lvl": {"min": item.min, "max": item.max},
                    "filter": item.filter
                };
            });

            myMap.loadData(mapdata);

            $(window).hashchange(function () {
                if (location.hash && location.hash !== '#view-page') {
                    myMap.ChangeMap(location.hash);
                } else {
                    myMap.ChangeMap('east');
                }
            });
            $('.map-list dd').on("click", function () {
                location.hash = $(this).data('type');
            });
            $('#map-filters input').change(function () {
                myMap.UpdateFilters();
            });
            $(document).scroll(function () {
                myMap.RelocateTooltip();
            });
            $(window).hashchange();
        });
    </script>

</div>