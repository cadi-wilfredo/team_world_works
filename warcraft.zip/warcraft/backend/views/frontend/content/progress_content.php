<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1417" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                            <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                            <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                            <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">
        <div id="breadcrumbs">
            <ul style="list-style:none" itemprop="breadcrumb" id="breadcrumbs-position">
                <li><a href="#!">Atlantiss</a></li>
                <li><a href="#!">Progress Through Expansions</a></li>
            </ul>
        </div>

        <div class="fullpage-article page-content">
            <div itemtype="#!" itemscope="" class="fullpage-article-content">
                <h2 itemprop="name">Progress Through Expansions</h2>
                <div itemprop="description"><p style="text-align: justify;">PTE ("Progress Through Expansions")&nbsp;is something new for us and for
                        you as well. Thus far none private server did not manage to achieve what we plan to do. What is PTE about?<br><br>PTE will
                        allow you a progressive which will begin with TBC and finish along with the end of Cataclysm. You'll experience something
                        what, hitherto only Retail players could experience, full of passion, rivalry, a path through The Burning Crusade, Wrath of
                        the Lich King and Cataclysm!</p>
                    <p style="text-align: justify;">PTE project establishes an idea of creating 3 realms, TBC, WotLK and Cataclysm, one by one. Every
                        realm will be progressive and blizzlike. After the end of progression on one expansion, there will be opened a new realm,
                        players will have an opportunity to transfer their characters from one expansion onto another, thus, after achieving
                        everything on TBC you'll be able to transfer your character onto WotLK without losing anything on TBC realm.</p>
                    <p style="text-align: justify;">The first realm from PTE project will be none other than 2.4.3 Netherwing!</p>
                    <ul style="text-align: justify;">
                        <li>On our project we're working more than 6 months, during those months we perfected the project organisation and details of
                            PTE, we also developed Netherwing realm. As you can see, the development of Dragonwrath realm did not suffer, sole PTE
                            project will even speed up our work on Cataclym core since it will be the 3rd realm in our project.
                        </li>
                        <li>PTE is a challenge for us, it's an excercise and it gives us satisfaction. As a team we want to fulfil this undertaking
                            even for ourselves. We think that this is something fresh, interesting and it's very promising, and we'll do our best for
                            PTE to completely change the private servers scene and once again to prove that we know what we're doing.
                        </li>
                        <li>At the same time we also make plans towards further Cataclym development. About all of this we already thought, wondered,
                            planned and counted our possibilities for a long time. It's not a hasty decision and we realise what we need to face. We
                            hope that these guarantees will eliminate most of your concerns about whether we'll manage to deliver it or is anyone
                            going to suffer from it and at the same time we hope for your support in any form. Together with you, we'll achieve it!
                        </li>
                    </ul>
                    <p style="text-align: justify;">More details:</p>
                    <ul style="text-align: justify;">
                        <li>PTE project realms will be opened at the starting progression cap, e.g. Cataclysm realm upon start will offer a
                            posibillity to complete only dungeons, and after this stage we'll open T11 raids.
                        </li>
                        <li>Realms after the end of progression will remain available for players.</li>
                        <li>Players will be able to begin his journey at any time on any realm, e.g. if the progress is currently on T12, the player
                            can start on TBC or WotLK realm and later, simply transfer his character onto Cataclysm or he can begin on Cataclysm
                            straight away.
                        </li>
                        <li>PTE project is a separate project, Dragonwrath realm will still be available for everyone.</li>
                        <li>Each expansion will require appropriate game client.</li>
                    </ul>
                    <p style="text-align: justify;">The project is still in a development stage and it's pretty certain that changes, about which
                        you'll be surely informed, will take place.</p></div>
                <div class="line">
                    Last change
                    <meta content="2016-02-25 17:49:11" itemprop="datePublished">
                    <time itemprop="dateModified" datetime="2016-02-25 17:49:11">25 February 2016</time>
                </div>
            </div>
        </div>

    </div>
</div>