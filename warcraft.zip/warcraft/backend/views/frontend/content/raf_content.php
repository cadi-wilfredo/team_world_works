<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1417" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                            <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                            <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                            <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">
        <div id="breadcrumbs">
            <ul style="list-style:none" itemprop="breadcrumb" id="breadcrumbs-position">
                <li><a href="#!">Atlantiss</a></li>
                <li><a href="#!">Recruit a Friend</a></li>
            </ul>
        </div>

        <div class="fullpage-article page-content">
            <div itemtype="#!" itemscope="" class="fullpage-article-content">
                <h2 itemprop="name">Recruit a Friend</h2>
                <div itemprop="description"><p style="text-align: justify;">Recruit a Friend system (RaF) allows to send an invitation to friends in a
                        reference link form. When the person receiving the invitation creates an account it will be linked with sender's account. From
                        this moment, both receiver and sender can get a few benefits.<br><br><strong>What can I get using RaF?</strong></p>
                    <ol style="text-align: justify;">
                        <li>Bonus experience from both quests and killing mobs.</li>
                        <li>Ability to summon linked friends.</li>
                        <li>Ability to grant levels.</li>
                        <li>Bonus to reputation gained.</li>
                    </ol>
                    <p style="text-align: justify;"><strong>What are the requirements and details of receiving those benefits?</strong></p>
                    <ol>
                        <li style="text-align: justify;">RaF works only for 90 days from the moment of creating account from reference link only when
                            characters are level 79 or below.
                        </li>
                        <li style="text-align: justify;">Both the recruit and the recruiter gain triple experience points while partied and within 100
                            yards of each other. This does not stack with rested XP.
                        </li>
                        <li style="text-align: justify;">If both characters are not within 4 levels of each other, only the lower-level character will
                            gain extra experience.
                        </li>
                        <li style="text-align: justify;">Both the recruit and the recruiter gain 10% bonus to reputation received when killing mobs.
                            This does not include reputation from completing quests or other sources.
                        </li>
                        <li style="text-align: justify;">Recruit characters gain one "grantable" level for every two levels earned. Recruit characters
                            may then grant these levels to the recruiter's lower-level characters.
                        </li>
                        <li style="text-align: justify;">Both the recruit and the recruiter can summon each other while partied. This "Summon Friend"
                            ability has a 30 minute cooldown. The summoned character must be level 79 or below.
                        </li>
                    </ol>
                </div>
                <div class="line">
                    Last change
                    <meta content="2013-07-21 12:30:03" itemprop="datePublished">
                    <time itemprop="dateModified" datetime="2013-07-21 12:30:03">21 July 2013</time>
                </div>
            </div>
        </div>

    </div>
</div>