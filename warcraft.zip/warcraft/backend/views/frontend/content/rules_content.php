<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1417" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                            <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                            <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                            <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">
        <div id="breadcrumbs">
            <ul style="list-style:none" itemprop="breadcrumb" id="breadcrumbs-position">
                <li><a href="#!">Atlantiss</a></li>
                <li><a href="#!">Rules</a></li>
            </ul>
        </div>

        <div class="fullpage-article page-content">
            <div itemtype="#!" itemscope="" class="fullpage-article-content">
                <h2 itemprop="name">Rules</h2>
                <div itemprop="description">
                    <ol>
                        <li style="text-align: justify;">Registering on our server and forum means acceptance of our Rules. A player is obliged to
                            acquaint with the Rules, has to abide by them and follow any changes which can be made by Administrators.<br><br></li>
                        <li style="text-align: justify;">Every FORUM/SERVER/<a href="#!">TeamSpeak/IRC</a> user has to follow the
                            Netiquette.<br><br></li>
                        <li style="text-align: justify;">Playing on our server is completely free and open for everyone. Nobody from the <a
                                href="#!">Team</a>&nbsp;(Administrators, Game Masters etc.) is gaining any profits, they spend their
                            time working on this server of their own free will, so you should treat them with regard.
                            <ol>
                                <li style="text-align: justify;">Any words from Administrators or <a href="#!">GMs</a> are undisputed
                                    and indisputable (in a case when everything is clear and every single detail is known, and Administration clearly
                                    claims it).
                                </li>
                                <li style="text-align: justify;">Cases that are not covered by these rules will be investigated individually.</li>
                            </ol>
                        </li>
                        <li style="text-align: justify;"><strong>Any objections and appeals must be be reported by an Email Message to&nbsp;Administration:
                                <a href="#!">complaints@atlantiss.eu</a></strong>&nbsp;(we
                            require a strong proof and screens/videos). <strong><strong>Complaints written on the forum are going to be
                                    deleted.&nbsp;</strong></strong><br>
                            <ol>
                                <li>The administration staff does not have to show proofs regarding a case. All punishments are discussed earlier, the
                                    proofs are checked in a in-depth manner and the punishment is adequate to the violation.<br><br></li>
                            </ol>
                        </li>
                        <li style="text-align: justify;">Administrators are not taking responsibility for the account, its content or information
                            loss. Setting up a strong password is the best way to protect if from other people. Remember! Nobody from the Team would
                            want you telling them your account details (like password, mail etc.).&nbsp;<strong>The administration staff takes no
                                responsibility for hacked accounts.</strong><br><br></li>
                        <li style="text-align: justify;"><a href="#!">GMs/Admins</a> do not change the race/class/sex of a character,
                            they do not change a nickname nor make character transfers, do not move/exchange/give items/gold, do not complete quests
                            for any players (it can be done only in cases with no other way) and do not give back items/honor/ap/rating/gold etc lost
                            because of dc/player's fault/technical problems/actions by a third party.<br><br>Only in some cases we consider giving
                            back things, which have made a permanent track in the database and could not be deleted or given away in any way by the
                            player (e.g. reputations, quest rewards (not daily). We do not consider item/gold/achievements.<br><br></li>
                        <li style="text-align: justify;">Administrators have the right to shut down/restart the server without letting players know
                            about it in a case of unforeseen situations like: improvements, changes, updates and technical problems.<br><br></li>
                        <li style="text-align: justify;">Developers have <a href="#!">GM</a> profile accounts and they can penalty
                            players. If you have any objections, please look at the 3rd point.<br><br></li>
                        <li style="text-align: justify;">Every member of Administration can play on private characters, they do not have to inform
                            about them. The Team is not supporting any players, guilds, friends or faction and they cannot help them in any way. If
                            you are suspecting any of the Administrators for cheating, we can share logs with you. In this case you should write to
                            Ranor with some good reasons.<br><br></li>
                        <li style="text-align: justify;">Chat owners and moderators are responsible for the behaviour on global chats. They can kick
                            or ban any players who are not abiding by the Rules. Administrators will only take steps in case of Owner/Moderator
                            inactivity. It refers to any channels despite guild/whisper chat, but only to a certain extent.<br><br></li>
                        <li style="text-align: justify;">We will not interfere in a case of whispering to someone such things as "you are stupid, I'm
                            not playing with you" - there is an "ignore" function or just do not care about them. We will do something only in a
                            severe situation.<br><br></li>
                        <li style="text-align: justify;">In the case of continous and groundless banning/kicking/muting players by the owner there are
                            sought penalties, Administrators will decide about them.<br><br></li>
                        <li style="text-align: justify;">Administrators are not required to answer questions written on whisper or public channels. Do
                            you have a problem? Send a ticket.<br><br></li>
                        <li style="text-align: justify;">We do not transfer characters from other servers. (Does not apply between 25.03.2015 and
                            04.07.2015.).<br><br></li>
                        <li style="text-align: justify;">Atlantiss administration staff does not force anybody to play on the server. If, by any
                            reason, our server seems unsuitable for you &ndash; choose a different one and do not vent your anger or frustration on
                            the forum or in the game.<br><br></li>
                        <li style="text-align: justify;">You may recognize a <a href="#!">GM</a> by a "Blizz" logo by their nickname and
                            "GM" title above their character. The majority of <a href="#!">GMs</a>’ public characters are also members
                            of the "Administracja" or "Atlantiss Staff" guild. If, by any chance, there is a suspicion of someone impersonating a <a
                                href="#!">GM</a>, you may request the individual to prove his status. In such case, a <a
                                href="#!">GM</a> will use a command, e.g. teleport. Impersonation of any administration staff member in
                            any way (simply calling oneself an administrator, <a href="#!">dev</a>, <a href="#!">GM</a>;
                            using the "Blizz" logo; any similar behaviour) is strictly forbidden.<br><br></li>
                        <li style="text-align: justify;">Every administration staff member is allowed to enter a raid of any guild/party, except his
                            personal character’s own guild/party.
                            <ol>
                                <li style="text-align: justify;">During such action, the <a href="#!">GM’s</a> character is required to
                                    be in the <a href="#!">GM</a> mode and Invisible.
                                </li>
                                <li style="text-align: justify;">In case of exploiting or bugging detection during such a visit, the investigating <a
                                        href="#!">GM</a> is allowed to wipe the raid, kick each raid member from the server or punish
                                    the raid members with a server ban.
                                </li>
                            </ol>
                        </li>
                        <li>The main chat channel is "world" and its obligatory language is English.&nbsp;The website and the forum are English.
                            Comments must be written in English. All players that break this rule will be punished. All posts/comments that break this
                            rule will be removed and the user will be punished.
                        </li>
                    </ol>
                    <h3 style="text-align: center;"><strong>PENALTIES</strong></h3>
                    <center></center>
                    <ol>
                        <li style="text-align: justify;">Communicating in-game with other Users and Atlantiss representatives, whether by text, voice
                            or any other method, (Server/Forum/TeamSpeak/IRC) is an integral part of the Game and the Service and is referred to here
                            as "Chat." When engaging in Chat, you may not: <br>Transmit or post any content or language which, in the sole and
                            absolute discretion of Atlantiss, is deemed to be offensive, including without limitation content or language that is
                            unlawful, harmful, threatening, abusive, harassing, defamatory, vulgar, obscene, hateful, sexually explicit, or racially,
                            ethnically or otherwise objectionable, nor may you use a misspelling or an alternative spelling to circumvent the content
                            and language restrictions listed above.<br>Every person playing on this server is equal, regardless of previous servers or
                            the faction (Alliance and Horde), player should be respected. Breaking this rule will be severely punished.<br><br></li>
                        <li style="text-align: justify;">Gaining any profits from game (selling/buying accounts/gold/items/time etc. (also&nbsp;selling/buying&nbsp;
                            attempt)) is BANNED. In a case of breaking this rule we will impose a permanent ban.<br><br></li>
                        <li style="text-align: justify;">Bugging with premeditation or bugging without reporting will be SEVERELY punished.<br><br>
                        </li>
                        <li style="text-align: justify;">It is banned to use cheats (programs like fly hack, speed hack, teleport) or bots (programs
                            which are helping you e.g. farming - autoclick, automove, fishbot). Addons are allowed. Breaking this rule will result
                            with a permanent ban.<br><br></li>
                        <li style="text-align: justify;">Any advertisements of other servers/websites/products is forbidden - forcing players to move
                            to other server is completely banned and will be severely punished.<br><br></li>
                        <li style="text-align: justify;">There is an outright ban for impersonation of Administrators and writing on their behalf.
                            Punishment - permanent ban.<br><br></li>
                        <li style="text-align: justify;">Arena match fixing is forbidden. If we discover this type of action, then there will be
                            deleted:
                            <ul>
                                <li style="text-align: justify;">All items received by the arena system</li>
                                <li style="text-align: justify;">Arena points</li>
                                <li style="text-align: justify;">Honor points</li>
                                <li style="text-align: justify;">Arena team<br><br></li>
                            </ul>
                        </li>
                        <li style="text-align: justify;">Multiboxing is forbidden in PvP (for example being in a queue for battleground in Alliance as
                            well as in Horde).<br><br></li>
                        <li style="text-align: justify;">Baseless accusations of the administration staff member’s partiality, charges without proofs,
                            insults and denigration of any member of the administration staff will be immediately punished with a ban.
                        </li>
                        <li style="text-align: justify;">It is forbidden to send addresses and links to private profiles on social networking
                            websites. Intentional publication of personal details to embarrass or harm anyone will be punished.
                        </li>
                        <li style="text-align: justify;">Any kind of harmful actions against the server will be punished with a permanent ban.<br><br>
                        </li>
                        <li style="text-align: justify;">The penalty is put on an account, not the person. The only exception is an IP ban, which is
                            being put on for acting in harmful ways against the server or repeatedly breaking the server rules.
                        </li>
                    </ol>
                </div>
                <div class="line">
                    Last change
                    <meta content="2013-05-01 21:12:45" itemprop="datePublished">
                    <time itemprop="dateModified" datetime="2016-01-11 23:37:14">11 January 2016</time>
                </div>
            </div>
        </div>

    </div>
</div>