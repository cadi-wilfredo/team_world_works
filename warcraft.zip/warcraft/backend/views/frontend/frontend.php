<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <?php echo assets_css(
        array(
            'node_modules/semantic/assets/semantic/dist/semantic.css',
            'node_modules/semantic/assets/css/style.css'
        )
    ) ?>
</head>
<body class="full height">
<!--top bar-->
<div id="topmenu" class="ui top attached menu inverted teal">
    <div class="right menu">
        <a class="item" href="<?php echo site_url('app/backend/'); ?>">Backend</a>
        <a class="item">Sign Up</a>
        <a class="item">Help</a>
    </div>
</div>
<ng-app class="row">Loading...</ng-app>

<?php echo assets_js(
    array(
        'node_modules/semantic/vendor/jquery-2.1.4.min.js',
        'node_modules/semantic/assets/semantic/dist/semantic.min.js'
    )
) ?>
<script type="text/javascript">
//    Configuration = $.parseJSON('<?php //echo $conf ?>//');
//    Theme = $.parseJSON('<?php //echo $theme ?>//');
    System.config({
        defaultJSExtensions: true,
        paths: {
            'tplUrl': 'assets/apps/frontend/themes/' + Theme.foldername + '-thm/partials/',
            'angular2/': 'assets/node_modules/angular2/',
            'angular2-websocket/': 'assets/node_modules/angular2-websocket/',
            "semantic-ui/dist/components/*": 'assets/node_modules/semantic/assets/semantic/dist/components/*.js',
//            "rxjs/operator/*": 'assets/node_modules/semantic/vendor/rxjs/add/operator/*',
            "rxjs/": 'assets/node_modules/rxjs/',
            "xhr-factory": 'assets/apps/backend/serv/xhr-factory',
            "serv/": 'assets/apps/backend/serv/',
            "facts/": 'assets/apps/backend/serv/facts/'
        },
        map: {
            "typescript": 'assets/node_modules/ntypescript/bin/typescript.js',
            "ng-semantic/semantic": 'assets/node_modules/semantic/vendor/ng-semantic/semantic.js'
        },
        packages: {
            "backend": {
                format: 'register',
                defaultExtension: 'js'
            }
        }
    });
    System.import('assets/apps/frontend/boot').then(null, console.error.bind(console));
</script>
</body>
</html>

