<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
        <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
        <title>Atlantiss</title>
        <link type="image/x-icon" href="../../../assets/frontend/images/favicon.ico" rel="icon">
        <meta content="index, follow" name="Robots">
        <meta content="1 days" name="revisit-after">
        <meta content="Copyright © Atlantiss" name="dcterms.rightsHolder">
        <meta content="2014" name="dcterms.dateCopyrighted">
        <meta content="Atlantiss" name="author">
        <meta content="Map - Atlantiss" property="og:title">
        <meta content="article" property="og:type">
        <meta content="We are a free, blizzlike Private World of Warcraft: Cataclysm server.
        Created on the basis of trinitycore. Current patch is 4.3.4" property="og:description">
        <meta content="http://atlantiss.eu/images/n3pr5E7.png" property="og:image">
        <meta content="Map - Atlantiss" itemprop="name">
        <meta content="recursos/n3pr5E7.png" itemprop="image">
        <?php echo assets_css(
            array(
                'frontend/css/style.css',
                'frontend/css/jquery-ui.css',
                'frontend/css/armory.css',
                'frontend/css/table.css',
                'frontend/css/map.css',
                'frontend/css/pvp.css',
                'frontend/css/gameguide.css'
            )
        ) ?>
        <?php echo assets_js(array('frontend/js/jquery-2.1.4.min.js')) ?>
    </head>
    <body class="full height" style="cursor: default;">

        <div id="container">

            <?= $header ?>
            <?= $content ?>

            <div class="clear"></div>

            <?= $footer ?>

            <div style="position: absolute; min-width: 250px; max-width: 300px; visibility: visible; display: none;" id="map-tip"
                 class="wowhead-tooltip">
            </div>

        </div>
        <script type="text/javascript">
            baseUrl = '<?php echo base_url() ?>';
        </script>
        <?php echo assets_js(
            array(
                'frontend/js/scripts.js',
                'frontend/js/power.js',
                'frontend/js/jquery-ui.js',
                'frontend/js/jquery.tablesorter.js',
                'frontend/js/jquery.tablesorter.pager.js',
                'frontend/js/kinetic.js',
                'frontend/js/map.js',
                'frontend/js/recaptcha__es.js',
            )
        ) ?>

        <?php echo assets_css(array('frontend/css/basic.css',)) ?>

    </body>
</html>

