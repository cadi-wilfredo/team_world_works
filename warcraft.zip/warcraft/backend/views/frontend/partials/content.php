<div id="content-large">
    <div id="leftcolumn-large">
        <div class="fullpage-article">
            <div id="map-container">
                <section class="map-legend">
                    <h1 id="map-name">Eastern Kingdoms</h1>
                </section>
                <section class="map-list">
                    <dl>
                        <dt class="h_azeroth"><span>Azeroth</span></dt>
                        <dd data-type="north" class="north">
                    <span>
                        <b>Northrend</b>
                    </span>
                        </dd>
                        <dd data-type="kalimdor" class="kalimdor">
                    <span>
                        <b>Kalimdor</b>
                    </span>
                        </dd>
                        <dd data-type="east" class="east active">
                    <span>
                        <b>Eastern Kingdoms</b>
                    </span>
                        </dd>
                        <dd data-type="mal" class="mal">
                    <span>
                        <b>Maelstrom</b>
                    </span>
                        </dd>
                        <dt class="h_outlands"><span>Outland</span></dt>
                        <dd data-type="out" class="out">
                    <span>
                        <b>Outland</b>
                    </span>
                        </dd>
                        <dt style="margin-top: 5px;">
                        <div style="padding: 0px 15px;color: #9E815A;border-top: 1px solid #221006;padding-top: 10px;">
                            <b style="font-size: 0.8rem;">Show on Map:</b>
                            <ul id="map-filters" style="list-style:none;padding: 10px;margin: 0px;">
                                <li style="padding: 2px 10px;margin: 0px;">
                                    <label><b style="line-height: 11px;">Dungeons</b></label>
                                    <ul style="list-style:none;padding: 2px 10px 0px 10px;margin: 0px;">
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="4">
                                                <b style="line-height: 11px;">Cataclysm</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="5">
                                                <b style="line-height: 11px;">Wrath Of The Lich King</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="6">
                                                <b style="line-height: 11px;">The Burning Crusade</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="7">
                                                <b style="line-height: 11px;">Vanilla WoW</b>
                                            </label>
                                        </li>
                                    </ul>
                                </li>
                                <li style="padding: 2px 10px;margin: 0px;">
                                    <label><b style="line-height: 11px;">Cities</b></label>
                                    <ul style="list-style:none;padding: 2px 10px 0px 10px;margin: 0px;">
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="8" checked="">
                                                <b style="line-height: 11px;">Capital Cities of Alliance</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="9" checked="">
                                                <b style="line-height: 11px;">Capital Cities of Horde</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="14" checked="">
                                                <b style="line-height: 11px;">Neutral Cities</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="15">
                                                <b style="line-height: 11px;">Villages</b>
                                            </label>
                                        </li>
                                    </ul>
                                </li>
                                <li style="padding: 2px 10px;margin: 0px;">
                                    <label><b style="line-height: 11px;">Raids</b></label>
                                    <ul style="list-style:none;padding: 2px 10px 0px 10px;margin: 0px;">
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="10">
                                                <b style="line-height: 11px;">Cataclysm</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="11">
                                                <b style="line-height: 11px;">Wrath Of The Lich King</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="12">
                                                <b style="line-height: 11px;">The Burning Crusade</b>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox" style="float: left;margin-right:5px" value="13">
                                                <b style="line-height: 11px;">Vanilla WoW</b>
                                            </label>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        </dt>
                    </dl>
                    <div class="clear"></div>
                </section>
                <section id="map-section" class="map-preview">
                    <div style="position: relative; display: inline-block; width: 690px; height: 880px;" class="kineticjs-content"
                         role="presentation">
                        <canvas
                            style="padding: 0px; margin: 0px; border: 0px none; background: none repeat scroll 0% 0% transparent; position: absolute; top: 0px; left: 0px; width: 690px; height: 880px;"
                            width="690" height="880"></canvas>
                    </div>
                </section>

                <div style="margin-bottom:100px" class="clear"></div>
            </div>
            <div id="map-ender"></div>
        </div>
    </div>
</div>