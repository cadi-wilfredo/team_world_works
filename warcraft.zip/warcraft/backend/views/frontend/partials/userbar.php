<section id="user-bar">
    <div class="available" id="status-button"></div>
    <div id="status-bar">
        <div>
            <span class="alliance">1430</span>
            <span class="horde">1309</span>
        </div>
        <div id="o-status">Online Players: 2739</div>
    </div>
    <div id="login-bar">
        <form autocomplete="off" method="post" action="<?php echo site_url('login/') ?>" name="login">
            <input type="hidden" name="token" value="<?php echo $token ?>"/>
            <input type="text" maxlength="100" placeholder="Email..." autocomplete="on" id="l_username"
                   name="email"
                   class="login-input">
            <input type="password" maxlength="100" placeholder="Password..." autocomplete="on" id="l_password"
                   name="password"
                   class="login-input">
            <label class="checkl">
                <input type="checkbox" value="1" name="l_remember">
                <span>Remember</span><br>

                <a href="#!">Remind password</a>
            </label>
            <input type="submit" value="Login" name="login" id="login-btn">
            <br>
        </form>
    </div>
    <div id="marker-bar">
        <a href="<?php echo site_url('app/register') ?>" id="reglink"></a>
    </div>
</section>