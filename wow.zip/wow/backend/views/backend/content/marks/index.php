<h2 class="ui header">
    <i class="marker icon"></i>

    <div class="content">Marks</div>
</h2>
<div class="ui attached container">
    <?php if ($flash = $this->session->flashdata('alert')) {
        ?>
        <div class="ui ignored <?php echo $flash['type']; ?> message">
            <?php echo $flash['msg']; ?>
        </div>
    <?php } ?>
    <?php
    if ($this->session->userdata('rol') === 'admin') {
        ?>
        <a href="<?php echo site_url('mark/form/new/0') ?>">
            <button class="ui button green"><i class="plus icon"></i>Add mark</button>
        </a>
    <?php } ?>
    <table class="ui celled table">
        <thead>
        <tr>
            <th>
                <div class="ui ribbon label">Marks data table</div>
            </th>
            <th>Type</th>
            <th>Level</th>
            <th>Region</th>
            <th>Points</th>
            <th>Filter</th>
            <?php
            if ($this->session->userdata('rol') === 'admin') {
                ?>
                <th>Actions</th>
            <?php } ?>
        </tr>
        </thead>
        <tbody>
        <?php if ($cant > 0) {
            foreach ($marks as $mark) { ?>
                <tr>
                    <td class="">
                        <h4 class="ui image header">
                            <?php echo assets_img('client/images/' . $mark->icon . '.' . $mark->iconext, array('class' => "ui mini rounded image", 'title' => $mark->icon . '.' . $mark->iconext)) ?>
                            <div class="conten">
                                <?php echo $mark->name ?>
                            </div>
                        </h4>
                    </td>
                    <td class="">
                        <?php echo $mark->type === 'new' ? 'New' : assets_img('client/images/' . $mark->typeicon . '.' . $mark->typeiconext, array('class' => "ui mini rounded image", 'title' => $mark->typeicon)) ?></td>
                    <td class=""><?php echo $mark->min . ' - ' . $mark->max; ?></td>
                    <td class=""><?php $reg = ["east" => 'Eastern Kingdoms', 'kalimdor' => 'Kalimdor', 'out' => 'Outland', 'north' => 'Northrend', 'mal' => 'Maelstrom'];
                        echo $reg[$mark->region] ?></td>
                    <td class=""><?php echo $mark->points ?></td>
                    <td class=""><?php echo $mark->filter ?></td>
                    <?php
                    if ($this->session->userdata('rol') === 'admin') {
                        ?>
                        <td class="">

                            <div class="ui buttons">
                                <a class="ui button olive"
                                   href="<?php echo site_url('mark/form/edit/' . $mark->id) ?>">Edit</a>

                                <div class="or" data-text="or"></div>
                                <a class="ui button red"
                                   href="<?php echo site_url('mark/delete/marks/' . $mark->id) ?>">Delete</a>

                            </div>
                        </td>
                    <?php } ?>
                </tr>
            <?php }
        } else { ?>
            <tr>
                <td rowspan="7">No data to show</td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>