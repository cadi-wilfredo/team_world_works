<h2 class="ui header">
    <i class="marker icon"></i>

    <div class="content">Users</div>
</h2>
<div class="ui attached container">
    <?php if ($flash = $this->session->flashdata('alert')) {
        ?>
        <div class="ui ignored <?php echo $flash['type']; ?> message">
            <?php echo $flash['msg']; ?>
        </div>
    <?php } ?>
    <a href="<?php echo site_url('user/') ?>">
        <button class="ui button blue"><i class="arrow left icon"></i>Go back</button>
    </a>

    <div class="ui horizontal divider">User form</div>
    <form action="<?php echo site_url('user/process') ?>" method="post" class="ui form equal width"
          enctype="multipart/form-data">
        <?php if ($user) { ?>
            <input name="id" type="hidden" value="<?php echo $user->id ?>">
        <?php } ?>
        <div class="fields">
            <div class="field">
                <label>Name</label>
                <input name="name" placeholder="Enter your full name" type="text"/>
            </div>
            <div class="field">
                <label>Email</label>
                <input name="email" placeholder="Enter a valid email address" type="email"/>
            </div>
        </div>
        <div class="fields">
            <div class="field">
                <label>Role:</label>

                <div class="ui fluid search selection dropdown">
                    <input name="role" type="hidden">
                    <i class="dropdown icon"></i>

                    <div class="default text">Select Country</div>

                    <div class="menu">
                        <div class="item" data-value="user">
                            <i class="user icon"></i> User
                        </div>
                        <div class="item" data-value="admin">
                            <i class="key icon"></i> Administrator
                        </div>
                    </div>
                </div>
            </div>
            <div class="field">
                <label>Password</label>
                <input name="password" placeholder="Enter a Password" type="password"/>
            </div>
        </div>
        <div class="ui blue submit button">Submit</div>
        <div class="ui reset button">Reset</div>
        <div class="ui clear button">Clear</div>
    </form>
</div>