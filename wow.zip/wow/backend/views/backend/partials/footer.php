</section>
</div>
</div>
</div>
<?php echo assets_js(
    array(
        'backend/semantic/vendor/jquery-2.1.4.min.js',
        'backend/semantic/assets/semantic/dist/semantic.min.js'
    )
) ?>
<script type="text/javascript">
    //	Configuration = $.parseJSON('<?php //echo $conf ?>//');
    //	Theme = $.parseJSON('<?php //echo $conf ?>//');
    $(document).ready(function () {
        baseUrl = '<?php echo base_url() ?>';
        $('.ui.accordion').accordion();
        $('.tabular.menu .item').tab();
        $('.ui.sidebar')
            .sidebar({
                context: $('.bottom.segment'),
                dimPage: false,
                closable: false,
                mobileTransition: 'overlay', //if is a mobile
                transition: 'overlay', //if is a mobile
//                transition: 'slide along',
            });
        //            .sidebar('attach events', '.menu .item');
        $('#topmenu .toggleleftmenu').click(function () {
            $('#leftmenu').sidebar('toggle');
        });

        $('.ui.form').form({
            fields: {
                name: 'empty',
                x: ['maxLength[3]', 'empty', 'integer'],
                y: ['maxLength[3]', 'empty', 'integer'],
                min: ['maxLength[2]', 'empty', 'number'],
                max: ['maxLength[2]', 'empty', 'number'],
                type: ['empty'],
                filter: ['empty'],
                password: ['empty'],
                role: ['empty'],
                email: ['empty']
            },
            inline: true,
            on: 'submit',
        });
        <?php if($type === 'mark' && $data){ ?>
        $('.ui.form').form('set values', {
            name: "<?php echo $data->name ?>",
            x: "<?php echo json_decode($data->points,JSON_OBJECT_AS_ARRAY)[0] ?>",
            y: "<?php echo json_decode($data->points,JSON_OBJECT_AS_ARRAY)[1] ?>",
            min: "<?php echo $data->min ?>",
            max: "<?php echo  $data->max ?>",
            type: "<?php echo $data->type ?>",
            filter: "<?php echo $data->filter ?>",
            region: "<?php echo $data->region ?>",
            desc: "<?php echo $data->desc ?>",
        });
        <?php } ?>
        <?php if($type === 'user' && $data){ ?>
        $('.ui.form').form('set values', {
            name: "<?php echo $data->name ?>",
            role: "<?php echo $data->rol ?>",
            email: "<?php echo $data->email ?>",
        });
        <?php } ?>
        $('.ui.dropdown').dropdown();

        $('input#lvlmin').change(function () {
            var maxval = parseInt($('input#lvlmax').val());
            var minval = parseInt($(this).val());

            if (maxval <= minval) {
                $('input#lvlmax').attr('min', minval + 1);
                $('input#lvlmax').val(minval + 1);
            }
        });
        $('input#lvlmax').change(function () {
            var minval = parseInt($('input#lvlmin').val());
            var maxval = parseInt($(this).val());

            if (maxval <= minval) {
                $('input#lvlmax').attr('min', minval + 1);
                $('input#lvlmax').val(minval + 1);
            }
        });
        $('#openMap').click(function () {
            if ($('input[name|="region"]').val() !== "") {

                $('.ui.modal').modal('show');
                var img = new Image();
                var src = '';
                var region = $('input[name|="region"]').val();
                img.src = baseUrl + "assets/client/images/" + region + '.png';
                var mapCanvas = document.getElementById('mapCanvas');
                var context = mapCanvas.getContext('2d');
                img.onload = function () {
                    mapCanvas.width = mapCanvas.width;
                    context.drawImage(img, 0, 0);
                }
                mapCanvas.addEventListener('mousedown', function (event) {
                    var x = new Number();
                    var y = new Number();
                    if (event.x != undefined && event.y != undefined) {
                        x = event.x;
                        y = event.y;
                    } else {
                        x = event.clientX;
                        y = event.clientY;
                    }
                    $('#cordX').val(x - mapCanvas.offsetLeft - parseInt($('.ui.modal').position().left));
                    $('#cordY').val(y - mapCanvas.offsetTop - 50 + 4);
                    $('.ui.modal').modal('hide');
                }, false);
                mapCanvas.addEventListener('mousemove', function (event) {
                    var x = new Number();
                    var y = new Number();
                    if (event.x != undefined && event.y != undefined) {
                        x = event.x;
                        y = event.y;
                    } else {
                        x = event.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
                        y = event.clientY + document.body.scrollTop + document.documentElement.scrollTop;
                    }
                    $('.ui.modal .header').html('X: ' + (x - mapCanvas.offsetLeft - parseInt($('.ui.modal').position().left)) + ', Y:' + (y - mapCanvas.offsetTop - 100));
                }, false);
            }
        });
    });
</script>
</body>
</html>