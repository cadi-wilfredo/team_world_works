<!--top bar-->
<div id="topmenu" class="ui top attached menu inverted teal">
	<a class="item toggleleftmenu"><i class="sidebar icon"></i></a>

	<div class="right menu">
		<a class="item"><i class="user icon"></i> <?php echo $this->session->userdata('name') ?></a>
		<a class="item" href="<?php echo site_url('login/logout') ?>"><i class="out log icon"></i>Logout</a>
	</div>
</div>