<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span></div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1416" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.023669836132%;" title="8010" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.569892473118%;" title="1757" class="works"><span> </span></div>
                            <div style="width:1.8924731182796%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.602209944751%;" title="829" class="works"><span> </span></div>
                            <div style="width:3.646408839779%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.923580786026%;" title="1739" class="works"><span> </span></div>
                            <div style="width:0.10917030567686%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">

        <style>
            .changelog .ch_icon {
                background-repeat: no-repeat;
                display: inline-block;
                padding: 1px 0px 1px 20px;
                background-position: center left;
            }
        </style>

        <div class="fullpage-article">
            <div class="fullpage-article-content">
                <h1>Changelog 4.3.4</h1>
                <br style="clear: both;">
                <div class="changelog">
                    <a id="rev4987" name="rev4987"></a>
                    <div style="opacity:0.6">
                        <h3>
                            rev. <a href="#!">4987</a>
                        <span>
                            Author: <a>lama</a> ::
                            <i>2016-04-20 22:26</i>
                        </span>
                            - Waiting for update </h3>
                        <div id="changelog_16665">
                            <p>Core/Unit:</p>
                            <ul>
                                <li>Fix possible server crashes</li>
                            </ul>
                            <p>Core/GameEventMgr:</p>
                            <ul>
                                <li>Fix possibler server crash</li>
                            </ul>
                        </div>
                    </div>
                    <a id="rev4986" name="rev4986"></a>
                    <div style="opacity:0.6">
                        <h3>
                            rev. <a href="#!">4986</a>
                        <span>
                            Author: <a>quban</a> ::
                            <i>2016-04-19 20:18</i>
                        </span>
                            - Waiting for update </h3>
                        <div id="changelog_16663">
                            <p>
                                <span class="ch_icon" style="background-image:url(../../../../assets/client/images/boss.png)">
                                    Majordomo Staghelm:
                                </span>
                            </p>
                            <ul>
                                <li>changed a bit energy regeneration</li>
                            </ul>
                        </div>
                    </div>
                    <a id="rev4985" name="rev4985"></a>
                    <div style="opacity:0.6">
                        <h3>
                            rev. <a href="#!">4985</a>
                        <span>
                            Author: <a>Bandysc</a> ::
                            <i>2016-04-19 17:44</i>
                        </span>
                            - Waiting for update </h3>
                        <div id="changelog_16662">
                            <p>Core stuff</p></div>
                    </div>
                    <a id="rev4984" name="rev4984"></a>
                    <div>
                        <h3>
                            rev. <a href="#!">4984</a>
                        <span>
                            Author: <a>quban</a> ::
                            <i>2016-04-19 02:27</i>
                        </span>
                        </h3>
                        <div id="changelog_16659">
                            <p><span class="ch_icon" style="background-image:url(../../../../assets/client/images/item.png);">Item:</span></p>
                            <ul>
                                <li>fix <a href="#!">Free Action Potion</a></li>
                            </ul>
                        </div>
                    </div>
                    <a id="rev4983" name="rev4983"></a>
                    <div>
                        <h3>
                            rev. <a href="#!">4983</a>
                        <span>
                            Author: <a>Bandysc</a> ::
                            <i>2016-04-18 23:47</i>
                        </span>
                        </h3>
                        <div id="changelog_16657">
                            <ul>
                                <li>Scripted quest: A Helping Hand</li>
                            </ul>
                            <ul>
                                <li>Added SAI action SMART_ACTION_WP_START_PATH (214), which uses MotionMaster and target SMART_TARGET_LINKED_CREATURE
                                    (29)
                                </li>
                                <li>Added command .npc getquests</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>