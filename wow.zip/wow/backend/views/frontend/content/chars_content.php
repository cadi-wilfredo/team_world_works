<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1417" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                            <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                            <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                            <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">
        <div id="breadcrumbs">
            <ul style="list-style:none" itemprop="breadcrumb" id="breadcrumbs-position">
                <li><a href="#!">Atlantiss</a></li>
                <li><a href="#!">Banlist</a></li>
            </ul>
        </div>

        <div class="fullpage-article">
            <div class="fullpage-article-content">
                <a class="ui-button2" href="<?php echo site_url('app/bans_account') ?>"><span><span>Accounts<div></div></span></span></a>
                <a class="ui-button2" href="<?php echo site_url('app/bans_chars') ?>"><span><span>Characters<div></div></span></span></a>
                <table cellspacing="0" class="tablesorter" style="width:100%">
                    <thead>
                        <tr>
                            <th style="width:100px">Account or player</th>
                            <th style="width:65px">When</th>
                            <th>Time end</th>
                            <th>Created by</th>
                            <th>Reason</th>
                            <th>State</th>
                        </tr>
                    </thead>
                    <tbody>

                        <tr class="col">
                            <td><a href="#!">Czorcisko</a></td>
                            <td>2016-03-27 09:53:50</td>
                            <td>
                                2016-03-29 09:53:50
                            </td>
                            <td>Yggr</td>
                            <td>Abusing dungeon bug</td>
                            <td style="text-align:center">
                                <img src="../../../../assets/client/images/delete.png">
                            </td>
                        </tr>

                        <tr class="col">
                            <td><a href="#!">Fle</a></td>
                            <td>2016-02-21 20:43:23</td>
                            <td>
                                Perm ban
                            </td>
                            <td>Myivvo</td>
                            <td>hacks</td>
                            <td style="text-align:center">
                                <img src="../../../../assets/client/images/delete.png">
                            </td>
                        </tr>

                        <tr class="col">
                            <td><a href="#!">Skurwodaktyl</a></td>
                            <td>2016-02-05 23:44:22</td>
                            <td>
                                Perm ban
                            </td>
                            <td>Emtecs</td>
                            <td>obraza serwera</td>
                            <td style="text-align:center">
                                <img src="../../../../assets/client/images/delete.png">
                            </td>
                        </tr>

                        <tr class="col">
                            <td><a href="#!">Crosskin</a></td>
                            <td>2016-01-26 22:46:56</td>
                            <td>
                                Perm ban
                            </td>
                            <td>Tahtii</td>
                            <td>Offending Administration/SPAM.</td>
                            <td style="text-align:center">
                                <img src="../../../../assets/client/images/delete.png">
                            </td>
                        </tr>

                        <tr class="col">
                            <td><a href="#!">Skyfrostback</a></td>
                            <td>2016-01-26 12:45:57</td>
                            <td>
                                2016-02-02 12:45:57
                            </td>
                            <td>Ranor</td>
                            <td>Offending other players</td>
                            <td style="text-align:center">
                                <img src="../../../../assets/client/images/delete.png">
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>