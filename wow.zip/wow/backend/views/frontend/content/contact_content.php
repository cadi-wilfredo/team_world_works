<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1417" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                            <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                            <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                            <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">
        <div id="breadcrumbs">
            <ul style="list-style:none" itemprop="breadcrumb" id="breadcrumbs-position">
                <li><a href="#!">Atlantiss</a></li>
                <li><a href="#!">Contact Us</a></li>
            </ul>
        </div>

        <div class="fullpage-article page-content">
            <div itemtype="#!" itemscope="" class="fullpage-article-content">
                <h2 itemprop="name">Contact Us</h2>
                <div itemprop="description"><h3><strong>General Support:</strong></h3>
                    <table width="547" style="height: 6px; margin-left: auto; margin-right: auto;">
                        <tbody>
                            <tr>
                                <td><em><strong>Email</strong></em></td>
                                <td><em><strong>Description</strong></em></td>
                            </tr>
                            <tr>
                                <td><a href="mailto:support@atlantiss.eu">support@atlantiss.eu</a></td>
                                <td>Support</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:recruitment@atlantiss.eu">recruitment@atlantiss.eu</a></td>
                                <td>Recruitment</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:complaints@atlantiss.eu">complaints@atlantiss.eu</a></td>
                                <td>Complaints</td>
                            </tr>
                        </tbody>
                    </table>
                    <h3>&nbsp;</h3>
                    <hr>
                    <h3><strong>The Team:</strong></h3>
                    <table width="550" style="height: 94px; margin-left: auto; margin-right: auto;">
                        <tbody>
                            <tr>
                                <td><em><strong>Email</strong></em></td>
                                <td><em><strong>Nick</strong></em></td>
                                <td><em><strong>Position</strong></em></td>
                            </tr>
                            <tr>
                                <td><a href="mailto:emtec@atlantiss.eu">emtec@atlantiss.eu</a></td>
                                <td>(Emtec)</td>
                                <td>Head Administrator</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:ranor@atlantiss.eu">ranor@atlantiss.eu</a></td>
                                <td>(Ranor)</td>
                                <td>Community Support Master</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:luneth@atlantiss.eu">luneth@atlantiss.eu</a></td>
                                <td>(Luneth)</td>
                                <td>Forum Administrator</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:wolfenstein@atlantiss.eu">wolfenstein@atlantiss.eu</a></td>
                                <td>(Wolfenstein)</td>
                                <td>Master of Developers</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:giq@atlantiss.eu%20"><span data-cfemail="5b3c322a1b3a2f373a352f322828753e2e" class="__cf_email__">giq@atlantiss.eu</span></a>&nbsp;
                                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</td>
                                <td>(Giq) &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</td>
                                <td>Master of CF's</td>
                            </tr>
                        </tbody>
                    </table>
                    <p>&nbsp;</p>
                    <hr>
                    <p>&nbsp;</p>
                    <table width="552" style="height: 223px; margin-left: auto; margin-right: auto;">
                        <tbody>
                            <tr>
                                <td><em><strong>Email</strong></em></td>
                                <td><em><strong>Nick</strong></em></td>
                                <td><em><strong>Position</strong></em></td>
                            </tr>
                            <tr>
                                <td><a href="mailto:bildo@atlantiss.eu">bildo@atlantiss.eu</a></td>
                                <td>(Bildo)</td>
                                <td>Developer</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:jenova@atlantiss.eu">jenova@atlantiss.eu</a></td>
                                <td>(Jenova)</td>
                                <td>Developer</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:kiper@atlantiss.eu">kiper@atlantiss.eu</a></td>
                                <td>(Kiper)</td>
                                <td>Developer</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:krecik@atlantiss.eu">krecik@atlantiss.eu</a></td>
                                <td>(Krecik)</td>
                                <td>Developer</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:raknar@atlantiss.eu">raknar@atlantiss.eu</a></td>
                                <td>(Raknar)</td>
                                <td>Developer</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:salg@atlantiss.eu">salg@atlantiss.eu</a></td>
                                <td>(Salg)</td>
                                <td>Developer</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:yggr@atlantiss.eu">yggr@atlantiss.eu</a></td>
                                <td>(Yggr)</td>
                                <td>Game Master</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:freebooter@atlantiss.eu">freebooter@atlantiss.eu</a></td>
                                <td>(Freebooter)</td>
                                <td>Game Master</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:fureya@atlantiss.eu">fureya@atlantiss.eu</a></td>
                                <td>(Fureya)</td>
                                <td>Game Master</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:appophis@atlantiss.eu">appophis@atlantiss.eu</a></td>
                                <td>(Appophis)</td>
                                <td>Forum Moderator</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:hyko@atlantiss.eu">hyko@atlantiss.eu</a></td>
                                <td>(Hyko)</td>
                                <td>Forum Moderator</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:inferi@atlantiss.eu">inferi@atlantiss.eu</a></td>
                                <td>(Inferi)</td>
                                <td>Forum Moderator</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:lajfis@atlantiss.eu">lajfis@atlantiss.eu</a></td>
                                <td>(Lajfis)</td>
                                <td>Forum Moderator</td>
                            </tr>
                            <tr>
                                <td><a href="mailto:tytanus@atlantiss.eu">tytanus@atlantiss.eu</a></td>
                                <td>(Tytanus)</td>
                                <td>Forum Moderator</td>
                            </tr>
                        </tbody>
                    </table>
                    <p><strong>REMEMBER:</strong>&nbsp;</p>
                    <p>Inquiries related to gameplay must be addressed by opening an in-game ticket.</p></div>
                <div class="line">
                    Last change
                    <meta content="2015-01-13 22:56:03" itemprop="datePublished">
                    <time itemprop="dateModified" datetime="2015-05-13 11:21:29">13 May 2015</time>
                </div>
            </div>
        </div>

    </div>
</div>