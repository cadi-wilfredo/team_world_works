<div id="content-large">
    <div id="leftcolumn-large">

        <div id="gameguide-page" class="fullpage-article">
            <div class="fullpage-article-content">
                <div id="menu-part">
                    <img src="../../../../assets/client/images/logo.png">
                    <table cellspacing="0" style="width: 37%;" class="quatra-menu">
                        <thead>
                            <tr>
                                <th data-tab="m_tab1" class="bliz-quatra active">History</th>
                                <th data-tab="m_tab2" class="bliz-quatra">Server Rates</th>
                                <th data-tab="m_tab3" class="bliz-quatra">Machine</th>
                            </tr>
                        </thead>
                    </table>
                </div>

                <div id="history-part">
                    <div id="m_tab1" style="display: block;">
                        The history of the server starts in 2011, when the idea and the project of what we today call Atlantiss were born.
                        The server was supposed to be an alternative to still growing in numbers high rate servers (fun servers).
                        It took 1 year to finish initial works, form the Administration Team and Social Team.
                        The server opened on the 25 of March 2012. Atlantiss is the first Polish and one of the first in the world Cataclysm server.
                        From 2012 till now so many things have changed that it is impossible to describe all of them.
                        And it is just the beginning!

                        <br><br>
                        <span class="bliz-quatra">&nbsp; ...</span>
                        <span class="bliz-quatra">And it's just a beginning!&nbsp;</span> <span class="bliz-quatra"><span>SOON<span>&trade;</span></span></span>
                    </div>
                    <div style="display: none;" id="m_tab2">
                        <p>All the rates are set to x1</p>
                        <ul>
                            <li>Exp from&nbsp;NPCs x1</li>
                            <li>Exp from&nbsp;Quests x1</li>
                            <li>Exp from Instances and Battlegrounds x1</li>
                            <li>Gold drop x1</li>
                            <li>Item drop x1</li>
                            <li>Honor x1</li>
                            <li>Conquest poitns x1</li>
                            <li>Justice points x1</li>
                            <li>Valor points x1</li>
                        </ul>
                    </div>
                    <div style="display: none;" id="m_tab3">
                        <strong>Game server</strong>
                        <ul style="margin-bottom: 7px;margin-top: 5px;">
                            <li>2x Intel&reg; Xeon&reg; Processor E5630<br>(12 MB Intel Smart Cache, 2.53 GHz,<em>,&nbsp;</em>4 cores - 8 threads, turbo bost 2,8 GHz) 5.86 GT/s Intel&reg; QPI</li>
                            <li>192 GB DDR3 ECC</li>
                            <li>2x 2 TB SATA III (Hardware Raid MegaRaid + battery)</li>
                        </ul>
                        <strong style="margin-top: 0px;">TS3/www server</strong>
                        <ul style="margin-top: 5px;">
                            <li>Intel&reg; Atom&trade; Processor N2800<br>(1M Cache, 1.86 GHz, 2&nbsp;cores - 4 threads)</li>
                            <li>4 GB DDR3</li>
                            <li>2x 500GB SATA (Raid 1)</li>
                        </ul>
                    </div>
                </div>
                <a href="<?php echo site_url('app/map') ?>" id="map-part">
                    <img src="../../../../assets/client/images/gomap.png">
                </a>
                <div id="priv-status">
                    <div class="tip-bar">
                        <div title="1417" class="tip-bar-wrapp">
                            <div class="un"></div>
                            <div class="data-wrapp">
                                <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                                <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                            </div>
                        </div>
                    </div>
                    <span>Quests</span>

                    <div class="tip-bar">
                        <div title="524" class="tip-bar-wrapp">
                            <div class="un"></div>
                            <div class="data-wrapp">
                                <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                                <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                            </div>
                        </div>
                    </div>
                    <span>Achievement</span>

                    <div class="tip-bar">
                        <div title="43" class="tip-bar-wrapp">
                            <div class="un"></div>
                            <div class="data-wrapp">
                                <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                                <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                            </div>
                        </div>
                    </div>
                    <span>Instances</span>

                    <div class="tip-bar">
                        <div class="tip-bar-wrapp">
                            <div class="un"></div>
                            <div title="91" class="data-wrapp">
                                <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                                <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                            </div>
                        </div>
                    </div>
                    <span>Spell / Class</span>

                    <span class="darkner">Status provided by <b>private-status.com</b></span>
                </div>
                <div class="clear"></div>
                <div id="armory-part">
                    <form autocomplete="off" method="get" action="#!">
                        <input type="text" maxlength="100" name="name">
                    </form>
                    <table class="quatra-menu">
                        <thead>
                            <tr>
                                <th data-tab="tab5" class="bliz-quatra active">RATED BG</th>
                                <th data-tab="tab6" class="bliz-quatra">2VS<span style="font-size:120%">2</span></th>
                                <th data-tab="tab7" class="bliz-quatra">3VS<span style="font-size:120%">3</span></th>
                                <th data-tab="tab8" class="bliz-quatra">5VS<span style="font-size:120%">5</span></th>
                            </tr>
                        </thead>
                    </table>
                    <table id="tab5">
                        <tbody>
                        </tbody>
                    </table>
                    <table style="display:none" id="tab6">
                        <tbody>
                            <tr>
                                <td>BreakingBads</td><td>3153</td>
                            </tr>
                            <tr>
                                <td>we skip skill</td><td>3087</td>
                            </tr>
                            <tr>
                                <td>Cancerous gladiator</td><td>2942</td>
                            </tr>
                            <tr>
                                <td>sanwel dobrym serwerem</td><td>2887</td>
                            </tr>
                            <tr>
                                <td>asfasdasfas</td><td>2821</td>
                            </tr>
                        </tbody>
                    </table>
                    <table style="display:none" id="tab7">
                        <tbody>
                            <tr>
                                <td>TRUE DMG SZANOXA</td><td>2292</td>
                            </tr>
                            <tr>
                                <td>que tb jk no pop</td><td>2249</td>
                            </tr>
                            <tr>
                                <td>im in love with thekoko</td><td>2214</td>
                            </tr>
                            <tr>
                                <td>DamoJestMad</td><td>2185</td>
                            </tr>
                            <tr>
                                <td>Almost TSG</td><td>2004</td>
                            </tr>
                        </tbody>
                    </table>
                    <table style="display:none" id="tab8">
                        <tbody>
                            <tr>
                                <td>HORTA</td><td>1440</td>
                            </tr>
                            <tr>
                                <td>wpiateklecenamelo</td><td>1282</td>
                            </tr>
                            <tr>
                                <td>XD XP</td><td>1056</td>
                            </tr>
                            <tr>
                                <td>placki</td><td>1056</td>
                            </tr>
                            <tr>
                                <td>SAMO CEPAJ</td><td>672</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <a href="#!" id="calc-part">
                    <img src="../../../../assets/client/images/gocalc.png">
                </a>
                <div class="clear"></div>
                <div id="hof-part">
                    <div class="list left-list">
                        <b>Emtec</b>
                        <span>Head Admin</span>
                        <b>Wolfenstein</b>
                        <span>Master of Developers</span>
                        <b>Bildo</b>
                        <span>Developer</span>
                        <b>Salg</b>
                        <span>Developer</span>
                        <b>Jenova</b>
                        <span>Developer</span>
                        <b>Kiper</b>
                        <span>Developer</span>
                        <b>Krecik</b>
                        <span>Developer</span>
                        <b>Raknar</b>
                        <span>Developer</span>
                        <b>Savek</b>
                        <span>Developer</span>
                        <b>Quban</b>
                        <span>Developer</span>
                        <b>Bandy</b>
                        <span>Developer</span>
                    </div>
                    <div class="list right-list">
                        <b>Ranor</b>
                        <span>Community Support Master</span>
                        <b>Luneth</b>
                        <span>Forum Administrator</span>
                        <b>Lajfis</b>
                        <span>Forum Admin Assistant</span>
                        <b>Fureya</b>
                        <span>Game Master</span>
                        <b>Ohdeer</b>
                        <span>Game Master</span>
                        <b>Yamaha</b>
                        <span>Game Master</span>
                        <b>Sconnie</b>
                        <span>Game Master</span>
                        <b>Myivo</b>
                        <span>Game Master</span>
                        <b>Yggr</b>
                        <span>Agents Coordinator</span>
                        <b>Tytanus</b>
                        <span>Support Member</span>
                        <b>Silveris</b>
                        <span>Moviemaster</span>
                    </div>
                    <div class="center-section">
                        <img style="margin-top: 340px;" src="../../../../assets/client/images/hof.png">
                    </div>
                </div>
            </div>
            <div class="clear"></div>
            <div id="hof2-part">
                <section>
                    <div class="left-list list">
                        <img style="width:235px;height:60px" src="../../../../assets/client/images/atsv.png">
                        <b>Navedonar</b>
                        <span>Content Fixer</span>
                        <b>Hyko</b>
                        <span>Moderator</span>
                        <b>Apophis</b>
                        <span>Moderator</span>
                        <b>Inferi</b>
                        <span>Moderator</span>
                        <b>Ishya</b>
                        <span>Webmaster/Game Master</span>
                        <b>Garen_eye</b>
                        <span>Designer</span>
                    </div>
                    <div class="right-list list">
                        <img style="width:226px;height:60px" src="../../../../assets/client/images/honor.png">
                        <b>Gliniak</b>
                        <span>Developer</span>
                        <b>Miresa</b>
                        <span>Game Master</span>
                        <b>Nerv</b>
                        <span>Content Fixer</span>
                        <b>BGC</b>
                        <span>Game Master</span>
                        <b>Shande</b>
                        <span>Game Master</span>
                        <b>Dx</b>
                        <span>Game Master</span>
                        <b>Pallitax</b>
                        <span>Game Master</span>
                        <b>Armano</b>
                        <span>Tech Admin</span>
                        <b>Zori</b>
                        <span>Developer</span>
                    </div>
                    <div class="clear"></div>
                </section>
            </div>
        </div>

        <script type="text/javascript">
            $('#menu-part .quatra-menu .bliz-quatra').on("click", function() {
                $('#menu-part .quatra-menu .bliz-quatra').removeClass('active');
                $(this).addClass('active');
                $('#history-part div').css('display', 'none');
                $('#' + $(this).data('tab')).css('display', 'block');
            });
            $('#armory-part .quatra-menu .bliz-quatra').on("click", function() {
                $('#armory-part .quatra-menu .bliz-quatra').removeClass('active');
                $(this).addClass('active');
                $('#armory-part table').not('.quatra-menu').css('display', 'none');
                $('#' + $(this).data('tab')).css('display', '');
            });
        </script>

    </div>
</div>