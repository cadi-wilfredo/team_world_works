<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1416" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.023669836132%;" title="8010" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.569892473118%;" title="1757" class="works"><span> </span></div>
                            <div style="width:1.8924731182796%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.602209944751%;" title="829" class="works"><span> </span></div>
                            <div style="width:3.646408839779%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.923580786026%;" title="1739" class="works"><span> </span></div>
                            <div style="width:0.10917030567686%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">

        <div class="fullpage-article news-bg">
            <div style="padding:0;" class="fullpage-article-content">
                <div class="firstpost">
                    <div itemtype="#!" itemscope="" class="firstpostcontent">
                        <div itemtype="#!" itemscope="" class="postcontent">
                            <a href="#!">
                                <img width="180" height="180" class="postimg"
                                     src="../../../../assets/client/images/4fb60737e0a9104768e4773b2de69db312ae7c42.jpg" itemprop="thumbnailUrl">
                            </a>
                            <div class="right-postcontent">
                                <h3>
                                    <a href="#!" itemprop="url name">4th birthday</a>
                                </h3>
                                <div itemprop="articleBody" class="posttext">
                                    <p style="text-align: justify;">Ahoy Atlantiss Community!</p>
                                    <p style="text-align: justify;">Yesterday we had the pleasure of celebrating our 4th birthday. </p></div>
                                <div class="clear"></div>
                                <div class="line">
                                    <meta content="UserComments:71" itemprop="interactionCount">

                                    <a class="ui-button2" href="#!">
                                                <span>
                                                    <span>read more</span>
                                                </span>
                                    </a>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="">
                    <div itemtype="#!" itemscope="" class="firstpostcontent">
                        <div itemtype="#!" itemscope="" class="postcontent">
                            <a href="#!">
                                <img width="180" height="180" class="postimg"
                                     src="../../../../assets/client/images/4c8ae3f2a78e511d6df7bdd4cab379ad02d43184.jpg" itemprop="thumbnailUrl">
                            </a>
                            <div class="right-postcontent">
                                <h3>
                                    <a href="#!" itemprop="url name">Looking for After Effects Designer</a>
                                </h3>
                                <div itemprop="articleBody" class="posttext">
                                    <p style="text-align: justify;">Atlantiss Team is looking for one person for the position as After Effects
                                        Designer/Movie Master.<br></p></div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                    <div class="line line-ext">
                        <span itemprop="datePublished">15 March 2016</span>.
                        <span class="comments">Comments</span>: <a href="#!">16</a>
                        <meta content="UserComments:16" itemprop="interactionCount">

                        <a class="ui-button2" href="#!">
                                <span>
                                    <span>read more</span>
                                </span>
                        </a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="">
                    <div itemtype="#!" itemscope="" class="firstpostcontent">
                        <div itemtype="#!" itemscope="" class="postcontent">
                            <a href="#!">
                                <img width="180" height="180" class="postimg"
                                     src="../../../../assets/client/images/9062afd61c7e5bbab53962bcf0a0ed16fdce5c6e.jpg" itemprop="thumbnailUrl">
                            </a>
                            <div class="right-postcontent">
                                <h3>
                                    <a href="#!" itemprop="url name">Netherwing - Progress Through Expansions</a>
                                </h3>
                                <div itemprop="articleBody" class="posttext">
                                    <p style="text-align: justify;">Hello there!<br><br>Do you remember the Netherwing teasers we shared with you
                                        during the last 6 months? Today we have another one for you!</p></div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                    <div class="line line-ext">
                        <span itemprop="datePublished">22 February 2016</span>.
                        <span class="comments">Comments</span>: <a href="#!">114</a>
                        <meta content="UserComments:114" itemprop="interactionCount">

                        <a class="ui-button2" href="#!">
                                <span>
                                    <span>read more</span>
                                </span>
                        </a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="">
                    <div itemtype="#!" itemscope="" class="firstpostcontent">
                        <div itemtype="#!" itemscope="" class="postcontent">
                            <a href="#!">
                                <img width="180" height="180" class="postimg"
                                     src="../../../../assets/client/images/227b6f6a86cd9eda06a2496d5ae7bc511d20637f.jpg" itemprop="thumbnailUrl">
                            </a>
                            <div class="right-postcontent">
                                <h3>
                                    <a href="#!" itemprop="url name">Sunwell Transfers</a>
                                </h3>
                                <div itemprop="articleBody" class="posttext">
                                    <p style="text-align: justify;">During
                                        past few days we tried to mainly focus on optimizing the Dragonwrath
                                        realm, and after couple of coffees and unslept nights we managed to fix
                                        most of the issues that caused such high diff which made Dragonwrath
                                        almost unplayable at certain times.</p></div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                    <div class="line line-ext">
                        <span itemprop="datePublished">17 January 2016</span>.
                        <span class="comments">Comments</span>: <a href="#!">521</a>
                        <meta content="UserComments:521" itemprop="interactionCount">

                        <a class="ui-button2" href="#!">
                                <span>
                                    <span>read more</span>
                                </span>
                        </a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="">
                    <div itemtype="#!" itemscope="" class="firstpostcontent">
                        <div itemtype="#!" itemscope="" class="postcontent">
                            <a href="#!">
                                <img width="180" height="180" class="postimg"
                                     src="../../../../assets/client/images/aecb3924b776429a4369327b29e9f29af5dc1504.jpg" itemprop="thumbnailUrl">
                            </a>
                            <div class="right-postcontent">
                                <h3>
                                    <a href="#!" itemprop="url name">GM Recruitment</a>
                                </h3>
                                <div itemprop="articleBody" class="posttext">
                                    <p style="text-align: justify;">Dear
                                        players, due to high demand, we'd like to inform you that the Atlantiss
                                        team, yet again begins the recruitment for the Game Master position.</p></div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                    <div class="line line-ext">
                        <span itemprop="datePublished">4 January 2016</span>.
                        <span class="comments">Comments</span>: <a href="#!">31</a>
                        <meta content="UserComments:31" itemprop="interactionCount">

                        <a class="ui-button2" href="#!">
                                <span>
                                    <span>read more</span>
                                </span>
                        </a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="">
                    <div itemtype="#!" itemscope="" class="firstpostcontent">
                        <div itemtype="#!" itemscope="" class="postcontent">
                            <a href="#!">
                                <img width="180" height="180" class="postimg"
                                     src="../../../../assets/client/images/f2a494e31f881ba9660d10f85dadb61a942d25c8.jpg" itemprop="thumbnailUrl">
                            </a>
                            <div class="right-postcontent">
                                <h3>
                                    <a href="#!" itemprop="url name">Sunwell situation</a>
                                </h3>
                                <div itemprop="articleBody" class="posttext">
                                    <p style="text-align: justify;">Today
                                        we have to announce some sad news. In everyday life of every one of us
                                        there are elements which, according to us are solid, they are the
                                        foundation and a role model for durability and immortality. Sometimes
                                        these elements are people, sometimes objects and sometimes something
                                        completely else.</p>
                                    <p style="text-align: justify;"></p></div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                    <div class="line line-ext">
                        <span itemprop="datePublished">2 January 2016</span>.
                        <span class="comments">Comments</span>: <a href="#!">369</a>
                        <meta content="UserComments:369" itemprop="interactionCount">

                        <a class="ui-button2" href="#!">
                                <span>
                                    <span>read more</span>
                                </span>
                        </a>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>

    </div>
</div>