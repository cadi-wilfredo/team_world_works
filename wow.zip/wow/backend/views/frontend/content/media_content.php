<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1417" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                            <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                            <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                            <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">
        <div id="breadcrumbs">
            <ul style="list-style:none" itemprop="breadcrumb" id="breadcrumbs-position">
                <li><a href="#!">Atlantiss</a></li>
                <li><a href="#!">Media</a></li>
            </ul>
        </div>

        <div class="fullpage-article page-content">
            <div itemtype="#!" itemscope="" class="fullpage-article-content">
                <h2 itemprop="name">Media</h2>
                <div itemprop="description"><h2 style="text-align: center;">VIDEOS</h2>
                    <table width="91" style="margin-left: auto; margin-right: auto; height: 160px;">
                        <tbody>
                            <tr>
                                <td>
                                    <iframe width="320" height="180"
                                            src="#!"></iframe>
                                </td>
                                <td>
                                    <iframe width="320" height="180"
                                            src="#!"></iframe>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <h3 style="text-align: center;" class="yt" id="watch-headline-title"><span
                                            title="TITLE: Atlantiss WoW Private Server Review 4.0.6. AUTHOR: Dodgy kebaab" dir="ltr"
                                            class="watch-title " id="eow-title">Private Server Review</span></h3>
                                </td>
                                <td>
                                    <h3 style="text-align: center;" class="yt" id="watch-headline-title"><span
                                            title="TITLE: WoW Private Server Awards 2014 AUTHOR: Dodgy kebaab" dir="ltr" class="watch-title "
                                            id="eow-title">Private Server Awards 2014</span></h3>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <hr>
                                    <h3 style="text-align: center;" class="yt">&nbsp;</h3>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;
                                    <iframe width="320" height="180"
                                            src="#!"></iframe>
                                </td>
                                <td>&nbsp;
                                    <iframe width="320" height="180"
                                            src="#!"></iframe>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <h3 style="text-align: center;" class="yt" id="watch-headline-title"><span
                                            title="TITLE: Amicorum vs Sinestra - Atlantiss First [Affliction POV] AUTHOR: Zak" dir="ltr"
                                            class="watch-title long-title" id="eow-title">Amicorum vs Sinestra</span></h3>
                                </td>
                                <td>
                                    <h3 style="text-align: center;" class="yt" id="watch-headline-title"><span
                                            title="TITLE: Tol Barad - PvP World Zone - Private Server Atlantiss 4.3.4 (PoV Feral Druid) AUTHOR: Informator"
                                            dir="ltr" class="watch-title long-title" id="eow-title">Tol Barad - PvP World Zone</span></h3>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <hr>
                                    <h3 style="text-align: center;" class="yt">&nbsp;</h3>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;
                                    <iframe width="320" height="180"
                                            src="#!"></iframe>
                                </td>
                                <td>&nbsp;
                                    <iframe width="320" height="180"
                                            src="#!"></iframe>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <h3 style="text-align: center;" class="yt" id="watch-headline-title"><span
                                            title="TITLE: Genesis vs Omnotron Defense System - Atlantiss WoW AUTHOR: Lifelike" dir="ltr"
                                            class="watch-title " id="eow-title">Genesis vs Omnotron Defense System</span></h3>
                                </td>
                                <td>
                                    <h3 style="text-align: center;" class="yt" id="watch-headline-title"><span
                                            title="TITLE: Eternal Dynasty vs Cho'gall 10 Heroic - Atlantiss.eu - Server First Kill! AUTHOR: Nc"
                                            dir="ltr" class="watch-title long-title" id="eow-title">Eternal Dynasty vs Cho'gall</span></h3>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <hr>
                                    <h3 style="text-align: center;" class="yt">&nbsp;</h3>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <p>&nbsp;</p></div>
                <div class="line">
                    Last change
                    <meta content="2015-01-18 11:48:33" itemprop="datePublished">
                    <time itemprop="dateModified" datetime="2015-07-02 11:40:46">2 July 2015</time>
                </div>
            </div>
        </div>

    </div>
</div>