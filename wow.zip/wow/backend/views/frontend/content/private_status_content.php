<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1417" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                            <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                            <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                            <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">
        <div id="breadcrumbs">
            <ul style="list-style:none" itemprop="breadcrumb" id="breadcrumbs-position">
                <li><a href="#!">Atlantiss</a></li>
                <li><a href="#!">Quest Status (Addon)</a></li>
            </ul>
        </div>

        <div class="fullpage-article page-content">
            <div itemtype="#!" itemscope="" class="fullpage-article-content">
                <h2 itemprop="name">Quest Status (Addon)</h2>
                <div itemprop="description"><p>As you may know there is a website&nbsp;<a href="#!">(Private-Status)</a>
                        gathering data regarding working/non-working quests, spells, achievements etc. It circulates an add-on which sadly does not
                        support Cataclysm expansion. Since the add-on is quite helpful due to its ability to spot bugs, we have decided to reconfigure
                        it in a way it suits our patch.<br><br>You may download a fixed version below.<br>It is also advisable to systematically
                        update database file.</p>
                    <ul>
                        <li><a href="#!">Click here to download add-on</a></li>
                        <li><a href="#!">Click here to download database</a></li>
                    </ul>
                    <ol>
                        <li>Download the addon archive.</li>
                        <li>Extract addon files to: "[your game folder]\Interface\AddOns\".</li>
                        <li>Download the addon database.</li>
                        <li>Put the database into the addon folder.</li>
                        <li>In order to check the status you need to open a Quest Log once you are logged onto the game. Alternatively, you may simply
                            click a quest link.
                        </li>
                    </ol>
                    <p><a href="#!">Source</a></p>
                    <p style="text-align: right;"><a href="#!" class="ui-button2">Back to&nbsp;<strong>Information center</strong></a>
                    </p></div>
                <div class="line">
                    Last change
                    <meta content="2013-07-22 20:55:05" itemprop="datePublished">
                    <time itemprop="dateModified" datetime="2013-07-22 20:55:05">22 July 2013</time>
                </div>
            </div>
        </div>

    </div>
</div>