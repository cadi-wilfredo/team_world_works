<div id="content">
    <div id="rightcolumn">
        <span class="r-clear"></span>
        <a id="gameguide" href="<?php echo site_url('app/gameguide') ?>"><span>Center for knowledge</span></a>
        <div class="a-di">
            <ul itemtype="#!" itemscope="" class="subcategories">
                <li><a href="<?php echo site_url('app/information') ?>" itemprop="url"><span itemprop="name">Information Center</span></a></li>
                <li><a href="#!" itemprop="url"><span itemprop="name">Terms of use</span></a></li>
                <li><a href="<?php echo site_url('app/rules') ?>" itemprop="url"><span itemprop="name">Rules</span></a></li>
                <li><a href="<?php echo site_url('app/bans_account') ?>" itemprop="url"><span itemprop="name">Banlist</span></a></li>
                <li><a href="<?php echo site_url('app/progress') ?>" itemprop="url"><span itemprop="name">Progress Through Expansions</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
        <div id="gameguide-spacer"></div>
        <div class="a-di">
            <div id="private-status-header" class="category">
                <span class="category-text"><a href="<?php echo site_url('app/private_status') ?>">Private Status</a></span>
            </div>
            <div id="private-status">
                <div class="tip-bar">
                    <div title="1417" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:81.013554521546%;" title="8009" class="works"><span> </span></div>
                            <div style="width:4.6530447096905%;" title="460" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Quests</span>

                <div class="tip-bar">
                    <div title="524" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:75.580395528805%;" title="1758" class="works"><span> </span></div>
                            <div style="width:1.8916595012898%;" title="44" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Achievement</span>

                <div class="tip-bar">
                    <div title="43" class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div class="data-wrapp">
                            <div style="width:91.611479028698%;" title="830" class="works"><span> </span></div>
                            <div style="width:3.6423841059603%;" title="33" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Instances</span>

                <div class="tip-bar">
                    <div class="tip-bar-wrapp">
                        <div class="un"></div>
                        <div title="91" class="data-wrapp">
                            <div style="width:94.926350245499%;" title="1740" class="works"><span> </span></div>
                            <div style="width:0.10911074740862%;" title="2" class="noworks"><span> </span></div>
                        </div>
                    </div>
                </div>
                <span>Spell / Class</span>
            </div>
        </div>
        <span style="clear:both"></span>
    </div>
    <div id="leftcolumn">
        <div id="breadcrumbs">
            <ul style="list-style:none" itemprop="breadcrumb" id="breadcrumbs-position">
                <li><a href="#!">Atlantiss</a></li>
                <li><a href="#!">Scroll of Resurrection</a></li>
            </ul>
        </div>

        <div class="fullpage-article page-content">
            <div itemtype="#!" itemscope="" class="fullpage-article-content">
                <h2 itemprop="name">Scroll of Resurrection</h2>
                <div itemprop="description"><p style="text-align: justify;">Scroll of Resurrection is a system developed by Blizzard which was
                        designed for people, whose account was frozen in given term. For obvious reasons it's not possible to model this system in
                        100% on our server, but still we tried very hard to model it as close as it was possible to the official version. <br> <br>Scroll
                        Of Resurrection (hereinafter referred to as SoR) will be available for accounts which the&nbsp;last login update was maximum
                        back in&nbsp;30 September 23:59:59 2015, and they do not own any 85 character level. <br> <br>SoR allows for a single level
                        boost on any character up to 80 level. The character is also provided with riding skills, mount, bags, green item set for the
                        current or default spec (DPS) and a quanity of gold in order to buy necessary skills. <br> <br><strong>How can i check if i
                            can use SoR?</strong> <br>SoR system is fully automated and is supported by player in game. To check if your account may
                        use the SoR system, type in game command <span style="text-decoration: underline;"><em>.sor info</em> </span><br>The feedback
                        information that will display on chat will show if you can use the SoR option, if yes it will tell you how to use it on
                        current character.</p>
                    <ul>
                        <li style="text-align: justify;"><strong>Remember!</strong> <br>Be sure that the character on which you are using the command
                            to use SoR is the character that you want to boost.&nbsp;</li>
                        <li style="text-align: justify;"><strong>Remember!</strong> <br>Items which Scroll of Resurrection offers will be sent to your
                            mailbox in game.
                        </li>
                        <li style="text-align: justify;"><strong>Remember!</strong> <br>Using the Scroll of Resurrection on Death Knight character
                            won't automatically complement the talents and it won't teleport the character to other location. If the class on which
                            you wish to use the SoR is Death Knight, first you need to complete the Death Knight quest chain if you haven't done it
                            yet.
                        </li>
                        <li style="text-align: justify;"><strong>Remember!</strong> <br>Despite the possibility of giving the Scroll of Resurrection
                            by the Game Master, the Game Master won't add the option for the person who by the decision of the administration doesn't
                            deserve it!
                        </li>
                        <li style="text-align: justify;"><strong>Remember!</strong> <br>SoR is added for usage to the whole account, you can safely
                            make a new character in order to use the SoR option on it, however using this option on any character on the account will
                            automatically disable the option for the whole account and every character on it.
                        </li>
                        <li style="text-align: justify;"><strong>Remember!</strong> <br>SoR can be used only on character below level 80!</li>
                    </ul>
                </div>
                <div class="line">
                    Last change
                    <meta content="2015-01-11 16:49:41" itemprop="datePublished">
                    <time itemprop="dateModified" datetime="2015-01-11 16:49:41">11 January 2015</time>
                </div>
            </div>
        </div>

    </div>
</div>