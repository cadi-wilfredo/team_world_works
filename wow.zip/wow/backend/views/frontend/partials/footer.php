<div id="footer">
    <div id="footer-menu">
        <div>
            <h3>Atlantiss</h3>
            <ol>
                <li><a href="#!">Rules</a></li>
                <li><a href="#!">FAQ</a></li>
                <li><a href="#!">Forum</a></li>
                <li><a href="#!">Center for knowledge</a></li>
                <li><a href="#!">Contact Us</a></li>
            </ol>
        </div>
        <div>
            <h3>Server</h3>
            <ol>
                <li><a href="#!">Banlist</a></li>
                <li><a href="#!">Map</a></li>
                <li><a href="#!">Changelog 4.3.4</a></li>
                <li><a href="#!">Media</a></li>
            </ol>
        </div>
        <div>
            <h3>Account</h3>
            <ol>
                <li><a href="<?php echo site_url('app/register') ?>">Register</a></li>
                <li><a href="#!">SoR</a></li>
                <li><a href="#!">RaF</a></li>
                <li><a href="#!">Armory</a></li>
                <li><a href="#!">Talent calculator</a></li>
            </ol>
        </div>
    </div>
    <div id="footer-text">
        <b>Copyright &copy; Atlantiss 2015</b>. All Rights Reserved. <br><br>
        Cataclysm is a trademark, and World of Warcraft and Blizzard Entertainment are trademarks or registered
        trademarks of Blizzard Entertainment, Inc. in the U.S. and/or other countries. This site is in no way
        associated with Blizzard Entertainment.
    </div>
</div>




