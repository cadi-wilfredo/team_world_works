<header id="header">
    <a title="Atlantiss" href="<?php echo site_url('app/index') ?>"></a>
</header>

<?= $navbar ?>
<?= $userbar ?>

<div id="navbar"></div>

<a id="view-page" name="view-page"></a>