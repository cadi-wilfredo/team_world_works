<!--top bar-->
<div id="topmenu" class="ui top attached menu inverted teal">
    <div class="right menu">
        <a class="item" href="<?php echo site_url('app/backend/'); ?>">Backend</a>
        <a class="item">Sign Up</a>
        <a class="item">Help</a>
    </div>
</div>